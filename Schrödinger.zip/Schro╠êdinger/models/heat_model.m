function model = heat_model(params) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Heat equation model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab 
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function creates the heat equation model and follows mainly 
% the lines of other provided models within RBmatlab library.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Name/Type of Model
model.name = 'heat';
model.instationary  = 1;
model.decomp_mode   = 0;

%% Dimension of the PDE-Equations
if ~isfield(params,'dimrange')
    model.dimrange = 1;
else
    model.dimrange = params.dimrange;
end


%% Space Discretization
if ~isfield(params,'xrange')
    model.xrange = [0,1];
else
    model.xrange = params.xrange;
end

if ~isfield(params,'level_space_trial') || ~isfield(params,'level_space_test')
    model.xnumintervals_trial = 2^4;
    model.xnumintervals_test  = 2^4;
else
    model.level_space_trial   = params.level_space_trial;
    model.xnumintervals_trial = 2^(params.level_space_trial); %params.xnumintervals_trial;
    
    model.level_space_test    = params.level_space_test;
    model.xnumintervals_test  = 2^(params.level_space_test); %params.xnumintervals_test;
end

if ~isfield(params,'pdeg_space_trial') || ~isfield(params,'pdeg_space_test')
    model.pdeg_space_trial = 1; %*ones(model.xnumintervals,1);
    model.pdeg_space_test  = 1; %*ones(model.xnumintervals,1);
else
    model.pdeg_space_trial = params.pdeg_space_trial; %.*ones(model.xnumintervals_trial,1);
    model.pdeg_space_test  = params.pdeg_space_test; %.*ones(model.xnumintervals_test,1);
end

model.Xnumintervals_trial  = model.xnumintervals_trial;
model.Xnumintervals_test   = model.xnumintervals_test;

model.Xrange               = model.xrange;

model.PDEG_space_trial     = model.pdeg_space_trial;
model.PDEG_space_test      = model.pdeg_space_test;


%% Time Discretization (if necessary)
if ~isfield(params,'trange')
    model.trange = [0,1];
else
    model.trange = params.trange;
end

model.T          = model.trange(2);

if ~isfield(params,'level_time_trial') || ~isfield(params,'level_time_test')
    model.tnumintervals_trial = 2^5;
    model.tnumintervals_test  = 2^5;
else
    model.level_time_trial    = params.level_time_trial;
    model.tnumintervals_trial = 2^(params.level_time_trial); %params.tnumintervals_trial;
    
    model.level_time_test     = params.level_time_test;
    model.tnumintervals_test  = 2^(params.level_time_test); %params.tnumintervals_test;
end

if ~isfield(params,'pdeg_time_trial') || ~isfield(params,'pdeg_time_test')
    model.pdeg_time_trial = 1; %ones(model.tnumintervals,1);
    model.pdeg_time_test  = 0; %zeros(model.tnumintervals,1);
else
    model.pdeg_time_trial = params.pdeg_time_trial; %.*ones(model.tnumintervals_trial,1);
    model.pdeg_time_test  = params.pdeg_time_test; %.*ones(model.tnumintervals_test,1);
end

model.tnumintervals_trial = model.tnumintervals_trial;
model.tnumintervals_test  = model.tnumintervals_test;

model.trange              = model.trange;

model.PDEG_time_trial     = model.pdeg_time_trial;
model.PDEG_time_test      = model.pdeg_time_test;

model.gridtype = 'onedgrid';

%% Discretization-Scheme
model.use_SEM      = params.use_SEM;
model.use_dgSEM    = params.use_dgSEM;
model.use_BSplines = params.use_BSplines;

%% Ultraweak-Formulation
if ~isfield(params,'ultraweak_formulation')
    model.ultraweak_formulation = 0;
else
    model.ultraweak_formulation = params.ultraweak_formulation;
end

%% Generate Model_Data
if model.use_SEM
    model.gen_model_data = @sem_gen_model_data;
elseif model.use_BSplines
    model.gen_model_data = @BSpline_gen_model_data;
end

%% Function Handles for Boundary (Space)
model.boundary_type_space_trial   = @heat_boundary_type_space_trial;
model.boundary_type_space_test    = @heat_boundary_type_space_test;

model.reconstruct_dirichlet_space = @reconstruct_dirichlet_space;

%% Function Handles for Boundary (Time)
model.boundary_type_time_trial   = @heat_boundary_type_time_trial;
model.boundary_type_time_test    = @heat_boundary_type_time_test;

model.reconstruct_dirichlet_time_and_space = @reconstruct_dirichlet_time_and_space;

%% Function Handles for Evaluate Solution
model.eval_u = @eval_u;

%% Function Handles for Generating Matrices
if model.use_SEM
    model.operators = @sem_operators_schroedinger;
elseif model.use_BSplines
    if model.ultraweak_formulation
        model.operators = @BSpline_operators_ultraweak_schroedinger;
    else
        model.operators = @BSpline_operators_schroedinger;
    end
end    


%% Values for Space
% Left-Hand-Side
model.has_diffusivity_space     = 1;
diffusivity_coefficients_space  = @(dummy,params) -0.5;
diffusivity_components_space    = @(glob,params) {ones(length(glob),1)};
model.diffusivity_space         = @(glob,params) eval_affine_decomp_general(...
                                        diffusivity_components_space, ...
                                        diffusivity_coefficients_space, ... 
                                        glob, params);
                                    
model.has_advection_space       = 0;
advection_coefficients_space    = @(dummy,params) 0;
advection_components_space      = @(glob,params) {zeros(length(glob),1)};
model.advection_space           = @(glob,params) eval_affine_decomp_general(...
                                        advection_components_space, ...
                                        advection_coefficients_space, ...
                                        glob, params);

model.has_reaction_space        = 0;
reaction_coefficients_space     = @(dummy,params) 0.5*params.mus; %1i;
reaction_components_space       = @(glob,params) {glob.^2}; %{1-exp(params.mus*(glob-0.5))};
model.reaction_space            = @(glob,params) eval_affine_decomp_general(...
                                        reaction_components_space, ...
                                        reaction_coefficients_space, ... 
                                        glob, params);

% Boundary Information
model.has_dirichlet_values_space    = 1;
dir_coefficients_space              = @(dummy,params) 1;
dir_components_space                = @(glob,params) {zeros(length(glob),1)};
model.dirichlet_space               = @(glob,params) eval_affine_decomp_general(...
                                            dir_components_space, ...
                                            dir_coefficients_space, ...
                                            glob, params);

model.has_neumann_values_space      = 0;
neumann_coefficients_space          = @(dummy,params) 1;
neumann_components_space            = @(glob,params) {};
model.neumann_space                 = @(glob,params) eval_affine_decomp_general(...
                                        neumann_components_space, ...
                                        neumann_coefficients_space, ...
                                        glob, params);

model.has_robin_values_space        = 0;
robin_g_coefficients_space          = @(dummy,params) 1;
robin_beta_coefficients_space       = @(dummy,params) 1i*params.mus;
robin_g_components_space            = @(glob,params) {zeros(length(glob),1)};
robin_beta_components_space         = @(glob,params) {ones(length(glob),1)};
model.robin_g_space                 = @(glob,params) eval_affine_decomp_general(...
                                            robin_g_components_space, ...
                                            robin_g_coefficients_space, ... 
                                            glob, params);
model.robin_beta_space              = @(glob,params) eval_affine_decomp_general(...
                                            robin_beta_components_space, ...
                                            robin_beta_coefficients_space, ...
                                            glob, params);


 %% Values for Time
% Left-Hand-Side
model.has_diffusivity_time      = 0;
diffusivity_coefficients_time   = @(dummy,params) 0;
diffusivity_components_time     = @(glob,params) {zeros(length(glob),1)};
model.diffusivity_time          = @(glob,params) eval_affine_decomp_general(...
                                        diffusivity_components_time, ...
                                        diffusivity_coefficients_time, ... 
                                        glob, params);
                                    
model.has_advection_time        = 1;
advection_coefficients_time     = @(dummy,params) 1;
advection_components_time       = @(glob,params) {ones(length(glob),1)};
model.advection_time            = @(glob,params) eval_affine_decomp_general(...
                                        advection_components_time, ...
                                        advection_coefficients_time, ...
                                        glob, params);

model.has_reaction_time         = 0;
reaction_coefficients_time      = @(dummy,params) 0;
reaction_components_time        = @(glob,params) {glob.^2};
model.reaction_time             = @(glob,params) eval_affine_decomp_general(...
                                        reaction_components_time, ...
                                        reaction_coefficients_time, ... 
                                        glob, params);


% Boundary Information
model.has_dirichlet_values_time = 1;
dir_coefficients_time           = @(dummy,params) 1;
dir_components_time             = @(glob,params) {sqrt(2)*sin(pi*glob)}; %{(3/4)*(-glob.^2 + 1)}; %{6*(-(glob - 0.5).^2 + 0.25)}; %{(3/4)*(-glob.^2 + 1)};
model.dirichlet_time            = @(glob,params) eval_affine_decomp_general(...
                                            dir_components_time, ...
                                            dir_coefficients_time, ...
                                            glob, params);
                                                         
                                    
%% Right-Hand-Side (bisher nicht umgesetzt)
model.has_source    = 1;
source_coefficients = @(dummy,params) 1;
source_components   = @(glob,params) {zeros(length(glob{1}),length(glob{2}))}; %{[1000*ones(1, length(glob{2})); zeros(length(glob{1})-1,length(glob{2}))]};
model.source        = @(glob,params) eval_affine_decomp_general( ...
                                        source_components, ...
                                        source_coefficients, ...
                                        glob, params);

%% Output Functional
model.has_output_functional = 0;       

%% For the Plot
model.plot          = 1;
model.plot_solution = @plot_sol;

%% Adjoint Problem?
model.compute_adjoint_problem = 0;

%% Exact Integration?
model.use_exact_integration = 0;

%% Solve System
model.solveLGS = @SolveSystem;

%% For the Reshape
model.doReshape = @DoReshape;

%% For Space-Time-Error
model.compute_spacetime_error = @compute_spacetime_error;

%% Energy Norm
model.use_energy_norm = 0;

%% Modified Norm
model.use_modified_norm = 0;

%% Discrete Norm
model.use_discrete_norm = 0;

%% Use Kronecker-Product
model.use_kronecker_product = 0;

%% Which Solver?
model.use_CGNR         = 1;
model.use_CGNR_precond = 0; 
model.use_LSQR         = 0;

%% Compute Inf-Sup-Constant?
model.compute_infsup = 0;

%% Duality Pairing Time?
model.use_no_duality_pairing_time = 0;

end

%--------------------------------------------------------------------------
% For RB
%--------------------------------------------------------------------------
function u = heat_init_data_basis(model,model_data)
    mu       = model.get_mu(model);
    model    = model.set_mu(model,1);
    sim_data = detailed_simulation(model,model_data);
    u(:,1)   = model.get_dofs_from_sim_data(sim_data);
end

function model = set_mu(model,mu)
    model.mus = mu(:);
end



%--------------------------------------------------------------------------
% Boundary Space
%--------------------------------------------------------------------------
function index = heat_boundary_type_space_trial(glob, params)
    index = [];
    index = zeros(size(glob));
    index(abs(glob)<eps)   = -1; %Dirichlet
    index(abs(glob)>1-eps) = -1; %Dirichlet
end

function index = heat_boundary_type_space_test(glob, params)
    index = [];
    index = zeros(size(glob));
    index(abs(glob)<eps)   = -1; %Dirichlet
    index(abs(glob)>1-eps) = -1; %Dirichlet
end

function uh = reconstruct_dirichlet_space(model, model_data, u)

    uh = zeros(model_data.space.df_info.nnodes_trial,model_data.time.df_info.nnodes_trial);

    uh(model_data.space.df_info.dofs_trial,:) = u;
    
    dir = model_data.space.df_info.dirichlet_ind_trial;
    
    decomp_mode = model.decomp_mode;
    
    model.decomp_mode = 0;
    
    for i = 1:size(dir,1)
        X  = model_data.space.grid.X_trial(model_data.space.grid.dirichlet_nodes_trial(i,1));
        uD = model.dirichlet_space(X(:),model);
        uh(dir(i,1),:) = uD;
    end
    
    if model.use_BSplines
        uh = Evaluate_Spline(uh, model);
    end
    
    model.decomp_mode = decomp_mode;
    
end



%--------------------------------------------------------------------------
% Boundary Time
%--------------------------------------------------------------------------
function index = heat_boundary_type_time_trial(glob,params)
    index = [];
    index = zeros(size(glob));
    %index(abs(glob)<eps)    = -1; %Dirichlet
    %index(abs(glob)>1-eps) = -1; %Dirichlet
end

function index = heat_boundary_type_time_test(glob,params)
    index = [];
    index = zeros(size(glob));
    %index(abs(glob)<eps)    = -1; %Dirichlet
    %index(abs(glob)>1-eps) = -1; %Dirichlet
end

function uh = reconstruct_dirichlet_time_and_space(model, model_data, u)

    uh = zeros(model_data.space.df_info.nnodes_trial, model_data.time.df_info.nnodes_trial);

    uh(model_data.space.df_info.dofs_trial,model_data.time.df_info.dofs_trial) = u;
    
    uh = Evaluate_Spline(uh, model);
    
    decomp_mode = model.decomp_mode;
    
    model.decomp_mode = 0;
    
    if model.use_SEM
        grid_space = sort(model_data.space.grid.X_trial_with_LGL);
    elseif model.use_BSplines 
        grid_space = model_data.space.grid.X_trial;
    end
    
    uD = model.dirichlet_time(grid_space(:),model);

    if model_data.time.df_info.dirichlet_ind_trial(:,1) == 1
        for k = 1:size(uh,2)
            uh(:,k) = uh(:,k) + uD;
        end
    end
    
    dir = model_data.space.grid.dirichlet_nodes_trial(:,1);
    
    for i = 1:size(dir,1)
        X  = model_data.space.grid.X_trial(model_data.space.grid.dirichlet_nodes_trial(i,1));
        uD = model.dirichlet_space(X(:),model);
        uh(dir(i,1),:) = uD;
    end
    
    model.decomp_mode = decomp_mode;  
end



%--------------------------------------------------------------------------
% For the Plot
%--------------------------------------------------------------------------
function plot_sol(model, model_data, u, u_ex)
if model.plot == 1
    
    if model.use_SEM
        
        grid_space = sort(model_data.space.grid.X_trial_with_LGL);
        grid_time  = sort(model_data.time.grid.X_trial_with_LGL);
        endtime    = size(u,2);
        
    elseif model.use_BSplines
        
        endtime = size(u,2) - 1;
        [grid_time, grid_space] = compute_extended_knots_on_interval(model);
            
        grid_space = grid_space(model.pdeg_space_trial + 1 : end - model.pdeg_space_trial-1);
        grid_time  = grid_time(model.pdeg_time_trial + 1 : end - model.pdeg_time_trial-1);
        
    end
    
    
    figure
    subplot(1,2,1)
    for j = 1:endtime
        if nargin == 4
            plot(grid_space,real(u(:,j)),'b-',grid_space,real(u_ex(:,j)),'r-','linewidth',1.5)
        else
            plot(grid_space,real(u(:,j)),'linewidth',1.5)
        end
        title({'Re(u)'},'interpreter','Latex')
        xlabel({'$x$'},'interpreter','Latex')
        ylabel({'$\Re u(t,x)$'},'interpreter','Latex')
        ylim([-2.5,2.5])
        set(gca,'Fontsize',28)
        grid on
        pause(0.01)
        
    end
    
    subplot(1,2,2)
    for j = 1:endtime
        if nargin == 4
            plot(grid_space,imag(u(:,j)),'b-',grid_space,imag(u_ex(:,j)),'r-','linewidth',1.5)
        else
            plot(grid_space,imag(u(:,j)),'linewidth',1.5)
        end
        title({'Im(u)'},'interpreter','Latex')
        xlabel({'$x$'},'interpreter','Latex')
        ylabel({'$\Im u(t,x)$'},'interpreter','Latex')
        ylim([-2.5,2.5])
        set(gca,'Fontsize',28)
        grid on
        pause(0.01)
    end
    
    figure
    for j = 1:endtime
        plot(grid_space,(abs(u(:,j))).^2,'linewidth',1.5)
        title({'$\vert u(t,x) \vert^2$'},'interpreter','Latex')
        xlabel({'$x$'},'interpreter','Latex')
        ylabel({'$\vert u(t,x) \vert^2$'},'interpreter','Latex')
        ylim([0,2])
        set(gca,'Fontsize',28)
        grid on
        pause(0.01)
    end
    
    
    figure
    subplot(1,2,1)
    [T,X] = meshgrid(grid_time(1:endtime), grid_space);
    surf(T,X,real(u(:,1:endtime)))
    title({'Re(u)'},'interpreter','Latex')
    
    subplot(1,2,2)
    [T,X] = meshgrid(grid_time(1:endtime), grid_space);
    surf(T,X,imag(u(:,1:endtime)))
    title({'Im(u)'},'interpreter','Latex')
    
    
    figure
    subplot(2,1,1)
    x = grid_space;
    y = grid_time(1:endtime);
    [X,Y] = meshgrid(x,y);
    h = pcolor(X,Y,real(u(:,1:endtime))');
    shading interp;
    set(h, 'EdgeColor', 'none');
    colormap(hot)
    colorbar
    xlabel({'$x$'},'interpreter','Latex')
    ylabel({'$t$'},'interpreter','Latex')
    set(gca,'Fontsize',36)
    title({'Re(u)'},'interpreter','Latex')
    
    subplot(2,1,2)
    x = grid_space;
    y = grid_time(1:endtime);
    [X,Y] = meshgrid(x,y);
    h = pcolor(X,Y,imag(u(:,1:endtime))');
    shading interp;
    set(h, 'EdgeColor', 'none');
    colormap(hot)
    colorbar
    title({'Im(u)'},'interpreter','Latex')
    xlabel({'$x$'},'interpreter','Latex')
    ylabel({'$t$'},'interpreter','Latex')
    set(gca,'Fontsize',36)
     
end
end


function plot_rb_sol(model,model_data,u_rb,uh,u_ex)
figure
hold on;
for i=1:model_data.grid.nelements
    X = model_data.grid.X( model_data.df_info.LGL_nodes_on_element{i} );
    urb = u_rb(model_data.df_info.elements_glob{i});
    if ~isempty(uh)
        u_h = uh(model_data.df_info.elements_glob{i});
        plot(X,u_h,'r-o');
    end
    plot(X,urb,'b-*');
end

if nargin==5
    x=linspace(model.xrange(1),model.xrange(2),1000);
    plot(x,u_ex(x),'k-');
    %legend('exakt','rb')
    fn = ['Exakte- und RB-L�sung \n mit Polynomgrad = ' ...
        num2str(model.pdeg(1)) '\n und Anzahl der Elemente = ' ...
        num2str(model.xnumintervals)];
    title(sprintf(fn))
else
    title(sprintf(['RB-L�sung'
        '\n mit Polynomgrad = ' num2str(model.pdeg(1))
        '\n und Anzahl der Elemente = ' num2str(model.xnumintervals)]))
end
hold off;

end



%--------------------------------------------------------------------------
% Perform Minimal-Residual-Method
%--------------------------------------------------------------------------
function [u, it, runtime] = SolveSystem(B, r, model, model_data, flag)

if model.use_kronecker_product

    tic
    u       = B\r;
    runtime = toc;
    it      = [];
    
else
    
    if model.use_CGNR
        
        tic
        [u, it] = CGNR(B, r, 1e6, 1e-8, model, model_data, flag);
        runtime = toc;
        
    elseif model.use_CGNR_precond
        
        [V, D]  = eig(full(model_data.time.inner_product_matrices.H1semi_trial), full(model_data.time.inner_product_matrices.L2_trial));
        
        M       = {model_data.space.inner_product_matrices.L2_trial, model_data.space.inner_product_matrices.H1_trial, sparse(V), sparse(D)};
        
        tic
        [u, it] = CGNR_precond(B, r, 1e6, 1e-8, M, model, model_data, flag);
        runtime = toc;
        
    elseif model.use_LSQR
        
        if ~isempty(model_data.time.df_info.dirichlet_ind_trial)
            L_time  = chol(model_data.W_test{1}, 'lower');
            L_space = chol(model_data.W_test{2}, 'lower');
            
            N = {L_time, L_space};
        else
            L_time  = chol(model_data.W_test{1}{1}, 'lower');
            L_space = chol(model_data.W_test{1}{2}, 'lower');
            
            L_testfunction = chol(model_data.W_test{2}, 'lower');
            
            N = {{L_time, L_space}, {L_testfunction}};
        end
        
        [V, D]  = eig(full(model_data.time.inner_product_matrices.H1semi_trial), full(model_data.time.inner_product_matrices.L2_trial));
        
        M       = {model_data.space.inner_product_matrices.L2_trial, model_data.space.inner_product_matrices.H1_trial, sparse(V), sparse(D)};
        
        tic
        [u, it] = LSQR(B, r, 1e6, 1e-8, N, M, model, model_data);
        runtime = toc;
        
    else
        
        error('No Solver selected!')
        
    end
    
end

end



%--------------------------------------------------------------------------
% For the Reshape
%--------------------------------------------------------------------------
function u = DoReshape(u, model, model_data)

u = reshape(u, model_data.space.df_info.ndofs_trial, model_data.time.df_info.ndofs_trial);

end



%--------------------------------------------------------------------------
% For Computing Space-Time-Error
%--------------------------------------------------------------------------
function error_spacetime = compute_spacetime_error(error, error_vec, model, model_data)

if model.use_kronecker_product
    
    error_spacetime = real(error_vec' * model_data.inner_product_matrices.W_trial * error_vec);
    
else
    
    temp = TensorVector(model_data.inner_product_matrices.W_trial, error, 'notransp');
    
    error_spacetime = real(error_vec' * temp(:));
    
end

end



%--------------------------------------------------------------------------
% Evaluate Solution
%--------------------------------------------------------------------------
function s = eval_u(model,model_data,u,x)

j = 0;
G = model_data.grid.X(model_data.grid.elements);
s = zeros(size(x));

for i = 1:model_data.grid.nelements
    ind = find(x<=G(i,2));
    if ind
        p  = model_data.df_info.pdeg_per_element(i);
        X  = transform_points_from_element_to_reference_element(x(ind),G(i,:));
        Y  = eval_lagrange_on_reference_element(X,model_data.df_info.LGL_nodes_on_reference_element{p});
        uh = u(model_data.df_info.elements_glob{i});
        s(j+ind) = uh'* Y;
        x(ind) = [];
        j = j+length(ind);
    end
end

end



%--------------------------------------------------------------------------
% For Computing the Error
%--------------------------------------------------------------------------
function err = err_alg(Udet, Ured, err_par, model, model_data)
    Udiff = Udet - Ured;
    W     = err_par; %.inner_product_matrix_h10;
    %err  = sqrt( abs( (Udiff' * W * Udiff) / (Udet' * W * Udet)));
    err   = abs((Udiff' * W * Udiff));
end