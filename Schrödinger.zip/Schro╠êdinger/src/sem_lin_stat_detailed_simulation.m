function sim_data = sem_lin_stat_detailed_simulation(model,model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Mladjan Radic, Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model and struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               struct sim_data with high-fidelity solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function solves the high-fidelity system of linear equations
% using SEM as discretization method. This functions follows the lines of
% lin_stat_detailed_simulation.m by B. Haasdonk (22.02.2011) and is not 
% able to compute an output value.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Save decomp_model for later purposes
old_mode = model.decomp_mode;

% First, set decomp_mode to 1 and save the full matrix and RHS
model.decomp_mode = 1; % complete

sim_data = [];

% If full matrix A and full RHS r are not computed yet, compute and save it 
% in model_data.operators
if ~isfield(model_data,'operators')
    
    % Get full matrix A and RHS r
    [A,r] = model.operators(model,model_data);

    % Save matrix A and RHS in model_data.operators
    model_data.operators.A = A;
    model_data.operators.r = r;

end

% Now, set decomp_mode to 2, compute the coefficients and solve
% high-fidelity system of linear equations
model.decomp_mode = 2;

[Acoeff,rcoeff]   = model.operators(model,model_data);

A = lincomb_sequence(model_data.operators.A,Acoeff);
r = lincomb_sequence(model_data.operators.r,rcoeff);

% Solve system of linear equations
uh.dofs = A\r;

% Save high-fidelity solution in sim_data
sim_data.uh = uh;

% Reset old decomp_mode
model.decomp_mode = old_mode;