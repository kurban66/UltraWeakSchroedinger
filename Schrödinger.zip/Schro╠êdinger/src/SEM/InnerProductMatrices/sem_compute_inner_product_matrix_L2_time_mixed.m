function [L2, L2_with_Dirichlet] = sem_compute_inner_product_matrix_L2_time_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               L2 inner-product matrix (mixed) between temporal 
%                       trial and temporal test functions with and without
%                       Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the L2 inner-product matrices between the
% temporal trial functions and the temporal test functions (= "mixed") with 
% and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set values for computing Inner-Product-Matrix
diff_time                               = model.has_diffusivity_time;
model.has_diffusivity_time              = 0;

adv_time                                = model.has_advection_time;
model.has_advection_time                = 0;

reac_time                               = model.has_reaction_time;
model.has_reaction_time                 = 1;

dirichlet_time                          = model.has_dirichlet_values_time;
model.has_dirichlet_values_time         = 0;

if isempty(model_data.df_info.dirichlet_ind_trial) && isempty(model_data.df_info.dirichlet_ind_test)
    dirichlet_values = model.has_dirichlet_values_time;
    model.has_dirichlet_values_time = 0;
end

decomp_mode                             = model.decomp_mode;
model.decomp_mode                       = 0;

% Save & change the reaction components and coefficients!
reaction_time       = model.reaction_time;
model.reaction_time = @(glob,params) ones(length(glob),1);

% Compute Inner Product Matrix
L2_time           = sem_assembly_matrices_time(model,model_data);
L2_with_Dirichlet = L2_time{1};
L2                = L2_with_Dirichlet;

model.has_dirichlet_values_time = dirichlet_time;

if model.has_dirichlet_values_time && ~isempty(model_data.df_info.dirichlet_ind_trial)
    dir_info_trial            = model_data.df_info.dirichlet_ind_trial;
    L2(:,dir_info_trial(:,1)) = [];
end

if model.has_dirichlet_values_time && ~isempty(model_data.df_info.dirichlet_ind_test)
    dir_info_test            = model_data.df_info.dirichlet_ind_test;
    L2(dir_info_test(:,1),:) = [];
end

% Return the old values
model.has_diffusivity_time              = diff_time;
model.has_advection_time                = adv_time;
model.has_reaction_time                 = reac_time;

if isempty(model_data.df_info.dirichlet_ind_trial) && isempty(model_data.df_info.dirichlet_ind_test)
    model.has_dirichlet_vales_time = dirichlet_values;
end

model.reaction_time                     = reaction_time;

model.decomp_mode                       = decomp_mode;