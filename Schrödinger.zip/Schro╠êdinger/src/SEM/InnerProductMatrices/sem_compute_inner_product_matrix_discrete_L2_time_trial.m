function discrete_L2_trial = sem_compute_inner_product_matrix_discrete_L2_time_trial(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               L2 inner-product matrix for temporal trial 
%                       functions using a discrete subspace dependend 
%                       topology
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the L2 inner-product matrix for the
% temporal trial functions using a discrete subspace dependend topology.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Choose Grid
if model.use_exact_integration
    X = model_data.grid.X_trial_with_LGL_exact_integration(:);
else
    X = model_data.grid.X_trial_with_LGL(:);
end

% Compute Reaction-Matrix
coeff = model.reaction_time(X(:),model);

if model.decomp_mode == 0
    coeff = {coeff};
end

Q_a_reac = size(coeff,2);

discrete_L2_trial = cell(Q_a_reac,1);

h_el = model_data.grid.stepsize_per_element_trial;

for q = 1:Q_a_reac
    
    discrete_L2_trial{q} = sparse(model_data.df_info.nnodes_trial, model_data.df_info.nnodes_trial);
    
    c = coeff{q};
    
    for el = 1:model_data.grid.nelements_trial
        
        ind_trial = model_data.df_info.elements_glob_trial{el};
        
        if model.use_exact_integration
            ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{el};
        else
            ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_trial{el};
        end
        
        A_temp = (h_el/2) * ((diag(c(ind_of_LGL_nodes).* model_data.df_info.LGL_weights_on_reference_element') * ...
            model_data.df_info.lagrange_values_on_reference_element_trial{1})' * ...
            ones(size(model_data.df_info.lagrange_values_on_reference_element_trial{1})))';
        
        discrete_L2_trial{q}(ind_trial,ind_trial) = discrete_L2_trial{q}(ind_trial,ind_trial) + 1/h_el * A_temp .* A_temp';
        
    end
    
    if model.has_dirichlet_values_time && ~isempty(model_data.df_info.dirichlet_ind_trial)
        dir_info_trial = model_data.df_info.dirichlet_ind_trial;
        discrete_L2_trial{q}(:,dir_info_trial(:,1)) = [];
        discrete_L2_trial{q}(dir_info_trial(:,1),:) = [];
    end
    
end