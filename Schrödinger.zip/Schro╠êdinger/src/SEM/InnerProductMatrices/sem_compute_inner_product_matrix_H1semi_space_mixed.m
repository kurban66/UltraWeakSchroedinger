function [H1semi, H1semi_with_Dirichlet] = sem_compute_inner_product_matrix_H1semi_space_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H1-semi inner-product matrix (mixed) between 
%                       spatial trial and spatial test functions with and 
%                       without Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H1-semi inner-product matrices between 
% the spatial trial functions and the spatial test functions (= "mixed") 
% with and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set values for computing Inner-Product-Matrix
diff_space                              = model.has_diffusivity_space;
model.has_diffusivity_space             = 1;

adv_space                               = model.has_advection_space;
model.has_advection_space               = 0;

reac_space                              = model.has_reaction_space;
model.has_reaction_space                = 0;

dirichlet_space                         = model.has_dirichlet_values_space;
model.has_dirichlet_values_space        = 0;

robin_space                             = model.has_robin_values_space;
model.has_robin_values_space            = 0;

decomp_mode                             = model.decomp_mode;
model.decomp_mode                       = 0;

% Save & change the reaction components and coefficients!
diffusivity_space       = model.diffusivity_space;
model.diffusivity_space = @(glob,params) ones(length(glob),1);

% Compute Inner Product Matrix
H1semi                = sem_assembly_matrices_space(model,model_data);
H1semi_with_Dirichlet = -H1semi{1};
H1semi                = H1semi_with_Dirichlet;

model.has_dirichlet_values_space = dirichlet_space;

if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_trial)
    dir_info_trial                = model_data.df_info.dirichlet_ind_trial;
    H1semi(:,dir_info_trial(:,1)) = [];
end

if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_test)
    dir_info_test                = model_data.df_info.dirichlet_ind_test;
    H1semi(dir_info_test(:,1),:) = [];
end

% Return the old values
model.has_diffusivity_space             = diff_space;
model.has_advection_space               = adv_space;
model.has_reaction_space                = reac_space;

model.has_robin_values_space            = robin_space;

model.diffusivity_space                 = diffusivity_space;

model.decomp_mode                       = decomp_mode;