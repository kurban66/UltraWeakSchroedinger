function X = sem_compute_inner_product_matrix_trial(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               inner-product matrix for space and time dependend
%                       trial functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes inner-product matrix for the trial space, 
% which contains the space and time dependend trial functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose V-Norm
if model.use_energy_norm
    
    diffusion_matrix       = BSpline_compute_diffusion_matrix_space(model, model_data.space);
    diffusion_matrix       = {-diffusion_matrix{1}};
    
    if model.has_diffusivity_space && model.has_advection_space && model.has_reaction_space
        
        advection_matrix = sem_compute_advection_matrix_space(model, model_data.space);
        reaction_matrix = sem_compute_reaction_matrix_space(model, model_data.space);
        
        inner_product_matrix_V = cell2mat(diffusion_matrix) + cell2mat(advection_matrix) + cell2mat(reaction_matrix);
        inner_product_matrix_V = 0.5*(inner_product_matrix_V + inner_product_matrix_V.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
    
    elseif model.has_diffusivity_space && model.has_reaction_space
        
        reaction_matrix = sem_compute_reaction_matrix_space(model, model_data.space);
        
        inner_product_matrix_V = cell2mat(diffusion_matrix) + cell2mat(reaction_matrix);
        inner_product_matrix_V = 0.5*(inner_product_matrix_V + inner_product_matrix_V.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
        
    elseif model.has_diffusivity_space && ~model.has_reaction_space
        
        inner_product_matrix_V = 0.5*(diffusion_matrix{1} + diffusion_matrix{1}.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
        
    end
    
else
    
    inner_product_matrix_V = model_data.space.inner_product_matrices.H1_trial;
    
end

% Choose Inner-Product-Matrix of L2-Trial-Time
if model.use_discrete_norm
    
    %reaction_time       = model.reaction_time;
    %model.reaction_time = @(glob,params) ones(length(glob),1);
    
    %L2_trial_time        = sem_compute_inner_product_matrix_discrete_L2_time_trial(model, model_data.time);
    %L2_trial_time        = L2_trial_time{1};
    
    %model.reaction_time = reaction_time;
    
    L2_trial_time = model_data.time.inner_product_matrices.L2_mixed' * ...
        (model_data.time.inner_product_matrices.L2_test \ model_data.time.inner_product_matrices.L2_mixed);
    
else
    
    L2_trial_time = model_data.time.inner_product_matrices.L2_trial;
    
end

% Generate Inner-Product-Matrix of Trial-Space
if model.use_kronecker_product
    
    % Compute Inner-Product-Matrix for Trial-Space
    X = kron(L2_trial_time, inner_product_matrix_V) + ...
        kron(model_data.time.inner_product_matrices.H1semi_trial, model_data.space.inner_product_matrices.L2_trial * (inner_product_matrix_V \ model_data.space.inner_product_matrices.L2_trial));
    X = 0.5*(X + X');
    
    % If necessary, Compute Modified Norm
    if model.use_modified_norm
        
        temp = zeros(size(model_data.time.inner_product_matrices.L2_trial));
        temp(end,end) = 1;
        
        X = X + kron(temp, model_data.space.inner_product_matrices.L2_trial);
        X = 0.5*(X + X');
        
    end
    
else
    
    % Compute Inner-Product-Matrix for Trial-Space
    if model.use_modified_norm
        e          = sparse(model_data.time.df_info.ndofs_trial, model_data.time.df_info.ndofs_trial);
        e(end,end) = 1;
        
        X = {{L2_trial_time, inner_product_matrix_V}, ...
            {model_data.time.inner_product_matrices.H1semi_trial, model_data.space.inner_product_matrices.L2_trial * (inner_product_matrix_V \ model_data.space.inner_product_matrices.L2_trial)}, ...
            {e,model_data.space.inner_product_matrices.L2_trial}};
    else
        X = {{L2_trial_time, inner_product_matrix_V}, ...
            {model_data.time.inner_product_matrices.H1semi_trial, model_data.space.inner_product_matrices.L2_trial * (inner_product_matrix_V \ model_data.space.inner_product_matrices.L2_trial)}};
    end
    
end
