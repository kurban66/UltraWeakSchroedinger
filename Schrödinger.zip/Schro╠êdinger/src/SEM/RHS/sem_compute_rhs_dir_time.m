function r_dir_time = sem_compute_rhs_dir_time(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               RHS of high-fidelity formulation in time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function generates the RHS of the high-fidelity formulation 
% in time.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Compute Initial-Value-Time
coeff = model.dirichlet_time(sort(model_data.grid.X_trial_with_LGL(:)),model);

if model.decomp_mode == 0
    coeff = {coeff};
end

Q_b_source = size(coeff,2);
r_dir_time = cell(Q_b_source,1);

if strcmp(model.name,'schroedinger')
    inner_product_matrix = model_data.inner_product_matrices.L2_mixed_with_Dirichlet; %model_data.inner_product_matrices.H1_mixed_with_Dirichlet;
else
    inner_product_matrix = model_data.inner_product_matrices.L2_mixed_with_Dirichlet;
end


for q = 1:Q_b_source
    
    r_dir_time{q} = zeros(model_data.df_info.nnodes_test,1);
    
    for el = 1:model_data.grid.nelements_test
        
        ind  = model_data.df_info.elements_glob_test{el};
        
        uD    = coeff{q};
        
        r_dir_time{q}(ind) = inner_product_matrix(ind,:) * uD;

    end
    
    if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_trial)
        dir = model_data.df_info.dirichlet_ind_trial;
        r_dir_time{q}(dir(:,1)) = [];
    end
    
end

        
 
