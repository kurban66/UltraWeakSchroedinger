function [A] = sem_assembly_matrices_time(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               temporal system matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function helps to compute only the necessary temporal system 
% matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Adiff   = [];
Aadv    = [];
Areac   = [];


%% Assemble Diffusion Matrices
if model.has_diffusivity_time
    
    if model.use_SEM
    
        Adiff = sem_compute_diffusion_matrix_time(model, model_data);
        
    elseif model.use_BSplines
        
        Adiff = BSpline_compute_diffusion_matrix_time(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end



%% Assemble Advection Matrices
if model.has_advection_time
    
    if model.use_SEM
    
        Aadv = sem_compute_advection_matrix_time(model, model_data);
        
    elseif model.use_BSplines
        
        Aadv = BSpline_compute_advection_matrix_time(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end



%% Assemble Reaction Matrices
if model.has_reaction_time
    
    if model.use_SEM
    
        Areac = sem_compute_reaction_matrix_time(model, model_data);
        
    elseif model.use_BSplines
        
        Areac = BSpline_compute_reaction_matrix_time(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end


A = [Adiff; Aadv; Areac];

end
