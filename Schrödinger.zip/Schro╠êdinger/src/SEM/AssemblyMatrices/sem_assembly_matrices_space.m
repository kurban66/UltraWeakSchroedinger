function [A] = sem_assembly_matrices_space(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               spatial system matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function helps to compute only the necessary spatial system 
% matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Adiff   = [];
Aadv    = [];
Areac   = [];
Arobin  = [];


%% Assemble Diffusion Matrices
if model.has_diffusivity_space
    
    if model.use_SEM
    
        Adiff = sem_compute_diffusion_matrix_space(model, model_data);
        
    elseif model.use_BSplines
        
        Adiff = BSpline_compute_diffusion_matrix_space(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
         
end



%% Assemble Advection-Matrices
if model.has_advection_space
    
    if model.use_SEM
    
        Aadv = sem_compute_advection_matrix_space(model, model_data);
        
    elseif model.use_BSplines
        
        Aadv = BSpline_compute_advection_matrix_space(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end



%% Assemble Reaction-Matrices
if model.has_reaction_space
    
    if model.use_SEM
    
        Areac = sem_compute_reaction_matrix_space(model, model_data);
        
    elseif model.use_BSplines
        
        Areac = BSpline_compute_reaction_matrix_space(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end

end



%% Assemble Robin-Matrices
if model.has_robin_values_space
    
    if model.use_SEM
        
        Arobin = sem_compute_robin_matrix_space(model, model_data);
        
    elseif model.use_BSplines
        
        Arobin = BSpline_compute_robin_matrix_space(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end


A = [Adiff; Aadv; Areac; Arobin];

end
