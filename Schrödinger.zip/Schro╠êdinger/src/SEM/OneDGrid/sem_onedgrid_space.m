classdef sem_onedgrid_space < gridbase 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    12.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct params 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               spatial 1D grid 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB class generates a 1D grid in space and follows mainly the 
% lines of the RBmatlab function onedgrid.m.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    properties

        X_trial;
        X_test;
        X_trial_with_LGL;
        X_test_with_LGL;
        X_trial_with_LGL_exact_integration;
        X_test_with_LGL_exact_integration;
        
        nelements_trial;
        nelements_test;
        
        elements_coarse;
        elements_fine;  
        ratio;     

        stepsize_per_element_trial;
        stepsize_per_element_test;
        
        elements_trial;
        elements_test;
        
        NBI_trial;
        NBI_test;
        
        global_eind_trial; % global enumeration of entity indices '[1:nelements]'
        global_eind_test; % global enumeration of entity indices '[1:nelements]'
        
        A_trial;
        A_test;
        
        boundary_elements_type_trial;
        boundary_elements_type_test;
        
        dirichlet_nodes_trial;
        dirichlet_nodes_test;
        
        neumann_nodes_trial;
        neumann_nodes_test;
        
        robin_nodes_trial;
        robin_nodes_test;
        
    end
    
    methods
        
        function space = sem_onedgrid_space(varargin)
            % copy constructor
            if (nargin > 0) && ...
                    isa(varargin{1},'sem_onedgrid')
                % copy constructor
                fnames = fieldnames(varargin{1});
                
                for i = 1:length(fnames)
                    space.(fnames{i}) = varargin{1}.(fnames{i});
                end
                % the following only would copy handle!!!
                %grid= varargin{1};
                
            else
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % default constructor: unit interval
                if (nargin==0)
                    params.xrange = [0,1]; % 2 points
                    params.xnumintervals_trial = 100;
                    params.xnumintervals_test  = 100;
                else
                    params = varargin{1};
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % construct from params
                
                if ~isfield(params,'verbose')
                    params.verbose = 0;
                end
                
                %% Space
                % Step-Size for Trial- and Test-Space
                dx_trial = (params.xrange(2) - params.xrange(1))/params.xnumintervals_trial;
                dx_test  = (params.xrange(2) - params.xrange(1))/params.xnumintervals_test;
                
                % Grid-Points for Trial- and Test-Space
                space.X_trial = params.xrange(1):dx_trial:params.xrange(2);
                space.X_test  = params.xrange(1):dx_test:params.xrange(2);
                
                % Number of Grid-Points for Trial- and Test-Space
                n_trial = length(space.X_trial);
                n_test  = length(space.X_test);
                
                % Number of Elements for Trial- and Test-Space
                space.nelements_trial = n_trial - 1;
                space.nelements_test  = n_test - 1;
                
                if space.nelements_trial <= space.nelements_test
                    space.elements_coarse = space.nelements_trial;
                    space.elements_fine   = space.nelements_test;
                    space.ratio           = space.elements_fine/space.elements_coarse;
                else
                    space.elements_coarse = space.nelements_test;
                    space.elements_fine   = space.nelements_trial;
                    space.ratio           = space.elements_fine/space.elements_coarse;
                end
                
                % Step-Size per Element Space for Trial- and Test-Space
                space.stepsize_per_element_trial = dx_trial; 
                space.stepsize_per_element_test  = dx_test;
                
                % Elements for Trial- and Test-Space
                space.elements_trial = ...
                    [1:space.nelements_trial ; 2:space.nelements_trial + 1]';
                space.elements_test  = ...
                    [1:space.nelements_test ; 2:space.nelements_test + 1]';
                
                % Neighbourhood Information
                space.NBI_trial = ...
                    [2:space.nelements_trial, -1; -1,1:(space.nelements_trial - 1)]';
                space.NBI_test  = ...
                    [2:space.nelements_test, -1; -1,1:(space.nelements_test - 1)]';
                
                space.global_eind_trial = 1:space.nelements_trial;
                space.global_eind_test  = 1:space.nelements_test;
                
                space.A_trial = space.stepsize_per_element_trial./2;
                space.A_test = space.stepsize_per_element_test./2;
                
                %% Boundary Space
                % First and last element contain a boundary node!
                % We just have to find out which type...
                type_trial = params.boundary_type_space_trial(space.X_trial(1),params);
                type_test  = params.boundary_type_space_test(space.X_test(1),params);
                
                space.dirichlet_nodes_trial = [];
                space.dirichlet_nodes_test  = [];
                
                space.neumann_nodes_trial   = [];
                space.neumann_nodes_test    = [];
                
                space.robin_nodes_trial     = [];
                space.robin_nodes_test      = [];
                
                % Trial Space
                if type_trial < 0
                    
                    if abs(type_trial+1)<eps
                        space.dirichlet_nodes_trial = [1,1];
                    elseif abs(type_trial+2)<eps
                        space.neumann_nodes_trial = [1,1];
                    else
                        space.robin_nodes_trial = [1,1];
                    end
                    
                end
                
                % Test Space
                if type_test < 0
                    
                    if abs(type_test+1)<eps
                        space.dirichlet_nodes_test = [1,1];
                    elseif abs(type_test+2)<eps
                        space.neumann_nodes_test = [1,1];
                    else
                        space.robin_nodes_test = [1,1];
                    end
                    
                end
                
                
                type_trial = params.boundary_type_space_trial(space.X_trial(n_trial),params);
                type_test  = params.boundary_type_space_test(space.X_test(n_test),params);
                
                % Trial Space
                if type_trial < 0
                    if abs(type_trial+1)<eps
                        
                        space.dirichlet_nodes_trial = ...
                            [space.dirichlet_nodes_trial;n_trial,space.nelements_trial];
                        
                    elseif abs(type_trial+2)<eps
                        
                        space.neumann_nodes_trial = ...
                            [space.neumann_nodes_trial;n_trial,space.nelements_trial];
                        
                    else
                        
                        space.robin_nodes_trial = ...
                            [space.robin_nodes_trial; n_trial,space.nelements_trial];
                        
                    end
                end
                
                % Test Space
                if type_test < 0
                    if abs(type_test+1)<eps
                        
                        space.dirichlet_nodes_test = ...
                            [space.dirichlet_nodes_test; n_test, space.nelements_test];
                        
                    elseif abs(type_test+2)<eps
                        
                        space.neumann_nodes_test = ...
                            [space.neumann_nodes_test; n_test, space.nelements_test];
                        
                    else
                        
                        space.robin_nodes_test = ...
                            [space.robin_nodes_test;n_test, space.nelements_test];
                        
                    end
                end
                 
            end
        end
        
        gridp = gridpart(grid, eind);
        
        function gcopy = copy(grid)
            % deep copies the grid
            %
            % Return values:
            %   'gcopy': a copy of type onedspace.
            gcopy = onedgrid(grid);
        end
        
    end   % methods
    
end   % classdef
