function [seminfo_space_temp, seminfo_time_temp] = construct_seminfo(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data.grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               seminfo for space and time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function generates the seminfo for space as well as the 
% seminfo for time.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
seminfo_space_temp = [];
seminfo_time_temp  = [];

seminfo_space_temp = seminfo_space(model, model_data.space.grid);

if model.instationary 
    seminfo_time_temp = seminfo_time(model, model_data.time.grid);
end