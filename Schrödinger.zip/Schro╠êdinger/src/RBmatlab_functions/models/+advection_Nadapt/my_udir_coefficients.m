function U = my_udir_coefficients(X,Y,params)
%function U = my_udir_coefficients([],[],params)
%
% function computing parameter dependent coefficients of a function
% udir. The function f is obtained later by computing corresponding
% parameter independent components and then computing a linear combination
%
% the following evaluated at X= 0.0 (or 1.0)
%
% Xshift = X-params.transport_x * params.t;
% U = c_dir_1 * sin(pi*Xshift) +
%    c_dir_2 * sin(16*pi*Xshift+transport_x*1*pi) * 1_(1<=t<2) +

% Bernard Haasdonk 24.10.2008

arg = -pi*params.transport_x*params.t;
U = [params.c_dir_1 * sin(arg) , ...
     params.c_dir_2* sin(16*arg+params.transport_x*pi)...
        *(params.t<2 & params.t>=1)];
%| \docupdate 
