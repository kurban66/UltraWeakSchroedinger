function U = my_udir_components(X,Y,params)
%function U = my_udir_components(X,Y,params)
%
% function computing parameter independent components of a function
% f. The function f is obtained by computing corresponding
% parameter dependent coefficients and then computing a linear combination
%
% see my_udir_coefficients for specification of the function

% Bernard Haasdonk 24.10.2008

U = {ones(size(X)),ones(size(X))};
%| \docupdate 
