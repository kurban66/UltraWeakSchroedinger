function U = my_u0_components(X,Y,params)
%function U = my_u0_components(X,Y,params)
%
% function computing parameter independent components of a function
% f. The function f is obtained by computing corresponding
% parameter dependent coefficients and then computing a linear combination
%
% Initial data function is consistent with dirichlet values.
% See my_udir_coefficients for specification of the function.

% Bernard Haasdonk 24.10.2008

U = {sin(pi*X).*(X<Y) + sin(pi*Y).*(X>=Y)};
%| \docupdate 
