function U = my_u0_coefficients(X,Y,params)
%function U = my_u0_coefficients([],[],params)
%
% function computing parameter dependent coefficients of a function
% f. The function f is obtained by computing corresponding
% parameter independent components and then computing a linear combination
%
% Initial data function is consistent with dirichlet values.
% See my_udir_coefficients for specification of the function.

% Bernard Haasdonk 24.10.2008

U = [params.c_dir_1];

%| \docupdate 
