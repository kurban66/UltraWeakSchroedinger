function model = elastic_membrane_model(params)
%function model = elastic_membrane_model(params)
%
% model of an elastic membrane in 2D above some obstacles

% B. Haasdonk 11.3.2012

if nargin < 1
  params = [];
end;

model.decomp_mode = 0;
model.name = 'elastic_membrane';
model.mu_names = {'mu_1','mu_2'}; % first: diffusivity, second: obstacle
model.mu_ranges = {[0.3,20],[0,1]};

model.set_mu = @set_mu_default;
model.get_mu = @get_mu_default;

% default mu-values
model.mu_1 = 20;
model.mu_2 = 0.5;

% function pointers
model.gen_model_data = @vi_gen_model_data;
model.detailed_simulation = @vi_detailed_simulation;

model.gen_detailed_data = @vi_gen_detailed_data;
model.get_inner_product_matrix = @(model,model_data) ...
    model_data.df_info.regularized_h10_inner_product_matrix;
model.RB_stop_epsilon = 1e-6;
model.RB_stop_Nmax = 10;
model.gen_reduced_data = @vi_gen_reduced_data;
model.reduced_data_subset = @vi_reduced_data_subset;
model.rb_simulation = @vi_rb_simulation;
model.rb_reconstruction = @vi_rb_reconstruction;

model.plot_sim_data = @vi_plot_sim_data;
model.plot_detailed_data = @vi_plot_detailed_data;
model.get_rb_size = @(model,detailed_data) size(detailed_data.RB_U,2);
model.get_dofs_from_sim_data = @(sim_data) sim_data.U;
model.is_stationary = 1;
model.gridtype = 'triagrid';
model.grid_initfile = 'unitcircle_coarse.mat';

model.operators = @elastic_membrane_operators;
%model.get_inner_product_matrix = @standard_inner_product_matrix;
%model.get_supremizer_matrix = @elastic_membrane_supremizer_matrix;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model.has_diffusivity = 1;
model.has_reaction = 0;
model.has_advection = 0;
model.has_source = 1;
%model.has_output_functional = 0;
model.has_dirichlet_values = 1;
model.has_neumann_values = 0;
model.has_robin_values = 0;

% data functions
obstacle_coefficients = @(dummy,params) [0.5; params.mu_2];
obstacle_components = @(glob,params) ...
    {exp(10*(-(glob(:,1)-0.5).^2 - (glob(:,2)-0.5).^2))-2, ...
     exp(10*(-(glob(:,1)+0.5).^2 - (glob(:,2)).^2))};
model.obstacle = @(glob,params) ...
    eval_affine_decomp_general(obstacle_components, ...
			       obstacle_coefficients,glob,params);

% diffusion tensor: each row four entries a11,a_21,a_12,a_22. 
% a11(x)=a22(x) = mu_i if x in block i, a12=a21 = 0. 
mu_fix = 1;
my_diffusivity_tensor_coefficients = @(dummy,params) [mu_fix,params.mu_1];
model.diffusivity_tensor = @(glob,params) ...
    eval_affine_decomp_general(...
	@elastic_membrane_diffusivity_tensor_components, ...
	my_diffusivity_tensor_coefficients, glob,params);

dirichlet_values_coefficients = @(dummy,params) [0];
dirichlet_values_components = @(glob,params) {zeros(size(glob,1),1)};
model.dirichlet_values = @(glob,params) ...
    eval_affine_decomp_general(dirichlet_values_components, ...
			       dirichlet_values_coefficients,glob,params);

source_values_coefficients = @(dummy,params) [-2];
source_values_components = @(glob,params) {ones(size(glob,1),1)};
model.source = @(glob,params) ...
    eval_affine_decomp_general(source_values_components, ...
			       source_values_coefficients,glob,params);

% set pure dirichlet boundary conditions
model.boundary_type = @(glob,params) -ones(size(glob,1),1);

%%% inf-sup, coercivity and continuity constant
%model.beta_b = 1;
%model.alpha_a = @(model) min(model.mu_1,30);
%model.gamma_a = @(model) max(model.mu_1,30);
% discretization parameter
%model.H = params.H;
model.enable_error_estimator = 0;

model.beta_b = 1;
model.alpha_a = @(model) min(model.mu_1,mu_fix);
model.gamma_a = @(model) max(model.mu_1,mu_fix);

% parameter for the snaphots computation
model.RB_numintervals = [4, 4];
model.RB_generation_mode = 'enrichment_by_supremizers';
model.w_u = 1;
model.w_lambda = 1;

model.pdeg = 1; % polynomial degree 1
model.qdeg = 2; % quadrature degree
model.dimrange = 1;

% parameter for making work with new descr
model.descr = [];
model.crb_enabled = 0;
model.verbose = 0;
model = elliptic_discrete_model(model);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% auxiliary functions

function res = elastic_membrane_diffusivity_tensor_components(glob,params)
% diffusivity tensor component function:
% postivie x-direction and negative x-direction
res1 = zeros(size(glob,1),4);
i = find(glob(:,1)<=0);
if ~isempty(i)
  res1(i,1) = 1 ;
  res1(i,4) = 1 ;
end;
res2 = zeros(size(glob,1),4);
i = find(glob(:,1)>0);
if ~isempty(i)
  res2(i,1) = 1;
  res2(i,4) = 1;
end;
res = {res1,res2};

function [A,B,f,g] = elastic_membrane_operators(model,model_data)
%function [A,B,f,g] = elastic_membrane_operators(model,model_data)
%
% provides offline/online decomposition

[A,f] = fem_operators(model,model_data);
B = [];

if model.decomp_mode == 2
  %  B = 1;
  g = model.obstacle([],model);
elseif model.decomp_mode == 0
  g = -model.obstacle([model_data.grid.X,model_data.grid.Y],model);
  dirichlet_gids = model_data.df_info.dirichlet_gids;
  B = -speye(model_data.df_info.ndofs);
%  B(dirichlet_gids,dirichlet_gids) = 0;
  g(dirichlet_gids) = 0;
else %model.decomp_mode = 1
  gmin = model.obstacle([model_data.grid.X,model_data.grid.Y], ...
			model);
  dirichlet_gids = model_data.df_info.dirichlet_gids;
  gmin{1}(dirichlet_gids) = 0;
  gmin{2}(dirichlet_gids) = 0;
  g = {-gmin{1},-gmin{2}};
  dirichlet_gids = model_data.df_info.dirichlet_gids;
  B = -speye(model_data.df_info.ndofs);
end;
  
%function gamma_a = elastic_membrane_gamma_a(model);
