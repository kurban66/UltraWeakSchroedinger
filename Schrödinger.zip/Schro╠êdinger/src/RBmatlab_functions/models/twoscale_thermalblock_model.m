function model = twoscale_thermalblock_model(params)
%
% A thermalblock model, the parameters of which are 
% coupled to give overall params.Qa instead of params.B1*params.B2 
% many parameters. An N x M matrix of binary coefficient pattern
% needs to be given in params.parameter_pattern.
%
% A B1=M*M and B2 = N*N thermalblock is created, where 
% The pattern is taken for mu_1 as N*M unit blocks and
% the pattern is repeated N*M times for mu2
% the remaining blocks get mu3
%
% Hence, Qs = 3.

% B. Haasdonk 4.7.2012

[N,M] = size(params.parameter_pattern)
params.B1 = M*M;
params.B2 = N*N;
params.Qa = 3;
pattern = params.parameter_pattern';
pattern = pattern(:,end:-1:1);
parameter_mapping_matrix = 3*ones(N*N,M*M);
parameter_mapping_matrix1 = kron(pattern,ones(N,M));
parameter_mapping_matrix2 = kron(ones(N,M),pattern);

i = find(parameter_mapping_matrix1);
parameter_mapping_matrix(i) = 1;
i = find(parameter_mapping_matrix2);
parameter_mapping_matrix(i) = 2;
params.parameter_mapping = parameter_mapping_matrix(:);
model = multiscale_thermalblock_model(params);
