%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%                         COMSOL_README.txt                         %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
!!!
!!! A FULL DOCU IS NOT YET READY, BUT MAY BE PUBLISHED IN THE FUTURE! 
!!! MEANWHILE FEEL FREE TO ASK ANY QUESTIONS TO:
!!!
!!! oliver.zeeb@uni-ulm.de
!!!
!!! ANY COMMENTS, CRITICISM OR HINTS ARE WARMLY WELCOME AND VERY MUCH APPRECIATED!!!!
!!!
!!! Oliver Zeeb
!!! 2013/11/22
!!!

Here are some hints for the usage of the COMSOL-rbmatlab files:

1.) All the files were created and tested with COMSOL MULTIPHYSICS V4.2a
    If you are using a newer version (e.g. V4.3) please be sure to turn of the usage of "internal DOFs".
    Otherwise the size of the solution vector does not fit the size of the extracted operator matrices which causes problems and errors.
    The usage of internal dofs can be turned off the folliwing way: 
      Physics node ( 'Coefficient form PDE' or 'Weak form PDE' ) --> Discretization --> Turn off "Compute boundary fluxes"
    If you can't see "Discretization" in the physics node, it can be turned on in "Show" (the small sign with the eye on it).
2.) There are two files called comsol_save.m, comsol_load.m. Theses files are helpful for saving all the data
    including also a copy of the COMSOL model since this COMSOL model object would not be saved when just using the matlab commands
    'save(...)' and 'load(...).
    The function comsol_save(...) create two files on the hard disk, one is storing all the matlab data and another
    one saves the comsol model object.
    comsol_load(...) checks where there are structs with fields called 'comsol_model' (for example model_data or detailed_data)
    and loads the COMSOL model to these fields.
3.) There is a field in the model called 'model.use_comsol'.
    Once model_data is created, this field can (and should!) be set to 0. From then on, COMSOL is no longer needed for performing
    all the subsequent steps (e.g. perfomring a detailed simulation or creating the detailed_data).
    So all the computations can be done without using a copy of COMSOL once the model_data has been stored. This is extremely helpful
    when using COMSOL WITH MATLAB on a Mac, since (at least to speak for me) COMSOL WITH MATLAB is REALLY slow on a Mac.
    When using the Windows version of COMSOL these performance problems could not be observed.
    Although detailed and reduced simulations can be done without the usage of COMSOL, for plotting the results you need 
    COMSOL WITH MATLAB since the COMSOL plot routines are used.
4.) There are three scripts showing all the steps that are needed for performing a reduced simulation for different models:
     - comsol_thermal_block_script (2D stationary Thermal Block model created using a 'Coefficient Form PDE' including output calculations)
     - comsol_ThermalBlock3D_script (3D stationary Thermal Block model created using a 'Coefficient Form PDE' including output calculations)
     - evol_TB_2D_weak_form_model_script (2D instationary Thermal BLock model created using a 'Weak Form PDE' including output calculations)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% CREATING NEW MODELS WITH COMSOL AND RBMATLAB 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

For creating a new model, the following things have to be done:
    a.) Create the model with COMSOL and save it as mph-file.
         - Parameters should be defined in "Global Definitions".
         - The mesh sequence type should be set to 'user controlled mesh'
    b.) To create a rbmatlab modetl structure from the COMSOL model run
            model=gen_rbmatlab_model_from_comsol_model('mph_filename');
        All the needed fields (exception see point c.) are automatically extracted from the 
        comsol model and set in a proper way in the rbmatlab model.
    c.) the following two/three files must be written "by hand" and set in the rbmatlab-model:
            for linear stationary problems:
                - model.comsol_calculate_inner_product_matrices
                - model.operators
                - model.operators_output (optional! needed if model.compute_output_functional =1);
            for linear evolution problems:
                - model.comsol_calculate_inner_product_matrices
                - model.operators_ptr
                - model.operators_output (optional)
            for an example what these files shoud return, please have a look at the
            ThermalBlock 2D model (comsol_thermal_block_model)
            or 3D model (comsol_ThermalBlock3D_model)
            or the instationary ThermalBlock 2D model (evol_2D_weak_form_model).
    d.) now create the model_data
            model_data = gen_model_data(model)
        and afterwards set the usage of COMSOL to 'off':
            model.use_comsol = 0;
    e.) after these steps the usual rbmatlab commands can be used for creating a reduced basis,
        performing a detailed or reduced simulation and so on!
    f.) There are plot routines implemented that make use of the COMSOL plot routines. After a simulation the results can be plotted via 
            plot_sim_data(model,model_data,sim_data,[])
    g.) Due to the fact how COMSOL treats nonzero boundary conditions, especially when using an instationary model,
        the initial values stored in model_data can be added to the simulation data after a detailed or reconstricted reduced simulation
        to obtain a "real" result with inhomogeneous boundary conditions. Use the following command for this:
            sim_data.U=sim_data.U + repmat(model_data.operators.init_values,1,size(sim_data.U,2));



