classdef DetailedModel < LinStat.DetailedModel
  % Detailed model for the Thermalblock problem.
  %
  % This is a specialization of a linear stationary problem with simplified
  % methods for parameter handling, and a modified output method.


  methods
    function dm = DetailedModel(descr)
      % function dm = DetailedModel(descr)
      % constructor based on problem description
      %
      % Parameters:
      %  descr: structure of type ModelDescr describing the problem and the
      %         discretization
      dm = dm@LinStat.DetailedModel(descr);
    end

    function this=set_mu(this, mu)
      if length(mu)~=this.descr.number_of_blocks
        error('length of mu does not fit to number of blocks!');
      end;
      this.descr.mus = mu(:);
    end

    function mu = get_mu(this)
      mu = this.descr.mus(:);
    end

    function p = plot_sim_data(this, model_data, sim_data, plot_params)
      % function p = plot_sim_data(dmodel, model_data, sim_data, plot_params)
      % plots the simulation data as returned by detailed_simulation()
      %
      % This method actually calls femdiscfunc::plot().
      %
      % Parameters:
      %   sim_data:    simulation data structure as returned by detailed_simulation()
      %   plot_params: structure which controls the plot output
      %
      % Required fields of sim_data:
      %   uh:           discrete @ref fem function (c.f. ::femdiscfunc)
      %
      % Optional fields of plot_params:
      %   subsampling_level: number of sampling steps for interpolation of discrete
      %                      @ref fem functions. (default = 10)
      %   title:             title of the plot (default = none)
      %   no_lines:          boolean flag indicating whether lines between the
      %                      grid cell shall be skipped drawing (default = 1)
      %   plot_blocks:       boolean flag indicating whether the thermal blocks
      %                      shall be drawn. (default = 1)
      %
      % Return values:
      %   p:           GUI handle to the created MATLAB figure
      descr = this.descr;
      if nargin<4
        plot_params = [];
      end;
      if ~isfield(plot_params,'no_lines')
        plot_params.no_lines = 1;
      end;
      p = plot_sim_data@LinStat.DetailedModel(this, model_data,sim_data,plot_params);
      % plot coarse mesh
      if ~isfield(plot_params,'plot_blocks')
        plot_params.plot_blocks = 1;
      end;
      if plot_params.plot_blocks
        X = [0:1/descr.B1:1];
        Y = [0:1/descr.B2:1];
        l1 = line([X;X],...
          [zeros(1,descr.B1+1);...
          ones(1,descr.B1+1)]);
        set(l1,'color',[0,0,0],'linestyle','-.');
        %keyboard;
        l2 = line([zeros(1,descr.B2+1);...
          ones(1,descr.B2+1)],...
          [Y;Y]);
        set(l2,'color',[0,0,0],'linestyle','-.');
        p = [p(:);l1(:);l2(:)];
      end;
    end
  end
end
