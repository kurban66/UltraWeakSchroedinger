clear all, close all, clc;

params.xnumintervals = 250;
params.pdeg = 13;

params.xrange = [0,1];

model = sem_helmholtz_model_greedy_hierarchical_error_estimator(params);

model.RB_stop_Nmax = 49;
model.RB_numintervals = 5e3;
model.RB_detailed_train_savepath ='95_100';
model.mu_ranges = {[95 100]};
model.RB_stop_epsilon = 1e-4;
model.mus = 95;

model_data=model.gen_model_data(model);
M_train = linspace(95,100,5e3+1);

detailed_data = model_data;
detailed_data.RB_info.M_train = M_train;

first_mu = M_train(1);
model = model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,model_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);

U_enrich(:,1) = u;

SN(1) = 95;
SN_Indice = 1;

%{
for i=0:4
    mu_enrich = 90+i;
    SN(i+2) = mu_enrich;
    model=model.set_mu(model,mu_enrich);
    sim_data = detailed_simulation(model,detailed_data);
    U_enrich(:,i+2) = model.get_dofs_from_sim_data(sim_data);

end

n= size(U_enrich,2);

for i=1:5
    mu_enrich = 100+i;
    SN(end+1) = mu_enrich;
    model=model.set_mu(model,mu_enrich);
    sim_data = detailed_simulation(model,detailed_data);
    U_enrich(:,n+i) = model.get_dofs_from_sim_data(sim_data);
end
%}

mu_enrich = 97.5;
SN_Indice(end+1) = find(M_train == 97.5);
SN(end+1) = mu_enrich;
model=model.set_mu(model,mu_enrich);
sim_data = detailed_simulation(model,detailed_data);
U_enrich(:,2) = model.get_dofs_from_sim_data(sim_data);



% Orthonormalisation of the Init-Data-Basis
W = detailed_data.W;
if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
    disp('orthogonalising the init values')
    U_enrich = model_orthonormalize_qr(model, detailed_data ,U_enrich);
end


detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    U_enrich);



model.compute_constant = 0;
model.discrepancy = size(U_enrich,2)-1;
reduced_data = model.gen_reduced_data(model,detailed_data);


%reduced_data = model.gen_reduced_data(model,detailed_data_N);
hier_error = zeros(length(M_train),1);

for i = 1:length(M_train)
    mu = M_train(:,i);
    model = model.set_mu(model,mu);
    reduced_sim = rb_simulation(model, reduced_data);
    
    uN = reduced_sim.uN;
    uM = reduced_sim.reduced_data_M.uN;
    
    hier_error(i) = ...
        sqrt(abs(uM'*reduced_data.reduced_data_M.WMM*uM - ...
        uM'*reduced_data.reduced_data_M.WMN*uN - ...
        uN'*reduced_data.reduced_data_M.WNM*uM + ...
        uN'*reduced_data.reduced_data_M.WNN*uN));
end


figure(1)
set(gcf, 'Position', get(0, 'Screensize'));


h = plot(M_train,hier_error,'LineWidth',4);
le = legend({'$u_M (\mu) - u_N (\mu)$'},'interpreter','latex');
title('N=1')
xlabel('\mu')
set(le,'FontSize',20,'Location','northwest');
set(h(1),'linewidth',4);

[~,ind] = max(hier_error);
display(M_train(ind));

hier_error(SN_Indice) = 100000;
[val,min_err] = min(hier_error);

MIN(1,1) = val;
MIN(2,1) = min_err;

%% Weitere Snapshots Aufnehmen:

d=model.discrepancy;
u = detailed_data.RB;

for N=3:6
    
    third_mu = M_train(ind);
    
    SN(end+1) = third_mu;
    SN_Indice(end+1) = ind;
    
    model=model.set_mu(model,third_mu);
    sim_data = detailed_simulation(model,detailed_data);
    u(:,N:N-1+d) = u(:,N-1:N-2+d);
    u(:,N-1) = model.get_dofs_from_sim_data(sim_data);
    
    
    % Orthonormalisation of the Init-Data-Basis
    W = detailed_data.W;
    if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
        disp('orthogonalising the init values')
        u = model_orthonormalize_qr(model, detailed_data ,u);
    end
    
    
    detailed_data = model.set_rb_in_detailed_data(...
        detailed_data,...
        u);
    
    
    model.compute_constant = 0;
    reduced_data = model.gen_reduced_data(model,detailed_data);
    sigma = 0;
    hier_error = zeros(length(M_train),1);
    
    for i = 1:length(M_train)
        mu = M_train(:,i);
        model = model.set_mu(model,mu);
        reduced_sim = rb_simulation(model, reduced_data);
        
        uN = reduced_sim.uN;
        uM = reduced_sim.reduced_data_M.uN;
        
        hier_error(i) = ...
            sqrt(abs(uM'*reduced_data.reduced_data_M.WMM*uM - ...
            uM'*reduced_data.reduced_data_M.WMN*uN - ...
            uN'*reduced_data.reduced_data_M.WNM*uM + ...
            uN'*reduced_data.reduced_data_M.WNN*uN));
    end
    
    figure(N-1)
    set(gcf, 'Position', get(0, 'Screensize'));
    
    h = plot(M_train,hier_error,'LineWidth',4);
    le = legend({'$u_M (\mu) - u_N (\mu)$'},'interpreter','latex');
    title(['N=' num2str(N-1)])
    xlabel('\mu')
    set(le,'FontSize',20,'Location','northwest');
    set(h(1),'linewidth',4);
    
    [~,ind] = max(hier_error);
    display(M_train(ind));
    
    hier_error(SN_Indice) = 100000;
    [val,min_err] = min(hier_error);

    MIN(:,end+1) = [val ; min_err];
    
    
end




%% Plot f�r theta(mu)
%{
RB = detailed_data.RB;
dDN = detailed_data;
dDN1 = detailed_data;
dDN2 = detailed_data;

dDN.RB = RB(:,1:4);
dDN1.RB = RB(:,1:5);
dDN2.RB = RB(:,1:6);

model.discrepancy=0;
rDN = model.gen_reduced_data(model,dDN);
rDN1 = model.gen_reduced_data(model,dDN1);
rDN2 = model.gen_reduced_data(model,dDN2);

theta_truth = zeros(size(M_train));
theta_mod = zeros(size(M_train));
theta_mod2 = zeros(size(M_train));

for i = 1:length(M_train)
    flag = 1;
    mu = M_train(i);
    
    for j=1:6
        if norm(mu-SN(j))<1e-6
            flag = 0;
        end
    end
    
    if flag
        model = model.set_mu(model,mu);
        
        W = model.get_inner_product_matrix(detailed_data,model);
        
        sim_data = model.detailed_simulation(model,detailed_data);
        uh = sim_data.uh.dofs;
        
        rSN = rb_simulation(model, rDN);
        rSN1 = rb_simulation(model, rDN1);
        rSN2 = rb_simulation(model, rDN2);
        
        simRB_N = model.rb_reconstruction(model, detailed_data, rSN);
        simRB_N1 = model.rb_reconstruction(model, detailed_data, rSN1);
        simRB_N2 = model.rb_reconstruction(model, detailed_data, rSN2);
        
        nenner_truth = ...
            sqrt( abs( ((uh - simRB_N.uh.dofs)'*W*(uh - simRB_N.uh.dofs)) ));
        zaehler_truth = ...
            sqrt( abs( ((uh - simRB_N1.uh.dofs)'*W*(uh - simRB_N1.uh.dofs)) ));
        
        
        nenner_mod = ...
            sqrt( abs( ((simRB_N2.uh.dofs - simRB_N.uh.dofs)'*W*(simRB_N2.uh.dofs - simRB_N.uh.dofs)) ));
        zaehler_mod = ...
            sqrt( abs( ((simRB_N2.uh.dofs - simRB_N1.uh.dofs)'*W*(simRB_N2.uh.dofs - simRB_N1.uh.dofs)) ));
        nenner_mod2 = ...
            sqrt( abs( ((simRB_N1.uh.dofs - simRB_N.uh.dofs)'*W*(simRB_N1.uh.dofs - simRB_N.uh.dofs)) ));
        
        
        theta_truth(i) = zaehler_truth/nenner_truth;
        theta_mod(i) = zaehler_mod/nenner_mod;
        theta_mod2(i) = zaehler_mod/nenner_mod2;
    end
    
end


figure
set(gcf, 'Position', get(0, 'Screensize'));

h=plot(M_train,theta_truth,'b:',M_train,theta_mod,'g--',M_train,theta_mod2,'r','LineWidth',4,'MarkerSize',20);
xlabel('\mu')
le=legend({'$\Theta (\mu)$', ...
    '$\frac{\|u_{N+2}(\mu) - u_{N+1}(\mu)\|}{\|u_{N+2}(\mu) - u_{N}(\mu)\|}$', ...
    '$\frac{\|u_{N+2}(\mu) - u_{N+1}(\mu)\|}{\|u_{N+1}(\mu) - u_{N}(\mu)\|}$'},'interpreter','latex');
set(le,'FontSize',20,'Location','northwest');
set(h(1),'linewidth',4);
set(h(2),'linewidth',4);
set(h(3),'linewidth',4);


max(theta_truth)
%}

RB = detailed_data.RB;
dDN = detailed_data;
dDN1 = detailed_data;
dDN2 = detailed_data;

for N=1:5


dDN.RB = RB(:,1:N);
dDN1.RB = RB(:,1:N+1);

model.discrepancy=0;
rDN = model.gen_reduced_data(model,dDN);
rDN1 = model.gen_reduced_data(model,dDN1);

theta_truth = zeros(size(M_train));

for i = 1:length(M_train)
    flag = 1;
    mu = M_train(i);
    
    for j=1:length(SN)
        if norm(mu-SN(j))<1e-6
            flag = 0;
        end
    end
    
    if flag
        model = model.set_mu(model,mu);
        W = model.get_inner_product_matrix(detailed_data,model);
        sim_data = model.detailed_simulation(model,detailed_data);
        uh = sim_data.uh.dofs;
        
        rSN = rb_simulation(model, rDN);
        rSN1 = rb_simulation(model, rDN1);
        
        simRB_N = model.rb_reconstruction(model, detailed_data, rSN);
        simRB_N1 = model.rb_reconstruction(model, detailed_data, rSN1);
        
        nenner_truth = ...
            sqrt( abs( ((uh - simRB_N.uh.dofs)'*W*(uh - simRB_N.uh.dofs)) ));
        zaehler_truth = ...
            sqrt( abs( ((uh - simRB_N1.uh.dofs)'*W*(uh - simRB_N1.uh.dofs)) ));
        
        theta_truth(i) = zaehler_truth/nenner_truth;
    end
    
end

[val,ind] = max(theta_truth);
display(val)
mu_max = M_train(:,ind);

figure
set(gcf, 'Position', get(0, 'Screensize'));
set(gca,'FontSize',30)
h=plot(M_train,theta_truth,mu_max,val,'g*','LineWidth',4,'MarkerSize',20);
xlabel('\mu')
le=legend({'$\Theta (\mu)$'},'interpreter','latex');
set(le,'FontSize',20,'Location','northwest');
set(h(1),'linewidth',4);



end