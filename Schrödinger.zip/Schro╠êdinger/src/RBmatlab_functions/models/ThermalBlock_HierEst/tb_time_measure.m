close, clear, clc, filecache_clear;

%%

params.numintervals_per_block=36;
params.B1=3;
params.B2=3;

model = thermalblock_model_strong_greedy(params);

model.RB_extension_algorithm = @RB_ext;
model.get_rb_from_detailed_data = @(detailed_data)detailed_data.RB;
%model.orthonormalize = @orthonormalize_gram_schmidt;
model.orthonormalize = @orthonormalize_qr;


model.RB_stop_Nmax = 25;
model.RB_stop_epsilon=1e-4;

model_data = gen_model_data(model);
model_data.W = model_data.df_info.h10_inner_product_matrix;
model_data.W(model_data.df_info.dirichlet_gids,:)=[];
model_data.W(:,model_data.df_info.dirichlet_gids)=[];

detailed_data = model_data;

model.has_output_functional = 0;
model.compute_output_functional = 0;


model.RB_numintervals = [250;250];
model.mu_ranges = {[1/50 1] , [1/50 1]};

%Uniform 
% par.numintervals = model.RB_numintervals;
% par.range = model.mu_ranges;
% MMesh0 = cubegrid(par);
% detailed_data.RB_info.M_train = get(MMesh0,'vertex')';

%Logarithmic
par.numintervals = model.RB_numintervals;
par.range = model.mu_ranges;
for i = 1:length(par.range)
    par.range{i} = log(par.range{i});
end;
MMesh0 = cubegrid(par);
Mtrain_log = get(MMesh0,'vertex')';
detailed_data.RB_info.M_train = exp(Mtrain_log);

N_train = size(detailed_data.RB_info.M_train,2);



%% Start strong greedy:

detailed_data.RB = model.rb_init_data_basis(model,model_data);

first_mu = detailed_data.RB_info.M_train(:,1);
detailed_data.RB_info.mu_sequence = first_mu;
detailed_data.RB_info.max_err_sequence(1) = NaN;
model.use_scm = 0;

Nmax = 11;
error = zeros(Nmax+1,N_train);

model.decomp_mode = 0;

for n = 1:Nmax 
    
    reduced_data = model.gen_reduced_data(model,detailed_data);
    for i=1:N_train
        load(['/Users/Flad/Desktop/ThermalBlock3/uh_' num2str(i) '.mat']);
        model.mus = detailed_data.RB_info.M_train(:,i);
        
        rbs = model.rb_simulation(model,reduced_data);
        rbs = model.rb_reconstruction(model,detailed_data,rbs);
        uN = rbs.uh.dofs;
        error(n,i) = (uh-uN)'*(model_data.W*(uh-uN));
        
    end
    
    [val,ind] = max(error(n,:));
    val=val(1);
    ind = ind(1);
    
    next_mu = detailed_data.RB_info.M_train(:,ind);
    detailed_data.RB_info.mu_sequence(:,end+1) = next_mu;
    detailed_data.RB_info.max_err_sequence(:,end+1) = val;
    
    load(['/Users/Flad/Desktop/ThermalBlock3/uh_' num2str(ind) '.mat']);
    detailed_data.RB(:,end+1) = uh;
    
    detailed_data.RB = model.orthonormalize(detailed_data.RB,model_data.W);
    
    disp(n);
    
end

reduced_data = model.gen_reduced_data(model,detailed_data);
for i=1:N_train
    load(['/Users/Flad/Desktop/ThermalBlock3/uh_' num2str(i) '.mat']);
    model.mus = detailed_data.RB_info.M_train(:,i);
    
    rbs = model.rb_simulation(model,reduced_data);
    rbs = model.rb_reconstruction(model,detailed_data,rbs);
    uN = rbs.uh.dofs;
    error(n+1,i) = (uh-uN)'*(model_data.W*(uh-uN));
end



%% SCM:
% %% Ein mal die SCM:
% operator=@ (model) model.operators(model,model_data);
% innerproduct_matrix = model_data.W;
% % SCM properties
% params.Ma = inf;
% params.Mp = 0;
% params.ParameterSet = detailed_data.RB_info.M_train;
% params.NumberOfParameters = N_train;
% params.eps=1e-6;
% params.max_iterations=N_train;
% params.parallel=0;
% params.dirichlet_gids = [];
% params.type='coercive';
% 
% SCM_data=SCM(model,params,operator,innerproduct_matrix);