close, clear, clc, filecache_clear;

%%

params.numintervals_per_block=12;
params.B1=3;
params.B2=3;

model = thermalblock_model_strong_greedy(params);

model.RB_extension_algorithm = @RB_ext;
model.get_rb_from_detailed_data = @(detailed_data)detailed_data.RB;
model.orthonormalize = @orthonormalize_gram_schmidt;


model.RB_train_size = 5e4;
model.RB_train_rand_seed = 1500;
model.RB_stop_Nmax = 25;
model.RB_stop_epsilon=1e-4;

model_data = gen_model_data(model);
model_data.W = model_data.df_info.h10_inner_product_matrix;
model_data.W(model_data.df_info.dirichlet_gids,:)=[];
model_data.W(:,model_data.df_info.dirichlet_gids)=[];


model.has_output_functional = 0;
model.compute_output_functional = 0;

%%
% boundary box parameter:
hp_params.boundarybox = 0.25;
hp_params.boundarybox_minimum = 0.15;
hp_model=hp_gen_model_elliptic(model,hp_params);
%generate model data




%set the first anchor
hp_model = set_mu(hp_model,[1;1]);
%compute a h_refinment and RB generation
hp_model = hp_elliptic(hp_model,model_data);

hp_model = set_mu(hp_model,[0.13;0.13]);

%% Plot
%N_test = 5e3;
%truth_error_N = zeros(1,N_test);

%rand('state',hp_model.base_model.RB_train_rand_seed);
%mu_train = rand_uniform(N_test,...
%    hp_model.base_model.mu_ranges);

X=linspace(model.mu_ranges{1}(1),model.mu_ranges{1}(2),50);
[X,Y] = meshgrid(X,X);
mu_train = [X(:)' ; Y(:)'];
N_test = length(mu_train);
truth_error_N = zeros(1,N_test);

detailed_data = hp_model.tree.detailed_data;
reduced_data = hp_model.tree.reduced_data;

W = detailed_data.W;

dD = detailed_data;

NN = reduced_data.N;
RB = dD.RB;

for i=1:N_test
    display(i);
    model.mus = mu_train(:,i);
    sim = model.detailed_simulation(model,dD);
    uh = sim.uh.dofs;
    save(['/Users/flaeddi/Desktop/tmp2/uh_' num2str(i) '.mat'],'uh');
end


for N=1:NN

model.N = N;
dD.RB = RB(:,1:N);
reduced_data = model.gen_reduced_data(model,dD);

for i=1:N_test
    
    model.mus = mu_train(:,i);    
    %sim = model.detailed_simulation(model,dD);
    %uh = sim.uh.dofs;
    load(['/Users/flaeddi/Desktop/tmp2/uh_' num2str(i) '.mat']);
    rSN = rb_simulation(model,reduced_data);
    
    simRB_N = model.rb_reconstruction(model, dD, rSN);
    truth_error_N(i) = sqrt(abs((uh - simRB_N.uh.dofs)' * W *(uh - simRB_N.uh.dofs)));
end

figure
set(gcf, 'Position', get(0, 'Screensize'));

plot3(mu_train(1,:),mu_train(2,:),truth_error_N,'b*')
title(['Truth-Fehler f�r RB-L�sung der Dimension N=' num2str(N)])
xlabel('\mu_1')
ylabel('\mu_2')
zlabel('Error in H1-Norm ||u_h - u_N||_1')
legend('Truth-Fehler')
set(gca,'FontSize',20)

end
