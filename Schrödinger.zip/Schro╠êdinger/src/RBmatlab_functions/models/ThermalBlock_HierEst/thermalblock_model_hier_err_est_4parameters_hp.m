function model = thermalblock_model_hier_err_est_4parameters_hp(model)


model.operators = @operators;


% local data functions:
model = elliptic_discrete_model(model);

%hp-settings
%------------
model.distance_function = @euclidean_distance;
model.rb_init_data_basis = @thermalblock_init_data_basis;





%% For error estimator:
model.constant_for_error_estimator = @get_constant_for_error_estimator;

model.discrepancy = 1;

model.RB_stop_epsilon = 1e-5;

model.plot_estimator = 1;

model.get_constant_for_error_estimator = @get_constant_for_error_estimator;
model.compute_constant = 1;

model.reduced_data_subset = @reduced_data_subset;

%% Restliche Einstellungen
model.gen_model_data = @lin_stat_gen_model_data;
model.detailed_simulation = @lin_stat_detailed_simulation;
model.get_dofs_from_sim_data = @(sim_data)sim_data.uh.dofs;
model.use_scm = 0;
model.RB_error_indicator = 'estimator';

model.get_estimator_from_sim_data = @est_from_sim_data;
model.get_residual_for_basis_extension = @(sim_data) sim_data.reduced_data_M.res_norm_sqr;

model.gen_detailed_data = @lin_stat_gen_detailed_data_hier_err_est_hp;
model.set_rb_in_detailed_data = @lin_stat_set_rb_in_detailed_data;

model.gen_reduced_data = @stabilized_lin_stat_gen_reduced_data;

model.get_rb_size = @(model,detailed_data)size(detailed_data.RB,2);
model.get_rb_from_detailed_data=@(detailed_data)detailed_data.RB;


model.get_inner_product_matrix = ...
    @(detailed_data,model)detailed_data.W;

%model.rb_simulation= @lin_stat_rb_simulation;
model.rb_simulation= @stabilized_lin_stat_rb_simulation;
model.rb_reconstruction = @rb_reconstruction_without_femdiscfunc;
model.RB_extension_algorithm = @RB_ext;


model.filecache_ignore_fields_in_model = {'N','Nmax'};
model.filecache_ignore_fields_in_detailed_data = {'RB_info'};

end

%%%%%%% auxiliary functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function detailed_data = thermalblock_init_data_basis(model,detailed_data)

first_mu = detailed_data.RB_info.M_train(:,1);
%second_mu = detailed_data.RB_info.M_train(end);
model=model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);

reduced_data = model.gen_reduced_data(model,detailed_data);
%fct_temp = model.get_residual_for_basis_extension;
fct_temp = model.get_estimator_from_sim_data;
%model.get_residual_for_basis_extension = @(sim_data) log(sim_data.res_norm_sqr(end));
model.get_estimator_from_sim_data = @(sim_data) sim_data.res_norm_sqr(end);

model.N = 1;
post_errs = rb_test_indicator(model,...
    detailed_data, reduced_data,...
    detailed_data.RB_info.M_train,...
    []);


model.get_estimator_from_sim_data = fct_temp;


[~,ind] = max(post_errs);
second_mu = detailed_data.RB_info.M_train(:,ind);

model=model.set_mu(model,second_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,2) = model.get_dofs_from_sim_data(sim_data);


% Orthonormalisation of the Init-Data-Basis
W = detailed_data.W;
if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
    disp('orthogonalising the init values')
    u = model_orthonormalize_gram_schmidt(model, detailed_data ,u);
end

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);


detailed_data.RB_info.mu_sequence(:,1) = first_mu;
detailed_data.RB_info.mu_sequence(:,2) = second_mu;
end




function err = est_from_sim_data(sim_data,reduced_data)

uN = sim_data.uN;
uM = sim_data.reduced_data_M.uN;

rDM = reduced_data.reduced_data_M;

theta = reduced_data.theta;

err_temp = abs(uM'*rDM.WMM*uM + uN'*rDM.WNN*uN - ...
    uM'*rDM.WMN*uN - uN'*rDM.WNM*uM);


err = 1/(1-(theta+1e-6)) * (sqrt(err_temp) + reduced_data.sigma); 

end


function [A,r] = operators(model,model_data)
[A,r] = fem_operators(model,model_data);
if model.decomp_mode == 1
    ind = 1:model_data.df_info.ndofs;
    ind(model_data.df_info.dirichlet_gids)=[];
    for i=1:length(A)
        A{i} = A{i}(ind,ind);
    end
    for i=1:length(r)
        r{i} = r{i}(ind);
    end
end
if model.decomp_mode == 0
    ind = 1:model_data.df_info.ndofs;
    ind(model_data.df_info.dirichlet_gids)=[];
    A = A(ind,ind);
    r = r(ind);
end

end

