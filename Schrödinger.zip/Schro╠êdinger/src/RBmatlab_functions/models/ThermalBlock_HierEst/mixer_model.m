function [model,model_data] = mixer_model()

if ~exist('model_mixer.mat')
    dim = 3;
    
    %% Solve Steady Navier-Stokes equations using SUPG stabilized P1-P1 Finite Elements to compute the advection field
    femNS      = {'P1', 'P1'};
    [~,~,~]    = mkdir('Figures');
    [vertices, boundaries, elements] = msh_to_Mmesh( 'mesh/mixer_gmsh_3D_sym', dim);
    
    Advection_Field = NS_Solver(dim, elements, vertices, boundaries, femNS, 'mixerNS_data', [], 'Figures/AdvectionField');
    
    %% Set FE Space and load mesh
    fem      =  'P1';
    
    %% Generate Affine Full-Order Model
    [ model ] = build_affineFOM( elements, vertices, boundaries, fem, 'mixerADR_data', Advection_Field );
    
    %% Build Approximation of the Stability Factor (by RBF interpolation)
    model.stabFactor.mu_interp_index   = [4];
    model.stabFactor.interp_step       = [24];
    model.stabFactor.rbf_parfor        = 1;
    model.stabFactor.inf_sup           = 0;
    [model]                            = RBF_OfflineInterpolation(model);
    
    model_data = [];
    save model_mixer model
    
    %{
%% Generate Reduced-Order Model by Greedy Algorithm using n_train = 10000

% Define sample grid where to evaluate error estimate (here LHS design)
mu_train_Dimension = 10000;
mu_cube            = lhsdesign(mu_train_Dimension, FOM.P); % normalized design
mu_train           = bsxfun(@plus,FOM.mu_min,bsxfun(@times,mu_cube,(FOM.mu_max-FOM.mu_min)));

tolGREEDY          = 1e-4;
method             = 'Galerkin';%'LeastSquares'
Nmax               = 50;
mu_1               = [6 6 6 300];
t_g10000           = tic;
[ ROM_g10000 ]     = build_GREEDYbased_ROM(FOM, mu_train, tolGREEDY, mu_1, Nmax, method);
ROM_g10000.offline_time = toc(t_g10000);
save ROM_g10000 ROM_g10000;
    %}
    
else
    
    load('model_mixer.mat');
    model.orthonormalize = @model_orthonormalize_gram_schmidt;
    model.set_mu = @set_mu;
    model.get_mu = @(model) model.mus;
    model.mu_names = {'mus'};
    model.mu_ranges={[1,50],};
    mu_1 = [6 6 6 300];
    model = model.set_mu(model,mu_1);
    model.mu_ranges = { [model.mu_min(1),model.mu_max(1)], ...
        [model.mu_min(2),model.mu_max(2)], ...
        [model.mu_min(3),model.mu_max(3)], ...
        [model.mu_min(4),model.mu_max(4)]};
    model.RB_numintervals = [11,11,11,11];
    model.operators = @operators_mixer;
    model.decomp_mode = 0;
    
    model_data.operators.A = model.Aq;
    model=rmfield(model,'Aq');
    model_data.operators.r = model.Fq;
    model=rmfield(model,'Fq');
    model_data.W = model.Xnorm;
    
    %% Detailed Simulation:
    model.detailed_simulation=@sem_lin_stat_detailed_simulation;
    model.get_dofs_from_sim_data = @(sim_data) sim_data.uh.dofs;
    
    
    %% For RB:
    model.RB_generation_mode = 'model_RB_basisgen';
    model.RB_basisgen = @rb_basis_generation_with_hier_err_est;
    model.rb_init_data_basis = @mixer_init_data_basis;
    model.discrepancy = 1;
    
    model.filecache_ignore_fields_in_model = {'N','Nmax'};
    model.filecache_ignore_fields_in_detailed_data = {'RB_info'};
    
    model.RB_stop_Nmax = 50;
    model.RB_stop_epsilon = 1e-4;
    
    model.RB_error_indicator = 'estimator';
    
    model.get_estimator_from_sim_data = @est_from_sim_data;
    model.get_residual_for_basis_extension = @get_res;
    
    model.gen_detailed_data = @lin_stat_gen_detailed_data_hier_err_est;
    model.set_rb_in_detailed_data = @lin_stat_set_rb_in_detailed_data;
    
    model.gen_reduced_data = @stabilized_lin_stat_gen_reduced_data;
    
    model.get_rb_size = @(model,detailed_data)size(detailed_data.RB,2);
    model.get_rb_from_detailed_data=@(detailed_data)detailed_data.RB;
    
    
    model.get_inner_product_matrix = ...
        @(detailed_data,model)detailed_data.W;
    
    model.rb_simulation= @stabilized_lin_stat_rb_simulation;
    model.rb_reconstruction = @rb_reconstruction_without_femdiscfunc;
    model.RB_extension_algorithm = @RB_ext;
    model.save_detailed_simulations = @save_detailed_simulations;
    model.RB_detailed_train_savepath='';
    model.rb_problem_type = 'lin_stat';
    model.compute_output_functional = 0;
    model.debug = 0;
    model.reduced_data_subset = @reduced_data_subset;
    model.error_algorithm = @err_alg;
    model.verbose = 25;
    model.inner_product=@(model,model_data,vecs1,vecs2)vecs1'*model_data.W*vecs2;
    model.use_scm = 0;
    model.RB_detailed_train_savepath='';
    
    model.derivative_coeff = @derivative_coeff;
    
    model.compute_derivative = @compute_derivative;
    
    
end


end





function model = set_mu(model,mu)
    model.mus = mu(:);
end

function [A,r] = operators_mixer(model,model_data)

if model.decomp_mode == 0
    mu = model.get_mu(model); mu = mu(:);
    [Acoeff,rcoeff] = evaluate_ThetaFunctions(mu');
    A = lincomb_sequence(model_data.operators.A,Acoeff);
    r = lincomb_sequence(model_data.operators.r,rcoeff);
end

if model.decomp_mode == 1
    A = model_data.operators.A;
    r = model_data.operators.r;
end

if model.decomp_mode == 2
    mu = model.get_mu(model); mu = mu(:);
    [A,r] = evaluate_ThetaFunctions(mu');
    A=A(:); r=r(:);
end

end



function detailed_data = mixer_init_data_basis(model,detailed_data)
%{
first_mu = [6 6 6 300];
first_mu = zeros(length(model.mu_ranges),1);
for i=1:length(model.mu_ranges)
    first_mu(i) = 0.5*(model.mu_ranges{i}(1) + model.mu_ranges{i}(2) );
end
%}
first_mu = detailed_data.RB_info.M_train(:,1);

model=model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);

detailed_data.RB_info.mu_sequence(:,1) = first_mu;

for j=1:model.discrepancy
    
    reduced_data = model.gen_reduced_data(model,detailed_data);
    fct_temp = model.get_estimator_from_sim_data;
    model.get_estimator_from_sim_data = @(sim_data) sim_data.res_norm_sqr(end);
    
    model.N = j;
    post_errs = rb_test_indicator(model,...
        detailed_data, reduced_data,...
        detailed_data.RB_info.M_train,...
        []);
    
    
    model.get_estimator_from_sim_data = fct_temp;
    
    
    [max_res,ind] = max(post_errs);
    detailed_data.RB_info.max_residual_sequence(j) = max_res;
    next_mu = detailed_data.RB_info.M_train(:,ind);
    
    model=model.set_mu(model,next_mu);
    sim_data = detailed_simulation(model,detailed_data);
    u(:,j+1) = model.get_dofs_from_sim_data(sim_data);
    
    
    % Orthonormalisation of the Init-Data-Basis
    W = detailed_data.W;
    if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
        disp('orthogonalising the init values')
        u = model.orthonormalize(model, detailed_data ,u);
    end
    
    detailed_data = model.set_rb_in_detailed_data(...
        detailed_data,...
        u);
    
    
    detailed_data.RB_info.mu_sequence(:,j+1) = next_mu;
    
    
    %{
    % Vorbereitung f�r eventuellen Snapshotwechsel:
    model.compute_constant = 0;
    reduced_data = gen_reduced_data(model,detailed_data);
    reduced_data.theta = 0;
    reduced_data.sigma = 0;
    
    a_post_errors = get_hier_err_est(model, ...
        detailed_data, reduced_data,...
        detailed_data.RB_info.M_train); %+ get_residuals(model, ...
    %detailed_data, reduced_data,...
    %detailed_data.RB_info.M_train)./model.infsup_lb; %Zeile ver�ndert!!!
    
    [max_a_post_errors, mu_indices] = max(a_post_errors);
    max_a_post_error             = max_a_post_errors(1);
    mu_indice = mu_indices(1);
    mu = detailed_data.RB_info.M_train(:,mu_indice);
    
    if norm(mu-detailed_data.RB_info.mu_sequence(:,end))>eps
        disp('Changing the last Snapshot!');
        disp(mu)
        disp(max_a_post_error)
        model.mus = mu;
        sim_data = model.detailed_simulation(model,detailed_data);
        detailed_data.RB(:,end) = sim_data.uh.dofs;
        
        W = detailed_data.W;
        if(max(max(abs(detailed_data.RB'*W*detailed_data.RB)-eye(size(detailed_data.RB,2))))>1e-12)
            disp('orthogonalising the init values')
            detailed_data.RB = model.orthonormalize(model, detailed_data, detailed_data.RB);
        end
        detailed_data.RB_info.mu_sequence(:,end) = mu;
    end
    %}
    
    
end

end



function res = get_res(sim_data)
    res = sim_data.reduced_data_M.res_norm_sqr;
    if res < eps
        res = 0;
    end
end


function err = est_from_sim_data(sim_data,reduced_data)

uN = sim_data.uN;
uM = sim_data.reduced_data_M.uN;

rDM = reduced_data.reduced_data_M;

theta = reduced_data.theta;

err_temp = abs(uM'*rDM.WMM*uM + uN'*rDM.WNN*uN - ...
    uM'*rDM.WMN*uN - uN'*rDM.WNM*uM);

err = 1/(1-(theta)) * (sqrt(err_temp));

end



function [Da,Df] = derivative_coeff(model,k)

old_mode = model.decomp_mode;
model.decomp_mode = 2;
[A,f] = model.operators(model,[]);
%mu=model.get_mu(model);
mu = model.mus;
P = length(mu);

Na = length(A);
Nf = length(f);

Df = zeros(Nf,P);
Da = zeros(Na,P);

mu4 =  ( ((-1)^k)*factorial(k) )/(mu(4)^(k+1));

if k==1
    Df(1,1) = 1/mu(4);
    Df(2,2) = 1/mu(4);
    Df(3,3) = 1/mu(4);
    Df(4,1) = 1;
    Df(5,2) = 1;
    Df(6,3) = 1;
end

Df(1,4) = mu(1)*mu4;
Df(2,4) = mu(2)*mu4;
Df(3,4) = mu(3)*mu4;


Da(1,4) = mu4;



model.decomp_mode = old_mode;
end



function U = compute_derivative(model,model_data,K,u)

% binomial coefficient
%nchoosek(n,k);
P = length(model.mus);
n = length(u);


for k=1:K+1
    U{k} = zeros(n,P);
end

old_mode = model.decomp_mode;
model.decomp_mode = 1;
[Acomp,fcomp] = model.operators(model,model_data);
Qf = length(fcomp);
Qa = length(Acomp);

model.decomp_mode = 0;
[A,~] = model.operators(model,model_data);




for k=1:K
        [Da_temp,Df_temp] = model.derivative_coeff(model,k);
        Da{k} = Da_temp; 
        Df{k} = Df_temp;
end




for p=1:P
    % "zero-th" derivative in the first cell
    U{1}(:,p) = u;
    r = zeros(n,1);
    AA = zeros(n,1);
    for q =1:Qf
        r = r + Df{1}(q,p)*fcomp{q};
    end
    for q = 1:Qa
        AA = AA + Da{1}(q,p)*(Acomp{q}*u);
    end
    % "first" derivative in the second cell
    U{2}(:,p) = A \ (r - AA);
end



for k=2:K
    for p=1:P
        
        r = zeros(n,1);
        AA = zeros(n,1);
        
        for q = 1:Qf
            r = r + Df{k}(q,p)*fcomp{q};
        end
    
        for l=1:k
            for q = 1:Qa
                AA = AA+nchoosek(k,l)*Da{l}(q,p)*(Acomp{q}*U{k-l+1}(:,p));
            end
        end
        
        U{k+1}(:,p) = A \ (r-AA);
        
    end
end

model.decomp_mode = old_mode;
end