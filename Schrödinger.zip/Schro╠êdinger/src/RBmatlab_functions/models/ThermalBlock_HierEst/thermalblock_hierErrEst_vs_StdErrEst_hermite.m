clear, close, clc;

%% Make the model data and save the detailed simulations:

params.numintervals_per_block = 36;
params.B1 = 3;
params.B2 = 3;

model = thermalblock_model_strong_greedy(params);

model.RB_extension_algorithm = @RB_ext;
model.get_rb_from_detailed_data = @(detailed_data)detailed_data.RB;
%model.orthonormalize = @orthonormalize_gram_schmidt;
%model.orthonormalize = @model_orthonormalize_qr;

model.orthonormalize=@model_orthonormalize_gram_schmidt;

model.RB_stop_Nmax = 10;
model.RB_stop_epsilon=1e-4;

model_data = gen_model_data(model);
model_data.W = model_data.df_info.h10_inner_product_matrix;
model_data.W(model_data.df_info.dirichlet_gids,:)=[];
model_data.W(:,model_data.df_info.dirichlet_gids)=[];

detailed_data = model_data;

model.has_output_functional = 0;
model.compute_output_functional = 0;


model.RB_numintervals = [250;250];
model.mu_ranges = {[0.5 1] , [0.5 1]};

%Uniform 
% par.numintervals = model.RB_numintervals;
% par.range = model.mu_ranges;
% MMesh0 = cubegrid(par);
% detailed_data.RB_info.M_train = get(MMesh0,'vertex')';

%Logarithmic
par.numintervals = model.RB_numintervals;
par.range = model.mu_ranges;
for i = 1:length(par.range)
    par.range{i} = log(par.range{i});
end;
MMesh0 = cubegrid(par);
Mtrain_log = get(MMesh0,'vertex')';
detailed_data.RB_info.M_train = exp(Mtrain_log);



%% Strong Greedy:
N_train = size(detailed_data.RB_info.M_train,2);

flag_dir = 0;
if flag_dir
    for i=1:N_train
        model.mus = detailed_data.RB_info.M_train(:,i);
        sim = model.detailed_simulation(model,model_data);
        uh = sim.uh.dofs;
        save(['/Users/numerik/Desktop/ThermalBlock_Snapshots_0.5_1/uh_' num2str(i) '.mat'],'uh');
        disp(i);
    end
end






%% first_mu = detailed_data.RB_info.M_train(:,1);
first_mu = detailed_data.RB_info.M_train(:,1); 

model = model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,detailed_data);
u = model.get_dofs_from_sim_data(sim_data);

detailed_data.RB_info.mu_sequence(:,1) = first_mu;

% Now compute derivative and generate X_M
du_dmu = model.compute_derivative(model,model_data,2,u);

U = u;
%dU_dmu = [du_dmu{2}];
dU_dmu = [du_dmu{2} du_dmu{3}];
%dU_dmu = [du_dmu{2} du_dmu{3} du_dmu{4}];

detailed_data.RB = model.orthonormalize(model, detailed_data, u);

Ntrain = size(detailed_data.RB_info.M_train,2);
%model.compute_constant = 0;


%% Strong Greedy:
filename = '/Users/numerik/Desktop/ThermalBlock_Snapshots_0.5_1';

if ~isdir(filename)
    mkdir(filename);
    flag_dir = 0;
else
    flag_dir = 1;
end

Nmax = 6;
error = zeros(Nmax,Ntrain);
residuals = zeros(Nmax+1,Ntrain);
nenner_quadriert = zeros(Nmax,Ntrain);
nenner = zeros(Nmax,Ntrain);
zaehler_quadriert = zeros(Nmax,Ntrain);
zaehler = zeros(Nmax,Ntrain);
hier_err = zeros(Nmax,Ntrain);
theta_sequence = zeros(1,Nmax);
INFSUP = zeros(1,Ntrain);
model.discrepancy = 0;
detailed_data_M = detailed_data;

M = zeros(Nmax,4);

for j=1:Nmax
    U_orth = model.orthonormalize(model, detailed_data ,U);
    detailed_data.RB = U_orth;
    reduced_data = model.gen_reduced_data(model,detailed_data);
    V = POD_basis_computation([U dU_dmu], model_data.W, 1e-12);
    V_orth = model.orthonormalize(model, detailed_data ,V);
    detailed_data_M.RB = V_orth;
    reduced_data_M = model.gen_reduced_data(model,detailed_data_M);
    
    for i=1:Ntrain
        fN = [filename '/uh_' num2str(i)];
        mu = detailed_data.RB_info.M_train(:,i);
        model = model.set_mu(model,mu);
        
        if flag_dir
            load(fN);
        else
            sim_data = model.detailed_simulation(model,model_data);
            uh = sim_data.uh.dofs;
            save(fN,'uh');
        end
        
        rSN = rb_simulation(model, reduced_data);
        simRB_N = model.rb_reconstruction(model, detailed_data, rSN);
        uN = simRB_N.uh.dofs;
        
        %residuals(j,i) = simRB_N.res_norm;
        
        %[A,~] = model.operators(model,model_data);
        %INFSUP(j,i) = get_infsup(model,A, model_data.W);
        
        rSM = rb_simulation(model, reduced_data_M);
        simRB_M = model.rb_reconstruction(model, detailed_data_M, rSM);
        uM = simRB_M.uh.dofs;
        
        nenner_quadriert(j,i) = ((uh-uN)'*(detailed_data.W*(uh-uN)));
        nenner(j,i) = real(sqrt(nenner_quadriert(j,i)));
        
        zaehler_quadriert(j,i) = ((uh-uM)'*(detailed_data.W*(uh-uM)));
        zaehler(j,i) = real(sqrt(zaehler_quadriert(j,i)));
        
        hier_err(j,i) = real(sqrt((uM-uN)'*(detailed_data.W*(uM-uN))));
    end
    
    %[val_strong,next_mu_ind_strong] = max(nenner(j,:)); %Strong-Greedy
    %[val_res,next_mu_ind_res] = max(residuals(j,:)./INFSUP(j,:)); %Basisgen: Residual
    [val_hier,next_mu_ind_hier] = max(hier_err(j,:)); %Sampling mit Hier
    
    %fN = [filename '/uh_' num2str(next_mu_ind_strong(1))];
    %next_mu = detailed_data.RB_info.M_train(:,next_mu_ind_strong(1));
    %load(fN);
    
    %fN = [filename '/uh_' num2str(next_mu_ind_res(1))];
    %next_mu = detailed_data.RB_info.M_train(:,next_mu_ind_res(1));
    %load(fN);
    
    fN = [filename '/uh_' num2str(next_mu_ind_hier(1))];
    next_mu = detailed_data.RB_info.M_train(:,next_mu_ind_hier(1));
    load(fN);

    model = model.set_mu(model,next_mu);
    
    du_dmu = model.compute_derivative(model,model_data,2,uh);
    
    %dU_dmu = [dU_dmu du_dmu{2}];
    dU_dmu = [dU_dmu du_dmu{2} du_dmu{3}];
    %dU_dmu = [dU_dmu du_dmu{2} du_dmu{3} du_dmu{4}];
    
    U(:,end+1) = uh;
    %dU_dmu = [dU_dmu du_dmu];
    
    detailed_data.RB_info.mu_sequence(:,j+1) = next_mu;
    
    ind=find(nenner(j,:)>1e-8);
    theta_sequence(j) = max(zaehler(j,ind)./nenner(j,ind));
    
    [mean_err, mean_std, mean_hier] = ...
        TB_av_err(model,model_data,detailed_data, detailed_data_M, reduced_data, reduced_data_M, theta_sequence(j));
    
    M(j,1) = j;
    M(j,2) = mean_err;
    M(j,3) = mean_std;
    M(j,4) = mean_hier;
    
    flag_dir = 1;
    disp(j)
    
end

header = {'N','err','std','hier'};

disp('Basisgen done!');




%% Plot
Nmax = size(M,1);
figure
set(gcf, 'Position', get(0, 'Screensize'));
h = semilogy(1:Nmax,M(:,4),'g--', ...
1:Nmax,M(:,3),'b', ...
1:Nmax,M(:,2),'r:', ...
'LineWidth',8,'MarkerSize',20);
title({'Thermalblock $\mathcal{P} = [0.5,1] \times [0.5,1]$ - Average Error (Taylor-Basis for $X_M$ with two derivatives)'},'interpreter','Latex')
xlabel({'$N =$ dim$(X_N)$'},'interpreter','Latex')
ylabel({'Error in $H^1$-Norm'},'interpreter','Latex')
le=legend({'$\left( \sum_{i=1}^{N_{\mathrm{test}}} \Delta_{N,M} (\mu_i) \right) / N_{\mathrm{test}} $', ...
'$\left( \sum_{i=1}^{N_{\mathrm{test}}} \Delta_N^{\mathrm{Std}} (\mu_i ) \right) / N_{\mathrm{test}}$' ...
'$ \left( \sum_{i=1}^{N_{\mathrm{test}}} \|u^\mathcal{N} ( \mu_i) - u_N ( \mu_i)\|_{X^\mathcal{N}} \right) / N_{\mathrm{test}}$'},'interpreter','latex');
set(le,'FontSize',30,'Location','northeast');
grid on
set(h(1),'linewidth',8);
set(h(2),'linewidth',8);
set(h(3),'linewidth',8);
set(gca,'FontSize',30);
set(gca,'Xtick',1:Nmax);


%% Save File
filename = [filename '/data'];
save(filename);


%% Plot Theta
figure
plot(theta_sequence,'ro-','linewidth',4)
title({'Evolution of $\Theta_{N,M}$ (two derivatives)'},'interpreter','Latex')
xlabel({'$N$'},'interpreter','Latex')
ylabel({'$\Theta_{N,M}$'},'interpreter','Latex')
set(gca,'Fontsize',42)
grid on