clear, close, clc;

load('data_strong')

Nmax = size(detailed_data.RB,2);
RB_temp = detailed_data.RB;

operator=@ (model) model.operators(model,model_data);

%% SCM laden
for j = 3
    if j==1
        data = load('/Users/Flad/Desktop/tb_scm.mat');
        
        ind = find(data.SCM_data.eta_sequence < 1e-1);
        ind = ind(1);
        
        data.SCM_data.C.ParameterVector = data.SCM_data.C.ParameterVector(1:ind,:);
        data.SCM_data.C.infsup = data.SCM_data.C.infsup(1:ind);
        data.SCM_data.C.Set = data.SCM_data.C.Set(1:ind);
        data.SCM_data.C.UBVector = data.SCM_data.C.UBVector(:,1:ind);
        
        detailed_data.scm_offline_data = data.SCM_data;
        clear data;
    end
    if j==2
        data = load('/Users/Flad/Desktop/tb_scm.mat');
        
        ind = find(data.SCM_data.eta_sequence < 1e-3);
        ind = ind(1);
        
        data.SCM_data.C.ParameterVector = data.SCM_data.C.ParameterVector(1:ind,:);
        data.SCM_data.C.infsup = data.SCM_data.C.infsup(1:ind);
        data.SCM_data.C.Set = data.SCM_data.C.Set(1:ind);
        data.SCM_data.C.UBVector = data.SCM_data.C.UBVector(:,1:ind);
        
        
        detailed_data.scm_offline_data = data.SCM_data;
        clear data;
    end
    if j==3
        data = load('/Users/Flad/Desktop/tb_scm.mat');
        detailed_data.scm_offline_data = data.SCM_data;
        clear data;
    end
    
    %% Test set and compare:
    for d=1:3
        
        model.discrepancy = d;
        
        Ntest = 1000; %100 random "sample points"
        zaehler_quadriert = zeros(Nmax-d,Ntest);
        nenner_quadriert = zeros(Nmax-d,Ntest);
        zaehler = zeros(Nmax-d,Ntest);
        nenner = zeros(Nmax-d,Ntest);
        Norm = zeros(Nmax-d,Ntest);
        hier_err = zeros(Nmax-d,Ntest);
        res = zeros(Nmax-d,Ntest);
        infsup = zeros(Nmax-d,Ntest);
        
        mean_time_res = zeros(1,Nmax-d);
        mean_time_hier = zeros(1,Nmax-d);
        
        eta_hier = zeros(1,Nmax-d);
        eta_std = zeros(1,Nmax-d);
        
        theta_sequence = zeros(1,Nmax-d);
        model.decomp_mode = 0;
        model.use_scm = 0;
        
        res_time = zeros(Nmax-d,Ntest);
        infsup_time = zeros(Nmax-d,Ntest);
        hier_time = zeros(Nmax-d,Ntest);
        uM_time = zeros(Nmax-d,Ntest);
        
        for N = 1:Nmax-d
            
            detailed_data.RB = RB_temp(:,1:N+d);
            reduced_data = model.gen_reduced_data(model,detailed_data);
            
            ind = find(error(N,:)>1e-12);
            theta = error(N+d,ind)./error(N,ind);
            THETA = sqrt(max(theta));
            theta_sequence(N) = THETA;
            
            M_test = rand_uniform(Ntest, model.mu_ranges);
            
            for i=1:Ntest
                mu = M_test(:,i);
                model = model.set_mu(model,mu);
                
                sim_data = model.detailed_simulation(model,model_data);
                uh = model.get_dofs_from_sim_data(sim_data);
                
                rSN = rb_simulation(model, reduced_data);
                simRB_N = model.rb_reconstruction(model, detailed_data, rSN);
                uN = simRB_N.uh.dofs;
                
                res(N,i) = real(simRB_N.res_norm);
                
                res_time(N,i) = rSN.res_norm_time;
                
                tic
                infsup(N,i) = scm_coercive_lb(mu,model,operator,detailed_data.scm_offline_data);
                infsup_time(N,i) = toc;
                
                rSM = rb_simulation(model, reduced_data.reduced_data_M);
                uM_time(N,i) = rSM.uN_time;
                
                nenner_quadriert(N,i) = ((uh-uN)'*(detailed_data.W*(uh-uN)));
                nenner(N,i) = real(sqrt(nenner_quadriert(N,i)));
                
                uN = rSN.uN;
                uM = rSM.uN;
                
                tic
                hier_err(N,i) = sqrt(abs(uM'*reduced_data.reduced_data_M.WMM*uM - ...
                    uM'*reduced_data.reduced_data_M.WMN*uN - ...
                    uN'*reduced_data.reduced_data_M.WNM*uM + ...
                    uN'*reduced_data.reduced_data_M.WNN*uN))/(1-THETA);
                
                hier_time(N,i) = toc;
                
            end
            
            disp(N)
            mean_time_res(N) = sum(res_time(N,:)+infsup_time(N,:))/Ntest;
            mean_time_hier(N) = sum(hier_time(N,:) + uM_time(N,:))/Ntest;
            
            std_err_est = res(N,:)./infsup(N,:);
            
            eta_std(N) = sum(std_err_est./nenner(N,:))/Ntest;
            eta_hier(N) = sum(hier_err(N,:)./nenner(N,:))/Ntest;
            
        end
        
        if j==1
            save(['/Users/Flad/Desktop/tb_time/scm_1e-1_M=N+' num2str(d) '.mat']);
        end
        if j==2
            save(['/Users/Flad/Desktop/tb_time/scm_1e-3_M=N+' num2str(d) '.mat']);
        end
        if j ==3
            save(['/Users/Flad/Desktop/tb_time/scm_1e-6_M=N+' num2str(d) '.mat']);
        end
        
    end
    
    
end