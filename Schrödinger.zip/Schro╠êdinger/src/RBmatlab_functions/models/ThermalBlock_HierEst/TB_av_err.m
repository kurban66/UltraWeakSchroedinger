function [mean_err , mean_std, mean_hier] = TB_av_err(model, model_data, detailed_data, detailed_data_M, reduced_data, reduced_data_M, theta)

Ntest = 100; %100 random "sample points"
nenner_quadriert = zeros(1,Ntest);
nenner = zeros(1,Ntest);
hier_err = zeros(1,Ntest);
res = zeros(1,Ntest);
coer = zeros(1,Ntest);

model.decomp_mode = 0;

M_test = rand_uniform(100, model.mu_ranges);


opts.tol = 1e-8;
opts.maxit=1e3;

for i=1:Ntest
    mu = M_test(:,i);
    model = model.set_mu(model,mu);

    sim_data = model.detailed_simulation(model,model_data);
    uh = model.get_dofs_from_sim_data(sim_data);

    rSN = rb_simulation(model, reduced_data);
    simRB_N = model.rb_reconstruction(model, detailed_data, rSN);
    uN = simRB_N.uh.dofs;
    
    res(i) = real(simRB_N.res_norm);
    
    [A,~] = model.operators(model,model_data);
    coer(i) = eigs(A,model_data.W,1,'sm',opts);
    
    
    rSM = rb_simulation(model, reduced_data_M);
    simRB_M = model.rb_reconstruction(model, detailed_data_M, rSM);
    uM = simRB_M.uh.dofs;
    
    nenner_quadriert(i) = ((uh-uN)'*(detailed_data.W*(uh-uN)));
    nenner(i) = real(sqrt(nenner_quadriert(i)));
    
    hier_err(i) = real(sqrt((uM-uN)'*(detailed_data.W*(uM-uN))));
    
end

mean_err = sum( nenner )/Ntest;
mean_hier = sum( hier_err/(1-theta) )/Ntest;
mean_std = sum( res./coer )/Ntest;

