function scm_coercive_test(model,detailed_data)
operator=@ (model) model.operators(model,detailed_data);

innerproduct_matrix = model.get_inner_product_matrix(detailed_data);

SCM_data=detailed_data.scm_offline_data;


Ntest = 157;
rmserror=0;
maderror = 0;
mu_train = rand_uniform(Ntest,model.mu_ranges);

LB = zeros(1,Ntest);
UB = zeros(1,Ntest);
alpha = zeros(1,Ntest);

fprintf('Results:\ninfsup constant      upper bound       lower bound (scm infsup constant)     mu \n');
for i = 1:Ntest
    %mu = rand_uniform(1,model.mu_ranges);
    mu = mu_train(:,i);
    model = set_mu(model,mu);
    model.decomp_mode=0;
    [A,~] =  model.operators(model,detailed_data);
    
    %try
    %    [~,c] = fast_eigs( A,innerproduct_matrix,'sm' );
    %catch err
    %    try
    %        [~,c] = eigs( A,innerproduct_matrix,1,'sm' );
    %    catch err2
    %        warning('full spectrum needed, since eigs did not converged');
            [~,c] = eig( full(A),full(innerproduct_matrix) );
            c=min(diag(c));
    %    end
    %end
    
    alpha_UB =  SCMonline_complex(mu,model,operator,SCM_data,'ub');
    alpha_LB = SCMonline_complex(mu,model,operator,SCM_data,'lb');
    
    
    alpha(i) = sqrt(c);
    LB(i) = sqrt(alpha_LB);
    UB(i) = sqrt(alpha_UB);
    
    fprintf('%f             %f          %f                              %f \n',c,alpha_UB,alpha_LB,0);
    
    rmserror = rmserror+(c-alpha_LB).^2;
    maderror = maderror + abs(c-alpha_LB);
end
rmserror = sqrt(rmserror/Ntest);
maderror = maderror/Ntest;
display(rmserror)
display(maderror)



    
%{
    %N = length(detailed_data.scm_offline_data.C.infsup);
    ind1=[1 5:15:length(mu_train)];
    ind2=[1 10:15:length(mu_train)];
    ind3=[1 15:15:length(mu_train)];

    figure
    set(gcf, 'Position', get(0, 'Screensize'));
    
    h=plot(mu_train,alpha,'r^',mu_train,LB,'b*',mu_train,UB,'gs');
    %hold on;
    %g=plot(mu_train(ind1),beta(ind1),'ro',mu_train(ind2),LB(ind2),'b*',mu_train(ind3),UB(ind3),'gs','MarkerSize',20);
    title('SCM Lower and Upper Bound')
    xlabel('\mu')
    l=legend({'$\beta(\mu)$','$\beta^{\mathrm{LB}} (\mu)$', '$\beta^{\mathrm{UB}} (\mu)$'},'interpreter','latex');
    set(l,'FontSize',30,'Location','northeast');
    set(gca,'FontSize',50)
    set(h(1),'linewidth',6,'MarkerIndices',ind1,'MarkerSize',10);
    set(h(2),'linewidth',4,'MarkerIndices',ind2,'MarkerSize',20);
    set(h(3),'linewidth',4,'MarkerIndices',ind3,'MarkerSize',20);
    keyboard;
%}
end

