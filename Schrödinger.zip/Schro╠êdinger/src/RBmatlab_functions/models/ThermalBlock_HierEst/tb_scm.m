%% SCM:

for eps = 1e-6

operator=@ (model) model.operators(model,model_data);
innerproduct_matrix = model_data.W;
params.Ma = inf;
params.Mp = 0;
params.ParameterSet = detailed_data.RB_info.M_train;
params.NumberOfParameters = N_train;
params.eps=eps;
params.max_iterations=N_train;
params.parallel=0;
params.dirichlet_gids = [];
params.type='coercive';
 

tic
SCM_data=SCM(model,params,operator,innerproduct_matrix);
SCM_data.time = toc;

%FN = ['/Users/Flad/Desktop/thermalblock_data_scm_eps=' num2str(eps)];
%save(FN,'SCM_data');

end