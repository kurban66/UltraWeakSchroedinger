close, clear, clc, filecache_clear;

%%

params.numintervals_per_block = 25;
params.B1=3; params.B2=3;

model = thermalblock_model_hier_err_est_hp(params);

model.RB_extension_algorithm = @RB_ext;
model.get_rb_from_detailed_data = @(detailed_data)detailed_data.RB;
model.orthonormalize = @orthonormalize_qr;


model.RB_train_size = 5e4;
model.RB_train_rand_seed = 1500;
model.RB_stop_Nmax = 20;
model.RB_stop_epsilon = 1e-4; 

model_data = gen_model_data(model);
model_data.W = model_data.df_info.h10_inner_product_matrix;
model_data.W(model_data.df_info.dirichlet_gids,:)=[];
model_data.W(:,model_data.df_info.dirichlet_gids)=[];


model.has_output_functional = 0;
model.compute_output_functional = 0;


%% HP - method
% boundary box parameter:
hp_params.boundarybox = 0.25;
hp_params.boundarybox_minimum = 0.15;
hp_model=hp_gen_model_elliptic(model,hp_params);
%generate model data


%set the first anchor
hp_model = set_mu(hp_model,[1;1]);
%compute a h_refinment and RB generation
hp_model = hp_elliptic(hp_model,model_data);

hp_model = set_mu(hp_model,[0.13;0.13]);
