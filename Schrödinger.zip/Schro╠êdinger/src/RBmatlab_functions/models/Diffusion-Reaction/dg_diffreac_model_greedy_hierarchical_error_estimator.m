function model = dg_diffreac_model_greedy_hierarchical_error_estimator(params)

%% name of the model
model.name = 'DiffReac';

%% Dimension of the PDE-Equations
if ~isfield(params,'dimrange')
    model.dimrange=1;
else
    model.dimrange=params.dimrange;
end

%% Useful constants for the dg-method
model.dg.constants.epsilon = -1;
model.dg.constants.sigma0 = 0.0001;
model.dg.constants.sigma1 = 0;

%% define auxiliary properties for the grid
if ~isfield(params,'xrange')
    model.xrange=[0,1];
else
    model.xrange=params.xrange;
end

if ~isfield(params,'xnumintervals')
    model.xnumintervals=10;
else
    model.xnumintervals=params.xnumintervals;
end

model.gridtype = 'onedgrid';

if ~isfield(params,'pdeg')
    model.pdeg = 2*ones(model.xnumintervals,1);
else
    model.pdeg = params.pdeg.*ones(model.xnumintervals,1);
end

%% Others
model.gen_model_data = @dg_stat_gen_model_data;

%% dg-fem-function-handle
model.decomp_mode=0;
model.operators = @dg_operators;

model.has_diffusivity = 1;
model.has_advection = 0;
model.has_reaction = 1;

model.has_source = 1;
model.has_output_functional = 0;
model.has_dirichlet_values = 1;
model.has_neumann_values = 0;
model.has_robin_values = 0;

% Diffusion:
diffusivity_coefficients = @(dummy,params) 1;
diffusivity_components = @(glob,params) ...
    {ones(length(glob),1)};
model.diffusivity = @(glob,params) ...
    eval_affine_decomp_general(...
    diffusivity_components, ...
    diffusivity_coefficients, glob,params);


% Advection:
advection_coefficients = @(dummy,params) 1;
advection_components = @(glob,params) ...
    {cos(glob)};
model.advection = @(glob,params) ...
    eval_affine_decomp_general(...
    advection_components, ...
    advection_coefficients, glob,params);


% Reaction:
reaction_coefficients = @(dummy,params) +params.mus.^2;
reaction_components = @(glob,params) ...
    {ones(length(glob),1)};
model.reaction = @(glob,params) ...
    eval_affine_decomp_general(...
    reaction_components, ...
    reaction_coefficients, glob,params);


% Source Term:
source_coefficients = @(dummy,params) 1;
source_components = @(glob,params) ...
    {ones(length(glob),1)};
model.source = @(glob,params) ...
    eval_affine_decomp_general(...
    source_components, ...
    source_coefficients, glob,params);

% Dirichlet Boundary-Term:
dir_coefficients = @(dummy,params) 1;
dir_components = @(glob,params) ...
    {zeros(length(glob),1)};
model.dirichlet = @(glob,params) ...
    eval_affine_decomp_general(...
    dir_components, ...
    dir_coefficients, glob,params);


% Neumann Boundary-Term:
neumann_coefficients = @(dummy,params) [params.mus(1);params.mus(2)];
neumann_components = @(glob,params) ...
    {-sin(glob).*exp(-glob),-cos(glob).*exp(-glob)};
model.neumann = @(glob,params) ...
    eval_affine_decomp_general(...
    neumann_components, ...
    neumann_coefficients, glob,params);


% Robin Boundary-Term:
robin_g_coefficients = @(dummy,params) 1;
robin_g_components = @(glob,params) ...
    {zeros(length(glob),1)};
model.robin_g = @(glob,params) ...
    eval_affine_decomp_general(...
    robin_g_components, ...
    robin_g_coefficients, glob,params);

robin_beta_coefficients = @(dummy,params) params.mus;
robin_beta_components = @(glob,params) ...
    {1i*ones(length(glob),1)};
model.robin_beta = @(glob,params) ...
    eval_affine_decomp_general(...
    robin_beta_components, ...
    robin_beta_coefficients, glob,params);


%% For the boundary terms:
model.boundary_type = @helmholtz_boundary_type;
model.reconstruct_dirichlet = @reconstruct_dirichlet;


%% For the parameters:
model.mu_names = {'wavenumber'};
model.mus = 5;
model.get_mu = @(model) model.mus(:);
model.set_mu = @set_mu;


%% For the dirichlet-values
model.reconstruct_dirichlet = @reconstruct_dirichlet;


%% For the plot
model.plot_solution = @plot_sol;
model.plot_rb_solution = @plot_rb_sol;


%% For the evaluation of the function u
model.eval_u = @eval_u;


%% Detailed Simulation:
model.detailed_simulation=@dg_lin_stat_detailed_simulation;
model.get_dofs_from_sim_data = @(sim_data) sim_data.uh.dofs;


%% For RB:
model.RB_generation_mode = 'model_RB_basisgen';
model.RB_basisgen = @rb_basis_generation_with_hier_err_est;
model.RB_numintervals = 5000;
model.mu_ranges={[1,50]};

model.rb_init_data_basis = @helmholtz_init_data_basis;

model.filecache_ignore_fields_in_model = {'N','Nmax'};
model.filecache_ignore_fields_in_detailed_data = {'RB_info'};

model.RB_stop_Nmax = 5;
model.RB_error_indicator = 'estimator';

model.get_estimator_from_sim_data = @est_from_sim_data;
model.get_residual_for_basis_extension = @(sim_data) sim_data.reduced_data_M.res_norm_sqr;

model.gen_detailed_data = @lin_stat_gen_detailed_data_hier_err_est;
model.set_rb_in_detailed_data = @lin_stat_set_rb_in_detailed_data;

model.gen_reduced_data = @stabilized_lin_stat_gen_reduced_data;

model.get_rb_size = @(model,detailed_data)size(detailed_data.RB,2);
model.get_rb_from_detailed_data=@(detailed_data)detailed_data.RB;


model.get_inner_product_matrix = ...
    @(detailed_data)detailed_data.W;

%model.rb_simulation= @lin_stat_rb_simulation;
model.rb_simulation= @stabilized_lin_stat_rb_simulation;
model.rb_reconstruction = @rb_reconstruction_without_femdiscfunc;
model.RB_extension_algorithm = @RB_ext;

model.save_detailed_simulations = @save_detailed_simulations;
model.RB_detailed_train_savepath='';

model.rb_problem_type = 'lin_stat';

model.coercivity_alpha = @(model) 0.1;

model.compute_output_functional = 0;

model.debug = 0;

model.reduced_data_subset = @reduced_data_subset;

model.error_algorithm = @err_alg;

model.verbose = 25;


model.inner_product=@(model,model_data,vecs1,vecs2)vecs1'*model_data.W*vecs2;

model.use_scm = 0;

model.RB_detailed_train_savepath='';


model.compute_derivative = @compute_derivative;



%% For error estimator:
model.constant_for_error_estimator = @get_constant_for_error_estimator;

model.discrepancy = 1;

model.RB_stop_epsilon = 1e-5;

model.plot_estimator = 1;

model.get_constant_for_error_estimator = @get_constant_for_error_estimator;
model.compute_constant = 1;

end



function index = helmholtz_boundary_type(glob,params)

index=zeros(size(glob));
index(abs(glob)<eps) = -1; %Dirichlet
index(abs(glob)<1-eps) = -1; %Dirichlet
%index(abs(glob)>1-eps) = -1; %Neumann
%index(abs(glob)>1-eps) = -3; %Robin

end



function model = set_mu(model,mu)
model.mus = mu(:);
end



function plot_sol(model,model_data,u,u_ex)

figure
hold on;
for i=1:model_data.grid.nelements
    X = model_data.grid.X( model_data.df_info.LGL_nodes_on_element{i} );
    uh = u(model_data.df_info.elements_glob{i});
    plot(X,uh,'b-*');
end

if nargin==4
    x=linspace(model.xrange(1),model.xrange(2),1000);
    plot(x,u_ex(x),'r-');
    %legend('exakt','numerisch')
    fn = ['Exakte- und numerische L�sung \n mit Polynomgrad = ' ...
        num2str(model.pdeg(1)) '\n und Anzahl der Elemente = ' ...
        num2str(model.xnumintervals)];
    title(sprintf(fn))
else
    title(sprintf(['Numerische L�sung'
        '\n mit Polynomgrad = ' num2str(model.pdeg(1))
        '\n und Anzahl der Elemente = ' num2str(model.xnumintervals)]))
end
hold off;

end



function plot_rb_sol(model,model_data,u_rb,uh,u_ex)

figure
hold on;
for i=1:model_data.grid.nelements
    X = model_data.grid.X( model_data.df_info.LGL_nodes_on_element{i} );
    urb = u_rb(model_data.df_info.elements_glob{i});
    if ~isempty(uh)
        u_h = uh(model_data.df_info.elements_glob{i});
        plot(X,u_h,'r-o');
    end
    plot(X,urb,'b-*');
end

if nargin==5
    x=linspace(model.xrange(1),model.xrange(2),1000);
    plot(x,u_ex(x),'k-');
    %legend('exakt','rb')
    fn = ['Exakte- und RB-L�sung \n mit Polynomgrad = ' ...
        num2str(model.pdeg(1)) '\n und Anzahl der Elemente = ' ...
        num2str(model.xnumintervals)];
    title(sprintf(fn))
else
    title(sprintf(['RB-L�sung'
        '\n mit Polynomgrad = ' num2str(model.pdeg(1))
        '\n und Anzahl der Elemente = ' num2str(model.xnumintervals)]))
end
hold off;

end



function uh = reconstruct_dirichlet(model,model_data,u)

uh = zeros(model_data.df_info.nnodes,1);
uh(model_data.df_info.dofs) = u;
dir = model_data.df_info.dirichlet_ind;
decomp_mode = model.decomp_mode;
model.decomp_mode=0;
for i=1:size(dir,1)
    X = model_data.grid.X(model_data.grid.dirichlet_nodes(i,1));
    uD = model.dirichlet(X(:),model);
    uh(dir(i,1)) = uD;
end
model.decomp_mode=decomp_mode;
end



function s = eval_u(model,model_data,u,x)

j=0;
G = model_data.grid.X(model_data.grid.elements);
s=zeros(size(x));
for i=1:model_data.grid.nelements
    ind=find(x<=G(i,2));
    if ind
        p = model_data.df_info.pdeg_per_element(i);
        X = transform_points_from_element_to_reference_element(x(ind),G(i,:));
        Y = eval_lagrange_on_reference_element(X,model_data.df_info.LGL_nodes_on_reference_element{p});
        uh = u(model_data.df_info.elements_glob{i});
        s(j+ind) = uh'* Y;
        x(ind)=[];
        j=j+length(ind);
    end
end

end



function detailed_data = helmholtz_init_data_basis(model,detailed_data)

first_mu = detailed_data.RB_info.M_train(1);
%second_mu = detailed_data.RB_info.M_train(end);
model=model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);


reduced_data = model.gen_reduced_data(model,detailed_data);
%fct_temp = model.get_residual_for_basis_extension;
fct_temp = model.get_estimator_from_sim_data;
%model.get_residual_for_basis_extension = @(sim_data) log(sim_data.res_norm_sqr(end));
model.get_estimator_from_sim_data = @(sim_data) sim_data.res_norm_sqr(end);

model.N = 1;
post_errs = rb_test_indicator(model,...
    detailed_data, reduced_data,...
    detailed_data.RB_info.M_train,...
    []);


model.get_estimator_from_sim_data = fct_temp;


[~,ind] = max(post_errs);
second_mu = detailed_data.RB_info.M_train(:,ind);

model=model.set_mu(model,second_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,2) = model.get_dofs_from_sim_data(sim_data);


% Orthonormalisation of the Init-Data-Basis
W = detailed_data.W;
if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
    disp('orthogonalising the init values')
    u = model_orthonormalize_qr(model, detailed_data ,u);
end

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);


detailed_data.RB_info.mu_sequence(:,1) = first_mu;
detailed_data.RB_info.mu_sequence(:,2) = second_mu;
end



function u = helmholtz_init_data_basis_hermitian(model,model_data)

mu = model.get_mu(model);
model=model.set_mu(model,1);
sim_data = detailed_simulation(model,model_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

u(:,2) = model.compute_derivative(model,model_data,u);

u=orthonormalize(u,model_data.W,eps,'qr');

end



function err = err_alg(Udet, Ured, err_par, model, model_data)

Udiff = Udet-Ured;
W = err_par;%.inner_product_matrix_h10;
%err = sqrt( abs( (Udiff' * W * Udiff) / (Udet' * W * Udet)));
err = abs((Udiff' * W * Udiff));
end



function [du_dmu] = compute_derivative(model,model_data,u)

dec_mode_old = model.decomp_mode;
model.decomp_mode = 0;
[A,~] = model.operators(model,model_data);

model.decomp_mode = 1;

[A_comp,~] = model.operators(model,model_data);

r = -(-2*model.mus*A_comp{2}+A_comp{3})*u;

du_dmu = A\r;

model.decomp_mode = dec_mode_old;
end



function err = est_from_sim_data(sim_data,reduced_data)

uN = sim_data.uN;
uM = sim_data.reduced_data_M.uN;

rDM = reduced_data.reduced_data_M;

theta = reduced_data.theta;

err_temp = abs(uM'*rDM.WMM*uM + uN'*rDM.WNN*uN - ...
    uM'*rDM.WMN*uN - uN'*rDM.WNM*uM);

%err_sqr = 1/(1-theta)^2 * err_temp;
err = 1/sqrt(1-(theta+1e-10)^2) * sqrt(err_temp); 

end