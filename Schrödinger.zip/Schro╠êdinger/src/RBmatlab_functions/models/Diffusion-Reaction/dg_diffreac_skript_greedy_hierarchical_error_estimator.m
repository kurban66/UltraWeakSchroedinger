close, clear, clc, filecache_clear;

%%

params.xnumintervals = 100;
params.pdeg = 6;

params.xrange = [0,1];

model = dg_diffreac_model_greedy_hierarchical_error_estimator(params);

model.RB_stop_Nmax = 300;
model.RB_numintervals = 5e3;
model.RB_detailed_train_savepath ='SH';
model.mu_ranges = {[1 5]};
model.RB_stop_epsilon = 1e-4;
model.mus = 1;

model_data=model.gen_model_data(model);


%% RB
detailed_data = model.gen_detailed_data(model,model_data);




%% Plot it now

L=length(detailed_data.RB_info);
Ntest = 5000;
disc=model.discrepancy;
dD=detailed_data;
model.compute_constant = 0;

for l=1:L
    
    RB_info = detailed_data.RB_info{l};
    RB = detailed_data.RB{l};
    dD.RB_info = RB_info;
    
    left  = RB_info.M_train(1);
    right = RB_info.M_train(end);
    testspace = linspace(left,right,Ntest);
    
    error_truth = zeros(1,Ntest);
    error_est = zeros(1,Ntest);
    
    W = detailed_data.W;
    
    Nmax = size(RB,2);
    
    for N=1+disc:Nmax
        
        model.N = N;
        dD.RB=RB(:,1:N);
        reduced_data = model.gen_reduced_data(model,dD);
        
        theta = detailed_data.RB_info{l}.theta_sequence(N-disc);
        sigma = detailed_data.RB_info{l}.sigma_sequence(N-disc);
        
        for i=1:Ntest
            mu=testspace(i);
            reduced_data = enrich_reduced_data(dD,reduced_data);
            error_truth(i) = get_truth_error_with_reconstruction(mu, model, dD, reduced_data );
            %error_truth(i) = get_truth_error_with_reconstruction(mu, model, dD, reduced_data.reduced_data_M );
            
            %error_truth(i) = get_truth_error(mu, model, dD, reduced_data );
            error_est(i) = (1/sqrt(1-(theta+1e-10)^2))*(get_hierarchical_error_with_reconstruction( mu, model, dD, reduced_data ) + sigma);
            %error_est(i) = (1/((1/theta)-1))*(get_hierarchical_error_with_reconstruction( mu, model, dD, reduced_data ) + sigma);
        end
        
        %{
        figure
        set(gcf, 'Position', get(0, 'Screensize'));
        h=plot(testspace,error_est,'b',testspace,error_truth,'r');
        title(['Error Estimator vs. True Error (N=' num2str(N-disc) ')'])
        xlabel('\mu')
        ylabel('Error H_1')
        legend('Error Estimator','Error')
        set(gca,'FontSize',20)
        set(h(1),'linewidth',4);
        set(h(2),'linewidth',4);
        %}
        
        figure
        set(gcf, 'Position', get(0, 'Screensize'));
        h=semilogy(testspace,error_est,'b',testspace,error_truth,'r','MarkerSize',20);
        title(['N=' num2str(N-disc)])
        xlabel('\mu')
        g=legend({'$\Delta_N$','$\|u_h ( \mu) - u_N ( \mu)\|_{\mathrm{DG}}$'},'interpreter','latex');
        set(g,'FontSize',30,'Location','northwest');
        set(gca,'FontSize',24)
        set(h(1),'linewidth',4);
        set(h(2),'linewidth',4);
        name = ['/Users/Stefan/Documents/Forschung/Helmholtzgleichung/weak_greedy/HierErrEst_semilogy_N=' num2str(N-disc) ' and P = [' num2str(left) ',' num2str(right) ']''.fig'];
        saveas(gcf,name)
        close all;
        
        %filename = ['/Users/numerik/Documents/Forschung/Helmholtzgleichung/weak_greedy/helmholtz_weak_greedy' num2str(l) '.fig'];
        %saveas(h,filename);
        %close all
        
    end
    
end

filename = ['/Users/Stefan/Documents/Forschung/Helmholtzgleichung/weak_greedy/' 'xnumintervals=' num2str(params.xnumintervals) 'pdeg=' ...
    num2str(params.pdeg) 'tol=' num2str(model.RB_stop_epsilon) ...
    'RBnumintervals=' num2str(model.RB_numintervals) ...
    'mu_ranges=[' num2str(model.mu_ranges{1}(1)) ',' ...
    num2str(model.mu_ranges{1}(2)) ']'];
save(filename);
