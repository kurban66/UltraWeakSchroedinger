function model = laminar_flow_model(params)
%function model = laminar_flow_model(params)
% Model of laminar flow (steady Navier-Stokes) around cylinder in a pipe
%
% CFD benchmark, see:
% http://www.featflow.de/en/benchmarks/cfdbenchmarking/flow/dfg_benchmark1_re20.html

% IM 07.08.2012


if nargin < 1 || ~isfield(params, 'mesh_number')
    params.mesh_number = 3;
end


model = stokes_model_default;

model.has_volume_integral_matrix = 1;
model.has_dirichlet_values = 1;
model.has_nonlinearity = 1;


%% parameter
model.mu_names = {'mu'};
model.mu_ranges = {[2 10]};
model = set_mu(model, 10);


%% geometry settings
model.H = 0.41;
model.L = @(params)0.1;
model.U_m = 0.3;
model.U_mean = @(params)0.2;

model.xrange = [0 2.2];
model.yrange = [0 model.H];

model.gridtype = 'triagrid';
model.grid_initfile = ['cfd_benchmark_mesh', num2str(params.mesh_number), '.mat'];

% define rectangles for dirichlet and neumann boundary
model.bnd_rect_corner1 = [2.2 - 10*eps; 10*eps];
model.bnd_rect_corner2 = [2.2 + 10*eps; model.H - 10*eps];

model.bnd_rect_index = -2;
model.bnd_dimrange_index = {[1 2]};

model.inner_boundary_rectangle = [0.1 0.3 0.1 0.3];

%% discrete functions
model.df_type = 'taylor_hood';
model.pdeg = 2;
model.qdeg = 2;


%% data
model.kinematic_viscosity = @(params) params.mu * 1e-3;
model.diffusivity_tensor = @(grid, eindices, loc, params) ...
    eval_affine_decomp_general(@(grid, eindices, loc, params)...
    {repmat([1 0 0 1], length(eindices), 1), zeros(length(eindices), 4)}, ...
    @(~, ~, ~, params) params.matrix_volume_coeffs{1}(params), ...
    grid, eindices, loc, params);

model.divergence_tensor = @(grid, eindices, loc, params) ...
    eval_affine_decomp_general(@(grid, eindices, loc, params)...
    {zeros(length(eindices), 4), repmat([1 0 0 1], length(eindices), 1)}, ...
    @(~, ~, ~, params) params.matrix_volume_coeffs{1}(params), ...
    grid, eindices, loc, params);

model.dirichlet_values = @(grid,eindices,faceinds,llcoord,params) ...
    eval_affine_decomp_general(@my_inflow, @(~, ~, ~, ~, ~)1, ...
    grid, eindices, faceinds, llcoord, params);

model.matrix_volume_int_kernel = {@Fem.IntegralKernels.stokes_volume_matrix};
model.matrix_volume_coeffs = {@(params)[params.kinematic_viscosity(params); 1]};
model.matrix_nonlin_indices = 2;


%% RB generation
model.RB_detailed_train_savepath = ['/data/lfm/mesh', num2str(params.mesh_number)'];
%model.RB_generation_mode = 'greedy_random_fixed';
%model.RB_train_size = 1000;
model.RB_generation_mode = 'greedy_uniform_fixed';
model.RB_numintervals = 19;
%model.RB_error_indicator = 'error';
%model.RB_error_indicator = 'error_relative';
model.RB_error_indicator = 'estimator';

model.RB_stop_epsilon = 1e-5;
model.RB_stop_timeout = 10000;
model.RB_stop_Nmax = 100;

model.RB_infsup_rbf_test_size = 100;
model.RB_infsup_rbf_init_numintervals = 2;
model.RB_infsup_rbf_tolerance = 1e-4;
model.RB_infsup_rbf_nmax = 20;

model.infsup_method = 'rbf_interpolant';
model.dilation = 2;

model.filecache_ignore_fields_in_model = ...
    {'RB_error_indicator', 'filecache_ignore_fields_in_model', 'RB_stop_Nmax', ...
    'RB_stop_epsilon', 'RB_error_indicator', 'rb_init_data_basis'};
end

function res = my_inflow(grid,eindices,faceinds,llcoord,params)
%function res = my_inflow(grid,eindices,faceinds,llcoord,params)
%

loc = llocal2local(grid,faceinds,llcoord);
glob = local2global(grid,eindices,loc,params);

% inflow on left-hand side
Y = (glob(:,1) < eps) .* glob(:,2);

res = {[4 * params.U_m * Y .* (params.H - Y) / (params.H^2), zeros(length(Y), 1)]};
end