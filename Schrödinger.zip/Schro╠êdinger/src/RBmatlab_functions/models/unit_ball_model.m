function model = unit_ball_model(params)
%function model = unit_ball_model(params)
%
% parametric model in R^p to be used as an elliptic model. Example,
% where exact solution is known, manifold mapping is non-bijective.
%
% input parameter params.p: the dimension (and number of components
% of f, and parameter dimension)

% B. Haasdonk 12.6.2014

model = [];
p = params.p;
model.p = p;
model.ndofs = p;

%model.rb_problem_type = 'lin_stat';
%model.mu_names = {}; perhaps later
mu_ranges = {};

for i=1:p
  mu_ranges = [mu_ranges, {[-1,1]}];
end;
model.mu_ranges = mu_ranges;

model.set_mu = @my_set_mu;


model.get_mu = @(model) model.mus;

model.gen_model_data = @my_gen_model_data;
model.detailed_simulation = @my_detailed_simulation;
model.decomp_mode = 0; % default: complete evaluation

%model.plot_sim_data = @lin_stat_plot_sim_data;
%model.plot_detailed_data = @lin_stat_plot_detailed_data;

%model.gen_detailed_data = @lin_stat_gen_detailed_data;
%model.gen_reduced_data = @lin_stat_gen_reduced_data;
%model.reduced_data_subset = @lin_stat_reduced_data_subset;
%model.rb_simulation = @lin_stat_rb_simulation;
%model.rb_reconstruction = @lin_stat_rb_reconstruction;
%model.compute_output_functional = 0;
model.operators = @my_operators;
%model.operators_output = @fem_operators_output;

%model.get_dofs_from_sim_data = @(sim_data) sim_data.uh;
%model.set_dofs_in_sim_data = @my_set_dofs_in_sim_data; 
%model.get_inner_product_matrix = @(detailed_data) ...
%    detailed_data.df_info.regularized_h10_inner_product_matrix;
%model.RB_generation_mode = 'lagrangian';
%model.set_rb_in_detailed_data=@lin_stat_set_rb_in_detailed_data;
%model.get_rb_size= @(model,detailed_data) size(detailed_data.RB,2);
%model.get_estimators_from_sim_data= @(sim_data) sim_data.Delta;
% for demo_rb_gui:
%model.is_stationary = 1;
%model.axes_tight = 1;
% for use of scm (standard is 0, i.e. no scm - for the configuration fields of scm see scm_offline.m):
%model.use_scm = 0;

function model = my_set_mu(model,mu,dummy) 
model.mus = mu;

function [A,f] = my_operators(model,model_data);
switch model.decomp_mode
 case 0
  A = eye(model.p);
  f = model.mus/norm(model.mus);
 case 1 % components
  E = eye(model.p);
  A = {E};
  for i=1:model.p
    f = [f,{E(:,i)}];
  end;
 case 2 % coefficients
  A = 1;
  f = mu/norm(mu);
end;

function model_data = my_gen_model_data(model);
model_data = [];

function sim_data = my_detailed_simulation(model,model_data);
[A,f] = model.operators(model,model_data);
sim_data.u = A\f;


