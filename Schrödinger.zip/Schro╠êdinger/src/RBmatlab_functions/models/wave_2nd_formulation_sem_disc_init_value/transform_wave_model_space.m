function model = transform_wave_model_space(model)

%% Useful constants for the dg-method
model.dg.constants.epsilon = -1;
model.dg.constants.sigma0 = 0.1;
model.dg.constants.sigma1 = 0;


model.xnumintervals = model.Xnumintervals;
model.xrange = model.Xrange;
model.pdeg = model.PDEG;


%% dg-fem-function-handle in SPACE!
model.has_diffusivity = 1;
model.has_advection = 0;
model.has_reaction = 0;

model.has_source = 1;
model.has_output_functional = 0;
model.has_dirichlet_values = 1;
model.has_neumann_values = 0;
model.has_robin_values = 0;

% Diffusion:
diffusivity_coefficients = @(dummy,params) params.mus^2;
diffusivity_components = @(glob,params) ...
                {ones(length(glob),1)};
model.diffusivity = @(glob,params) ...
    eval_affine_decomp_general(...
	diffusivity_components, ...
    diffusivity_coefficients, glob,params);


% Reaction:
reaction_coefficients = @(dummy,params) 0;
reaction_components = @(glob,params) ...
                {};
model.reaction = @(glob,params) ...
    eval_affine_decomp_general(...
	reaction_components, ...
    reaction_coefficients, glob,params);


% Source Term:
source_coefficients = @(dummy,params) 1;
source_components = @(glob,params) ...
                {zeros(length(glob),1)}; % Not time-dependent. But if so -> params.t
model.source = @(glob,params) ...
    eval_affine_decomp_general(...
	source_components, ...
    source_coefficients, glob,params);


% Dirichlet Boundary-Term:
dir_coefficients = @(dummy,params) 1;
dir_components = @(glob,params) ...
                            {zeros(length(glob),1)};
model.dirichlet = @(glob,params) ...
    eval_affine_decomp_general(...
	dir_components, ...
    dir_coefficients, glob,params);


% Neumann Boundary-Term:
neumann_coefficients = @(dummy,params) 1;
neumann_components = @(glob,params) ...
                {};
model.neumann = @(glob,params) ...
    eval_affine_decomp_general(...
	neumann_components, ...
    neumann_coefficients, glob,params);


 % Robin Boundary-Term:
 robin_g_coefficients = @(dummy,params) 1;
 robin_g_components = @(glob,params) ...
                {zeros(length(glob),1)};
 model.robin_g = @(glob,params) ...
    eval_affine_decomp_general(...
	 robin_g_components, ...
    robin_g_coefficients, glob,params);

robin_beta_coefficients = @(dummy,params) params.mus;
robin_beta_components = @(glob,params) ...
                {1i*ones(length(glob),1)};
model.robin_beta = @(glob,params) ...
    eval_affine_decomp_general(...
	 robin_beta_components, ...
    robin_beta_coefficients, glob,params);


%% For the boundary terms:
model.boundary_type = @wave_boundary_type;


end



function index = wave_boundary_type(glob,params)
    
    index=zeros(size(glob));
    index(abs(glob)-eps<params.xrange(1)) = -1; %Dirichlet
    index(abs(glob)>params.xrange(2)-eps) = -1; %Dirichlet
    
end