function model = sem_wave_model(params)

%% name of the model
model.name = 'wave';

%% Dimension of the PDE-Equations
if ~isfield(params,'dimrange')
    model.dimrange=1;
else
    model.dimrange=params.dimrange;
end


%% define auxiliary properties for the spatial grid
if ~isfield(params,'xrange')
    model.xrange=[0,1];
else
    model.xrange=params.xrange;
end

if ~isfield(params,'xnumintervals')
    model.xnumintervals=10;
else
    model.xnumintervals=params.xnumintervals;
end

if ~isfield(params,'pdeg')
    model.pdeg = 2*ones(model.xnumintervals,1);
else
    model.pdeg = params.pdeg.*ones(model.xnumintervals,1);
end

model.Xnumintervals = model.xnumintervals;
model.Xrange = model.xrange;
model.PDEG = model.pdeg;



%% define auxiliary properties for the time grid

if ~isfield(params,'trange')
    model.trange=[0,1];
else
    model.trange=params.trange;
end

model.T = model.trange(2);

if ~isfield(params,'tnumintervals')
    model.tnumintervals=10;
else
    model.tnumintervals=params.tnumintervals;
end

if ~isfield(params,'pdeg_time')
    model.pdeg_time = ones(model.tnumintervals,1);
else
    model.pdeg_time = params.pdeg_time.*ones(model.tnumintervals,1);
end


model.gridtype = 'onedgrid';


%% Others
model.gen_model_data = @sem_space_time_gen_model_data;


%% dg-fem-function-handle in SPACE!
model.decomp_mode=0;
model.operators = @sem_wave_operators;

model.has_diffusivity = 1;
model.has_advection = 0;
model.has_reaction = 0;

model.has_source = 1;
model.has_output_functional = 0;
model.has_dirichlet_values = 1;
model.has_neumann_values = 0;
model.has_robin_values = 0;

% Diffusion:
diffusivity_coefficients = @(dummy,params) params.mus^2;
diffusivity_components = @(glob,params) ...
                {sin(pi*glob)/( (1-params.t+1e-12)^(1/4) )};
model.diffusivity = @(glob,params) ...
    eval_affine_decomp_general(...
	diffusivity_components, ...
    diffusivity_coefficients, glob,params);


% Reaction:
reaction_coefficients = @(dummy,params) 0;
reaction_components = @(glob,params) ...
                {};
model.reaction = @(glob,params) ...
    eval_affine_decomp_general(...
	reaction_components, ...
    reaction_coefficients, glob,params);


% Source Term:
source_coefficients = @(dummy,params) 1;
source_components = @(glob,params) ...
                {sin(pi*glob)*exp(-params.t)}; % Not time-dependent. But if so -> params.t
model.source = @(glob,params) ...
    eval_affine_decomp_general(...
	source_components, ...
    source_coefficients, glob,params);


% Dirichlet Boundary-Term:
dir_coefficients = @(dummy,params) 1;
dir_components = @(glob,params) ...
                            {zeros(length(glob),1)};
model.dirichlet = @(glob,params) ...
    eval_affine_decomp_general(...
	dir_components, ...
    dir_coefficients, glob,params);


% Neumann Boundary-Term:
neumann_coefficients = @(dummy,params) 1;
neumann_components = @(glob,params) ...
                {};
model.neumann = @(glob,params) ...
    eval_affine_decomp_general(...
	neumann_components, ...
    neumann_coefficients, glob,params);


 % Robin Boundary-Term:
 robin_g_coefficients = @(dummy,params) 1;
 robin_g_components = @(glob,params) ...
                {zeros(length(glob),1)};
 model.robin_g = @(glob,params) ...
    eval_affine_decomp_general(...
	 robin_g_components, ...
    robin_g_coefficients, glob,params);

robin_beta_coefficients = @(dummy,params) params.mus;
robin_beta_components = @(glob,params) ...
                {1i*ones(length(glob),1)};
model.robin_beta = @(glob,params) ...
    eval_affine_decomp_general(...
	 robin_beta_components, ...
    robin_beta_coefficients, glob,params);


%% For the boundary terms:
model.boundary_type = @wave_boundary_type;
model.reconstruct_dirichlet = @reconstruct_dirichlet;


%% For the parameters:
model.mu_names = {'c'};
model.mus = 1;
model.get_mu = @(model) model.mus(:);
model.set_mu = @set_mu;


%% For the dirichlet-values
model.reconstruct_dirichlet = @reconstruct_dirichlet;


%% For the plot
model.plot_solution = @plot_sol;
model.plot_solution_movie = @plot_sol_movie;
model.plot_rb_solution = @plot_rb_sol;


%% For the evaluation of the function u
model.eval_u = @eval_u; 


%% Detailed Simulation:
model.detailed_simulation=@st_detailed_simulation;
model.get_dofs_from_sim_data = @(sim_data) sim_data.uh.dofs;


%% For RB:
model.RB_generation_mode = 'greedy_uniform_fixed';
model.RB_numintervals = 1000;
model.mu_ranges={[1,5]};

model.rb_init_data_basis = @wave_init_data_basis;
%model.rb_init_data_basis = @helmholtz_init_data_basis_hermitian;

model.filecache_ignore_fields_in_model = {'N','Nmax'};
model.filecache_ignore_fields_in_detailed_data = {'RB_info'};

model.RB_stop_Nmax = 50;
model.RB_error_indicator = 'error';

model.gen_detailed_data = @sem_space_time_detailed_data;
model.set_rb_in_detailed_data = @lin_stat_set_rb_in_detailed_data;

%model.gen_reduced_data = @lin_stat_gen_reduced_data;
model.gen_reduced_data = @stabilized_lin_stat_gen_reduced_data;

model.get_rb_size = @(model,detailed_data)size(detailed_data.RB,2);
model.get_rb_from_detailed_data=@(detailed_data)detailed_data.RB;


model.get_inner_product_matrix = ...
    @(detailed_data)detailed_data.W;

%model.rb_simulation= @lin_stat_rb_simulation;
model.rb_simulation= @stabilized_lin_stat_rb_simulation;
model.rb_reconstruction = @lin_stat_rb_reconstruction;

model.RB_extension_algorithm = @RB_extension;

model.save_detailed_simulations = @save_detailed_simulations;
model.RB_detailed_train_savepath='';

model.coercivity_alpha = @(model) 1;

model.compute_output_functional = 0;

model.debug = 0;

model.reduced_data_subset = @lin_stat_reduced_data_subset;

model.error_algorithm = @err_alg;

model.verbose = 5;


model.inner_product=@(model,model_data,vecs1,vecs2)vecs1'*model_data.W*vecs2;

model.use_scm = 0;

model.RB_detailed_train_savepath='SH';


model.compute_derivative = @compute_derivative;

end



function index = wave_boundary_type(glob,params)
    
    index=zeros(size(glob));
    index(abs(glob)<eps) = -1; %Dirichlet
    index(abs(glob)>1-eps) = -1; %Dirichlet
    
end



function model = set_mu(model,mu)
    model.mus = mu(:);
end



function plot_sol(model,model_data,u,u_ex)
    figure
    hold on;
    for i=1:model_data.grid_space.nelements
        X = model_data.grid_space.X( model_data.df_info_space.LGL_nodes_on_element{i} );
        uh = u(model_data.df_info_space.elements_glob{i});
        plot(X,uh,'b-*');
    end
    
    if nargin==4
        x=linspace(model.xrange(1),model.xrange(2),1000);
        plot(x,u_ex(x),'r-');
        %legend('exakt','numerisch')
        fn = ['Exakte- und numerische L�sung \n mit Polynomgrad = ' ...
            num2str(model.pdeg(1)) '\n und Anzahl der Elemente = ' ...
            num2str(model.xnumintervals)];
        title(sprintf(fn))
    else
        title(sprintf(['Numerische L�sung' ...
        '\n mit Polynomgrad = ' num2str(model.pdeg(1)) ...
        '\n und Anzahl der Elemente = ' num2str(model.xnumintervals)]))
    end
    hold off;
    
end





function plot_sol_movie(model,model_data,u,u_ex,incr)
    figure(1)
    
    %% Set up the movie.
    moviename = ['movie_mu=' num2str(model.mus) '.avi'];
    writerObj = VideoWriter(moviename); % Name it.
    writerObj.FrameRate = 60; % How many frames per second.
    open(writerObj); 

    t=zeros(model_data.df_info_time.nnodes,1);
    for el_time=1:model_data.grid_time.nelements
        for i=1:length(model_data.df_info_time.LGL_nodes_on_element{el_time});
            coo = model_data.df_info_time.LGL_nodes_on_element{el_time}(i);
            ind = model_data.df_info_time.elements_glob{el_time}(i);
            t(ind) = model_data.grid_time.X(coo);
        end
    end
    
    
    model_data.grid = model_data.grid_space;
    model_data.df_info = model_data.df_info_space;

    %x=linspace(model.xrange(1),model.xrange(2),1000);
    
    
    
    for k=1:incr:length(t)
        model.t = t(k);
        
        
        %plot(x,u_ex(model.t,x),'ro');
        %hold on;
        
        for i=1:model_data.grid_space.nelements
            X = model_data.grid_space.X( model_data.df_info_space.LGL_nodes_on_element{i} );
            uh = u(model_data.df_info_space.elements_glob{i},k);
            plot(X,uh,'b-*');
            hold on;
        end
        
        fn = ['Exact and numerical solution for mu = ' ...
            num2str(model.mus) '\n xnumintervals = ' ...
            num2str(model.xnumintervals) ' pdeg = ' ...
            num2str(model.pdeg(1)) '\n tnumintervals = ' ...
            num2str(model.tnumintervals) ' pdeg = ' ...
            num2str(model.PDEG(1)) '\nZeitschritt:' num2str(model.t)];
        title(sprintf(fn))
        legend('Space-Time-SEM')
        
        frame = getframe(gcf); % 'gcf' can handle if you zoom in to take a movie.
        writeVideo(writerObj, frame);
        
        hold off
    end

    close(writerObj);

    
end







function plot_rb_sol(model,model_data,u_rb,uh,u_ex)
    figure
    hold on;
    for i=1:model_data.grid.nelements
        X = model_data.grid.X( model_data.df_info.LGL_nodes_on_element{i} );
        urb = u_rb(model_data.df_info.elements_glob{i});
        if ~isempty(uh)
            u_h = uh(model_data.df_info.elements_glob{i});
            plot(X,u_h,'r-o');
        end
        plot(X,urb,'b-*');
    end
    
    if nargin==5
        x=linspace(model.xrange(1),model.xrange(2),1000);
        plot(x,u_ex(x),'k-');
        %legend('exakt','rb')
        fn = ['Exakte- und RB-L�sung \n mit Polynomgrad = ' ...
            num2str(model.pdeg(1)) '\n und Anzahl der Elemente = ' ...
            num2str(model.xnumintervals)];
        title(sprintf(fn))
    else
        title(sprintf(['RB-L�sung'
        '\n mit Polynomgrad = ' num2str(model.pdeg(1))
        '\n und Anzahl der Elemente = ' num2str(model.xnumintervals)]))
    end
    hold off;
    
end



function uh = reconstruct_dirichlet(model,model_data,u)
    uh = zeros(model_data.df_info_space.nnodes,1);
    uh(model_data.df_info_space.dofs) = u;
    dir = model_data.df_info_space.dirichlet_ind;
    decomp_mode = model.decomp_mode;
    model.decomp_mode=0;
    for i=1:size(dir,1)
        X = model_data.grid_space.X(model_data.grid_space.dirichlet_nodes(i,1));
        uD = model.dirichlet(X(:),model);
        uh(dir(i,1)) = uD;
    end
    model.decomp_mode=decomp_mode;
end



function s = eval_u(model,model_data,u,x)
    j=0;
    G = model_data.grid.X(model_data.grid.elements);
    s=zeros(size(x));
    for i=1:model_data.grid.nelements
        ind=find(x<=G(i,2));
        if ind
            p = model_data.df_info.pdeg_per_element(i);
            X = transform_points_from_element_to_reference_element(x(ind),G(i,:));
            Y = eval_lagrange_on_reference_element(X,model_data.df_info.LGL_nodes_on_reference_element{p});
            uh = u(model_data.df_info.elements_glob{i});
            s(j+ind) = uh'* Y;
            x(ind)=[];
            j=j+length(ind);
        end
    end
            
end

function u = wave_init_data_basis(model,model_data)
mu = model.get_mu(model);
model=model.set_mu(model,1);
sim_data = detailed_simulation(model,model_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

end




function err = err_alg(Udet, Ured, err_par, model, model_data)


Udiff = Udet-Ured;
W = err_par;%.inner_product_matrix_h10;
%err = sqrt( abs( (Udiff' * W * Udiff) / (Udet' * W * Udet)));
err = abs((Udiff' * W * Udiff));


end