clear, close, clc;

params.xrange=[-1,1];
params.xnumintervals=100;
T=1;
params.trange=[0,T];
params.tnumintervals=100;
params.pdeg_time = 3;
params.pdeg = 3;

model = sem_wave_model(params);

model_data = model.gen_model_data(model);




%% A detailed solution:
mu = 1;

[m,n] = size(model_data.operators.b);


A = [kron(model_data.operators.A_time,model_data.L2_space) , -kron(model_data.L2_time,model_data.L2_space) ;
        mu*kron(model_data.L2_time,model_data.operators.A_space) , kron(model_data.operators.A_time,model_data.L2_space)];
    
%A(1:m,:) = 0*A(1:m,:);
%A(:,1:m) = 0*A(:,1:m);
A(1:m,1:m) = A(1:m,1:m) + model_data.L2_space;
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);

%b(1:m) = b(1:m) + model_data.L2_space*model_data.operators.h;

nb = length(b);
b = [zeros(nb,1);b];
b(1:m) = b(1:m) + model_data.L2_space*model_data.operators.h;

uh = A\b;

uh = reshape(uh(1:m*n),m,n);

model.mus = mu;

% Dirichlet in space:
uh = [zeros(1,n) ; uh ; zeros(1,n)];

% Dirichlet in time:
%uh = [zeros(m+2,1) , uh];


%% Exact solution:

%U_ex = @(x) (1./(pi^2*mu^2))*(1-cos(t(i).*mu.*pi)).*sin(pi*x);
u_ex = @(t,x) (1./(pi^2*mu))*(1-cos(t.*sqrt(mu).*pi)).*sin(pi*x);
model.plot_solution_movie(model,model_data,uh,u_ex,1);




