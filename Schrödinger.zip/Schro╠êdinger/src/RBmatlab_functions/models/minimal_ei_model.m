function mm = minimal_ei_model
  mm                                  = [];
  mm.name                             = 'minimal_model';
  mm.mu_names                         = {'par1', 'par2'};
  mm.mu_ranges                        = {[0.5 1], [1 3]};
  mm.gsize                            = [ 100 1 ];
  mm.xfun                             = @simple_sin;
  mm.par1                             = 0.5;
  mm.par2                             = 1;
  mm.debug                            = 0;
  mm.force_delete                     = 1;
  mm.filecache_ignore_fields_in_model = {};

  mm.L_I_local_ptr                    = @fv_implicit_space;
  mm.num_diff_flux_ptr                = @fv_num_diff_flux_gradient;
  mm.fv_impl_diff_weight              = 1.0;
  mm.fv_impl_conv_weight              = 0.0;
  mm.fv_impl_react_weight             = 0.0;

  mm.mass_matrix                      = @fv_mass_matrix;

%  mm.bnd_rect_corner1                      = [-1 -1];
%  mm.bnd_rect_corner2                      = [2 2];
%  mm.bnd_rect_index                        = -2;
  mm.verbose                               = 10;
  mm.diffusivity_ptr                       = @diffusivity_exponential;
  mm.diffusivity_derivative_ptr            = @diffusivity_exponential_derivative;
  mm.diff_k0                               = 0.00;
  mm.diff_m                                = 1.0;
  mm.diff_p                                = 2.0;
  mm.decomp_mode                           = 0;
  mm.laplacian_ptr                         = @(glob, U, model) U;
  mm.laplacian_derivative_ptr              = @(glob, U, model) ones(length(U),1);
  mm.filecache_velocity_matrixfile_extract = 0;
  mm.neumann_values_ptr                    = @neumann_values_homogeneous;
  mm.c_neu                                 = 0.00;
  mm.get_inner_product_matrix              = @(detailed_data) detailed_data.W;
  mm.l2_error_sequence_algorithm           = @fv_l2_error;

  mm.new = 1;
  mm.operators_ptr = @(x) x;
  mm.init_values_algorithm = @(x) x;
  mm.error_norm = 'l2';
  mm.rb_problem_type = 'Test';

function U = simple_sin(descr, values)

  U = descr.par1.*sin(3.14159.*values.*descr.par2);

