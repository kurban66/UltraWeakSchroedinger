function model = transform_wave_model_time(model)

%% Useful constants for the dg-method
model.dg.constants.epsilon = -1;
model.dg.constants.sigma0 = 1;
model.dg.constants.sigma1 = 1;


% Change to the time-stuff
model.xnumintervals = model.tnumintervals;
model.xrange = model.trange;
model.pdeg = model.pdeg_time;



%% dg-fem-function-handle in TIME!
model.has_diffusivity = 0;
model.has_advection = 1;
model.has_reaction = 0;

model.has_source = 0;
model.has_output_functional = 0;
model.has_dirichlet_values = 1;
model.has_neumann_values = 0;
model.has_robin_values = 0;

% Advection:
advection_coefficients = @(dummy,params) 1;
advection_components = @(glob,params) ...
                {ones(length(glob),1)};
model.advection = @(glob,params) ...
    eval_affine_decomp_general(...
	advection_components, ...
    advection_coefficients, glob,params);




% Dirichlet Boundary-Term:
dir_coefficients = @(dummy,params) 1;
dir_components = @(glob,params) ...
                            {zeros(length(glob),1)};
model.dirichlet = @(glob,params) ...
    eval_affine_decomp_general(...
	dir_components, ...
    dir_coefficients, glob,params);


% Source Term:
source_coefficients = @(dummy,params) 1;
source_components = @(glob,params) ...
                {sin(pi*glob)*exp(-params.t)}; % Not time-dependent. But if so -> params.t
model.source = @(glob,params) ...
    eval_affine_decomp_general(...
	source_components, ...
    source_coefficients, glob,params);


%% For the boundary terms:
model.boundary_type = @wave_boundary_type;



end



function index = wave_boundary_type(glob,params)
    
    index=zeros(size(glob));
    index(abs(glob)-eps<params.xrange(1)) = -1; %Dirichlet
    %Am Endzeitpunkt keine Bedingung!
    %index(abs(glob)>params.xrange(2)-eps) = -1; %Dirichlet
    
end