function [] = sem_wave_test_with_movie

params.xrange=[0,1];
params.xnumintervals=10;
T=1;
params.trange=[0,T];
params.tnumintervals=1000;
params.pdeg_time = 1;
params.pdeg = 1;

model = sem_wave_model(params);

model_data = model.gen_model_data(model);




%% A detailed solution:
mu = 1;
model=model.set_mu(model,mu);

%{
[m,n] = size(model_data.operators.b);


A = [kron(model_data.operators.A_time,model_data.L2_space) , -kron(model_data.L2_time,model_data.L2_space) ;
        mu*kron(model_data.L2_time,model_data.operators.A_space) , kron(model_data.operators.A_time,model_data.L2_space)];
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);

nb = length(b);
b = [zeros(nb,1);b];

uh = A\b;
uh = reshape(uh(1:m*n),m,n);
%}

Ntime = size(model_data.operators.A_time,1);
Nspace = size(model_data.operators.A_space,1);


A = [kron(model_data.operators.A_time,model_data.L2_space) , -kron(model_data.L2_time,model_data.L2_space) ;
        mu*kron(model_data.L2_time,model_data.operators.A_space) , kron(model_data.operators.A_time,model_data.L2_space)];

    function w = Aw(w)
        mu = model.get_mu(model);
        w = w(:);
        w1 = reshape(w(1:Nspace*Ntime),Nspace,Ntime);
        w2 = reshape(w(Ntime*Nspace+1:end),Nspace,Ntime);
        Aw1 = model_data.L2_space*(w1*model_data.operators.A_time') - ...
            model_data.L2_space*(w2*model_data.L2_time');
        Aw2 = mu*model_data.operators.A_space*(w1* model_data.L2_time') + ...
            model_data.L2_space*(w2*model_data.operators.A_time');
        w = [Aw1(:);Aw2(:)];
    end
    
    function w = Atw(w)
        mu = model.get_mu(model);
        w = w(:);
        w1 = reshape(w(1:Nspace*Ntime),Nspace,Ntime);
        w2 = reshape(w(Ntime*Nspace+1:end),Nspace,Ntime);
        Aw1 = model_data.L2_space'*(w1*model_data.operators.A_time) + ...
            mu*model_data.operators.A_space'*(w2* model_data.L2_time);
        Aw2 = -model_data.L2_space'*(w1*model_data.L2_time) + ...
            model_data.L2_space'*(w2*model_data.operators.A_time);
        w = [Aw1(:);Aw2(:)];
    end

    function w = precond(w)
        w = w(:)./diag(A);
        %w1 = reshape(w(1:Nspace*Ntime),Nspace,Ntime);
        %w2 = reshape(w(Ntime*Nspace+1:end),Nspace,Ntime);
        %Mw1 = model_data.L2_space\((model_data.L2_time\w1')');
        %Mw2 = model_data.W_space\((model_data.L2_time\w2')');
        %w = [Mw1(:);Mw2(:)];
    end



b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);
nb = length(b);
b = [zeros(nb,1);b];
uh = gmres(@Aw,b,10,1e-2,1000,@precond);


%tol =1e-6;
%maxit = 100000;
%[uh, flag, relres, i] = glsqr(@Aw, @Atw, b, tol, maxit, @precond, @precond);
%disp(i)


model.mus = mu;
uh = reshape(uh(1:Ntime*Nspace),Nspace,Ntime);

% Dirichlet in space:
uh = [zeros(1,Ntime) ; uh ; zeros(1,Ntime)];

% Dirichlet in time:
uh = [zeros(Nspace+2,1) , uh];


%% Exact solution:
u_ex = @(t,x) (1./(pi^2*mu))*(1-cos(t.*sqrt(mu).*pi)).*sin(pi*x);
model.plot_solution_movie(model,model_data,uh,u_ex);


end

