clear, close, clc;

%% Prepare model & model_dat
[model,model_data] = dg_maxwell_model_standard_error_estimator;

M_train = linspace(model.mu_ranges{1}(1),model.mu_ranges{1}(2),model.RB_numintervals+1);

model.decomp_mode = 0;
betas = zeros(1,length(M_train));

for i = 1:length(M_train)
    mu = M_train(i);
    model = model.set_mu(model,mu);
    [A,~] = model.operators(model,model_data);
    betas(i) = get_infsup_mumps(model,A,model_data.W);
    betas(i)
end

plot(M_train,betas,'r*-');