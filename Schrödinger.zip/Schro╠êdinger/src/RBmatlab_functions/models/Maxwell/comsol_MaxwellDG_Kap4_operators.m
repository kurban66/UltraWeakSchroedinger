function [A,r] = comsol_MaxwellDG_Kap4_operators(model,model_data)
%function [A,r] = comsol_MaxwellDG_Kap4_operators(model,model_data)
%
% This function calculates the operators for the Maxwell DG model
% if model.use_comsol = 1. 
% Otherwise it simply forwards the matrices stored in model_data
%
%
% Input:
% =======
% - model: Maxwell Model
% - model_data
%
% Output:
% =======
% - A, r: affine terms of the operators (in case of model.decomp_mode=1) or
%           coefficients (in case of model.decomp_mode=2) or the 
%           full operators (in case of model.decomp_mode=0)
%
% Oliver Zeeb, 2013

    switch model.decomp_mode
        case 0
            model.decomp_mode = 1;
            [A_comp, r_comp] = model.operators(model,model_data);
            model.decomp_mode = 2;
            [A_coeff,r_coeff] = model.operators(model,model_data);
            A = lincomb_sequence(A_comp, A_coeff);
            r = lincomb_sequence(r_comp, r_coeff);
        case 1
            if model.use_comsol
                comsol_model=model_data.comsol_model;

                w_wfeq1  = comsol_model.physics('w').feature('wfeq1').getString('weak');
                w_ibweak1 = comsol_model.physics('w').feature('ibweak1').getString('weakExpression');
                w_ibweak2 = comsol_model.physics('w').feature('ibweak2').getString('weakExpression');
                w_ibweak3 = comsol_model.physics('w').feature('ibweak3').getString('weakExpression');
                w_weak1 = comsol_model.physics('w').feature('weak1').getString('weakExpression');
                w_weak2 = comsol_model.physics('w').feature('weak2').getString('weakExpression');
                w_weak3 = comsol_model.physics('w').feature('weak3').getString('weakExpression');
                w_weak4 = comsol_model.physics('w').feature('weak4').getString('weakExpression');
                w_weak5 = comsol_model.physics('w').feature('weak5').getString('weakExpression');

                
                A = cell(3,1);
                %a1:
                disp('extracting A{1}...')
                tic;
                comsol_model.physics('w').feature('wfeq1').set('weak', {'1/mu *rotE1*rotv1   +1/mu *rotE2*rotv2    + 1/mu *rotE3*rotv3 '; '0'; '0'});
                comsol_model.physics('w').feature('weak4').active(false);
                comsol_model.physics('w').feature('weak5').active(false);
                if model.comsol_get_eliminated_data
                    str = mphmatrix(comsol_model,'sol1','Out',{'Kc'});
                    A{1} = str.Kc;
                else
                    str = mphmatrix(comsol_model,'sol1','Out',{'K'});
                    A{1} = str.K;
                end
                disp(['done! time elapsed: ', num2str(toc)]);

                %a2:
                disp('extracting A{2}...')
                tic;
                comsol_model.physics('w').feature('wfeq1').set('weak', ...
                    {'-epsilon *E1*test(E1) - epsilon *E2*test(E2) - epsilon *E3*test(E3)'; '0'; '0'});
                comsol_model.physics('w').feature('ibweak1').active(false);
                comsol_model.physics('w').feature('ibweak2').active(false);
                comsol_model.physics('w').feature('ibweak3').active(false);
                comsol_model.physics('w').feature('weak1').active(false);
                comsol_model.physics('w').feature('weak2').active(false);
                comsol_model.physics('w').feature('weak3').active(false);
                comsol_model.physics('w').feature('weak4').active(false);
                comsol_model.physics('w').feature('weak5').active(false);
                if model.comsol_get_eliminated_data
                    str = mphmatrix(comsol_model,'sol1','Out',{'Kc'});
                    A{2} = str.Kc;
                else
                    str = mphmatrix(comsol_model,'sol1','Out',{'K'});
                    A{2} = str.K;
                end
                disp(['done! time elapsed: ', num2str(toc)]);

                %a3:
                disp('extracting A{3}...')
                tic;
                comsol_model.physics('w').feature('wfeq1').set('weak', ...
                    {'-i*sigma*E1*test(E1) -i*sigma*E2*test(E2)  -i*sigma*E3*test(E3) '; '0'; '0'});
                comsol_model.physics('w').feature('weak4').set('weakExpression',...
                    '-i*lambda *sqrt(epsilon0/mu0) * ( ET1*vT1 + ET2*vT2 + ET3*vT3 ) ');
                comsol_model.physics('w').feature('weak4').active(true);
                if model.comsol_get_eliminated_data
                    str = mphmatrix(comsol_model,'sol1','Out',{'Kc'});
                    A{3} = str.Kc;
                else
                    str = mphmatrix(comsol_model,'sol1','Out',{'K'});
                    A{3} = str.K;
                end
                disp(['done! time elapsed: ', num2str(toc)]);

                %f1:
                disp('extracting f{1}...')
                tic;
                comsol_model.physics('w').feature('weak4').active(false);
                comsol_model.physics('w').feature('wfeq1').set('weak', ...
                    {'- i*sqrt(epsilon0) * (Ja1*test(E1) + Ja2*test(E2) + Ja3*test(E3))'; '0'; '0'});
                if model.comsol_get_eliminated_data
                    str = mphmatrix(comsol_model,'sol1','Out',{'Lc'});
                    r{1} = str.Lc;
                else
                    str = mphmatrix(comsol_model,'sol1','Out',{'L'});
                    r{1} = str.L;
                end
                disp(['done! time elapsed: ', num2str(toc)]);
                
                %f2:
                disp('extracting f{2}...')
                tic;
                comsol_model.physics('w').feature('wfeq1').set('weak',{'0'; '0'; '0'});
                comsol_model.physics('w').feature('weak4').set('weakExpression', ...
                    '-(g1*vT1 + g2*vT2 + g3*vT3)/mu0');
                
                comsol_model.physics('w').feature('weak4').active(true);
                if model.comsol_get_eliminated_data
                    str = mphmatrix(comsol_model,'sol1','Out',{'Lc'});
                    r{2} = str.Lc;
                else
                    str = mphmatrix(comsol_model,'sol1','Out',{'L'});
                    r{2} = str.L;
                end
                disp(['done! time elapsed: ', num2str(toc)]);
                
                


                % daten auf original zuruecksetzen...
                comsol_model.physics('w').feature('wfeq1').set('weak', {char(w_wfeq1); '0'; '0'});
                comsol_model.physics('w').feature('weak1').set('weakExpression', w_weak1);
                comsol_model.physics('w').feature('weak2').set('weakExpression', w_weak2);
                comsol_model.physics('w').feature('weak3').set('weakExpression', w_weak3);
                comsol_model.physics('w').feature('weak4').set('weakExpression', w_weak4);
                comsol_model.physics('w').feature('weak5').set('weakExpression', w_weak5);
                %...und alles wieder aktivieren
                comsol_model.physics('w').feature('ibweak1').active(true);
                comsol_model.physics('w').feature('ibweak2').active(true);
                comsol_model.physics('w').feature('ibweak3').active(true);
                comsol_model.physics('w').feature('weak1').active(true);
                comsol_model.physics('w').feature('weak2').active(true);
                comsol_model.physics('w').feature('weak3').active(true);
                comsol_model.physics('w').feature('weak4').active(true);
                comsol_model.physics('w').feature('weak5').active(true);
                
                
%             % 25.04.14: ZUM TESTEN: die ZEHNERPOTENZEN SCHON IN DIE MATRIZEN MIT
%             % EINBAUEN!
%             keyboard
%             A{2} = A{2}* 1e18;
%             A{3} = A{3}* 1e9;
%             r{1} = r{1}* 1e9;
                 


            else %decomp_mode 1; ~model.use_comsol
                if model.comsol_get_eliminated_data %return eliminated data
                    A = model_data.operators.A_comp_eliminated;
                    r = model_data.operators.f_comp_eliminated;
                else %return full data
                    A = model_data.operators.A_comp_full;
                    r = model_data.operators.f_comp_full;
                end
            end




        case 2
            omega = get_mu(model);
            
%             % 25.04.14: ZUM TESTEN: die ZEHNERPOTENZEN SCHON IN DIE MATRIZEN MIT
%             % EINBAUEN!
%             %keyboard
%             omega=omega/1e9;
            
            
            A = zeros(3,1);
            A(1) = 1;
            A(2) = omega^2;
            A(3) = omega;
            r = zeros(2,1);
            r(1) = omega;
            r(2) = 1;
            
    end %switch
end