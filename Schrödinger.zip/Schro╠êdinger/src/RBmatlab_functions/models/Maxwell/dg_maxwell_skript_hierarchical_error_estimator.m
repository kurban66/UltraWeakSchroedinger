clear, close, clc;

[model,model_data] = dg_maxwell_model_hierarchical_error_estimator;


