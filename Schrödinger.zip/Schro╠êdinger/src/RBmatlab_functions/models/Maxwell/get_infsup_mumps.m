function beta = get_infsup_mumps(model,K,M)
%function beta = get_infsup_mumps(model,K,M)
%
% This function uses 'MUMPS' to calculate the inf sup constant for the
% Operator K with respect to the inner product matrix M
%
% Input:
% =======
% - model (not needed, maybe for later extensions of this file)
% - K : system matrix / operator
% - M : Mass matrix / Inner product matrix
%
% Output:
% =======
% beta: inf sup constant
%
% Oliver Zeeb, 2013


  opts.maxit = 1e3;
  opts.tol = 1e-5;
  opts.isreal = false;
  
  %mumps
  %disp('preparing id_Atransp')
  id_Atransp = initmumps;
  id_Atransp = zmumps(id_Atransp); 
  id_Atransp.JOB = 1;
  id_Atransp=zmumps(id_Atransp,K');
  id_Atransp.JOB = 2;
  id_Atransp = zmumps(id_Atransp,K');
  %disp('done...')
  
  
  %disp('preparing id_A')
  id_A = initmumps;
  id_A = zmumps(id_A); 
  id_A.JOB = 1;
  id_A=zmumps(id_A,K);
  id_A.JOB = 2;
  id_A = zmumps(id_A,K);
  %disp('done')
  
  %lambda = eigs(@(x) stiffFun(x,id_Atransp,id_A,K,M), ...
  %              size(K,1),M,1,'sm',opts);
  
  lambda = eigs(@(x) stiffFun(x,id_Atransp,id_A,K,M),size(K,1),1,'sm',opts);
  beta = sqrt(lambda);
  
  id_A.JOB = -2;
  id_A=zmumps(id_A);
  id_Atransp.JOB = -2;
  id_Atransp=zmumps(id_Atransp);
  
  
  
function y=stiffFun(x,id_Atransp,id_A,A,B)

    %disp('calculating y = A''\x;')
    %tic;
    id_Atransp.JOB = 3;
    id_Atransp.RHS = (B*x);
    id_Atransp=zmumps(id_Atransp,A');
    y = id_Atransp.SOL;
    %disp('done')
    
    %disp('now calculating y = A\(B*y)')
    id_A.JOB = 3;
    id_A.RHS = (B*y);
    id_A=zmumps(id_A,A);
    y = id_A.SOL;
    %disp('done...')
    %toc;
    
    
    
