function infsupLB = comsol_MaxwellDG_infsupLB(model)
%function infsupLB = comsol_MaxwellDG_infsupLB(model)
%
% Different possibilitys to calculate the infsup constant:
% see page 115 in Kristin Kirchners Master Thesis
%
% Input:
% =======
% model: Maxwell DG model
%
% Output:
% =======
% infsupLB: lower bound of the inf sup constant for parameter \mu
%
%
% Oliver Zeeb, 2013

sigma_inf   = model.sigma;
mu_inf      = model.mu0;
mu_sup      = model.mu0;
eps_sup     = model.epsilon0;
omega       = model.omega;
%C_inv = model.C_inv;
%tau         = 16*C_inv*(omega^2*eps_sup^2+sigma_inf^2)/(mu_inf*sigma_inf^2);




expr1 = sigma_inf / (4 * mu_sup * sqrt(omega^2*eps_sup^2+sigma_inf^2));
expr2 = omega/sqrt(2)*sqrt(  (omega^2*eps_sup^2*sigma_inf^2+sigma_inf^4) ...
        / (2*omega^2*eps_sup^2 + sigma_inf^2) );
%expr3 = (tau*sigma_inf / (2*sqrt(omega^2*eps_sup^2 + sigma_inf^2)))...
%        - 8*C_inv*mu_sup*sqrt(omega^2*eps_sup^2+sigma_inf^2) / (mu_inf^2*sigma_inf);
    
infsupLB = min([expr1, expr2]);