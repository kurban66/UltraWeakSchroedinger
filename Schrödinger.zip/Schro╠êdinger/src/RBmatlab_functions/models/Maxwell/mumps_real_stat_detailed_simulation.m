function sim_data = mumps_real_stat_detailed_simulation(model,model_data)
%function sim_data = mumps_real_stat_detailed_simulation(model,model_data)
%
% function performing a detailed simulation using the real version of the solver MUMPS.
% This file was especially written for the Maxwell DG model investigated in
% Kristin Kirchners Master Thesis.
% This file also supports the usage of COMSOL as solver via the switch:
% model.use_comsol = 0 / 1;
%
% Input:
% =======
% - model: (Maxwell) model
% - model_data
%
% Output:
% =======
% - sim_data: struct containing the detailed solution sim_data.U
%
% Oliver Zeeb, 07.01.2014

if model.use_comsol %let comsol do all the work!
        comsol_model = model_data.comsol_model;
        comsol_model = comsol_set_mu_from_rbmatlab_model(model,comsol_model); %set the mu in the comsol model

        %activate stationary solver ( if deactivated in COMSOL)
        comsol_model.sol(model.comsol_tags.sol).feature('s1').active(true);

        % execute COMSOL Simulation
        comsol_model.sol(model.comsol_tags.sol).runAll;

        %get solution from comsol:
        sim_data.U = mphgetu(comsol_model);
        sim_data.comsol_model=comsol_model;

        % compute output
        if model.compute_output_functional
          sim_data.s = comsol_model.result().numerical(model.comsol_tags.output).getReal();
        end;
        
else  %do the work by hand --> use only matlab!
    %     1. get operator matrices --> they are in model data!
    %     2. get parameter
    %     3. linear combination of 1. and 2
    %     4. Solve the linear system using MUMPS
    %     5. blow up the solution vector
    %     (6. add particular solution ud)
    %     7. compute output functional with the full solution!
    
    model.comsol_get_eliminated_data = 1;
    % 1.
    model.decomp_mode = 1;
    [A_comp, f_comp] = model.operators(model,model_data);
    
    % 2.
    model.decomp_mode = 2;
    [A_coeff,f_coeff] = model.operators(model,model_data);
    
    % 3.
    Ac = lincomb_sequence(A_comp, A_coeff);
    fc = lincomb_sequence(f_comp, f_coeff);
    
    % 4.
    id=initmumps;
    id=dmumps(id); 
    disp('performing analysis...')
    tic;
    id.JOB = 1;
    id=dmumps(id,Ac);
    disp(['done! time elapsed: ', num2str(toc)]);
    disp('performing factorization...')
    tic;
    id.JOB = 2;
    id=dmumps(id,Ac);
    disp(['done! time elapsed: ', num2str(toc)]);
    disp('performing solution...')
    tic;
    id.JOB = 3;
    id.RHS = fc;
    id=dmumps(id,Ac);
    disp(['done! time elapsed: ', num2str(toc)]);
    u = id.SOL;
    disp('destroy data...')
    id.JOB = -2;
    id=dmumps(id);
    disp('done!')
    disp('finished calculation of the detailed simulation!')
    
    % 5. blow up the solution to the full dimension:
    double_length_u = length(u);
    length_u = double_length_u *0.5;
    sim_data.u_big = u;
    sim_data.u_real = u(1:length_u);
    sim_data.u_imag = u(length_u+1:end);
    %detailed_simulation anschauen!!!
    %sim_data.U = model_data.ind_vectors.Null*(u(1:length_u) + i*u(length_u+1:end));
    %disp('set k'); keyboard;
    %figure(k)
    %plot_sim_data(model,model_data,sim_data,'pg1')
    sim_data.U = u;
    
    
    % 6. add particular solution ud
    %sim_data.U = sim_data.U + model_data.operators.ud;
    
    % 7.
    if model.compute_output_functional
        model.comsol_get_eliminated_data = 0;
        model.decomp_mode = 1;
        output_comp = model.operators_output(model,model_data);
        model.decomp_mode = 2;
        output_coeff = model.operators_output(model,model_data);
        output_operator = lincomb_sequence(output_comp, output_coeff);
        sim_data.s = output_operator' * sim_data.U;
        sim_data.s_with_ud = output_operator' * (sim_data.U + model_data.operators.ud);
    end
    
    
end %of model.use_comsol
    


%add some fields to sim_data
sim_data.ind_vectors = model_data.ind_vectors;