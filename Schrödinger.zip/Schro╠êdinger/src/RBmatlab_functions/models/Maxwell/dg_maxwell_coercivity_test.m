clear, close, clc;

%% Prepare model & model_dat
[model,model_data] = dg_maxwell_model_standard_error_estimator;

%M_train = linspace(model.mu_ranges{1}(1),model.mu_ranges{1}(2),5);

M_train = 1e12;

model.decomp_mode = 0;
alpha = zeros(1,length(M_train));

for i = 1:length(M_train)
    mu = M_train(i);
    model = model.set_mu(model,mu);
    [A,~] = model.operators(model,model_data);
    A = (A+A')/2;
    alpha(i) = get_coercivity_mumps(model,A,model_data.W);
end

%plot(M_train,alpha,'r*-');