function err = comsol_imag_stat_error_algorithm(Udet, Ured, InProdMat, model)
%function err = comsol_imag_stat_error_algorithm(Udet, Ured, InProdMat, model)
%
% This function computes the true error between two solutions Udet and Ured
% in a norm specified by the inner product matrix InProdMat. This function
% works for imaginary models and returns a real scalar.
%
% Input:
% =======
% - Udet, Ured: 2 solution vectors
% - InProdMat:  According Inner product matrix
% - model : optional, not needed so far
%
% Output:
% =======
% - err: real scalar error between the solutions Udet and Ured
%
% Oliver Zeeb, 2013



err = sqrt(real((Udet-Ured)' * InProdMat *(Udet-Ured)));