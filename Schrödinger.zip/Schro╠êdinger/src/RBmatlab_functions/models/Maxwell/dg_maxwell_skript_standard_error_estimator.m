clear, close, clc;

%% Prepare model & model_dat
[model,model_data] = dg_maxwell_model_standard_error_estimator;

%% Now make RB:
detailed_data = model.gen_detailed_data(model,model_data);



%% Plot the whole damn thing
filename = '/Users/Flad/Desktop/Auswertungen/DG_Maxwell_StdErrEst';

if ~isdir(filename)
    mkdir(filename);
else
    rmdir(filename,'s');
    mkdir(filename);
end



left=model.mu_ranges{1}(1);
right=model.mu_ranges{1}(2);
testspace = linspace(left,right,100);
Ntest = length(testspace);

error_truth = zeros(1,Ntest);
error_est = zeros(1,Ntest);
online_time = zeros(1,Ntest);

W = detailed_data.W;

reduced_data = model.gen_reduced_data(model,detailed_data);
Nmax = model.get_rb_size(model,detailed_data);

for N=Nmax-2:Nmax
    
    model.N = N;
    rD = model.reduced_data_subset(model,reduced_data);
    
    for i=1:Ntest
        model.mus = testspace(i);
        
        sim = model.detailed_simulation(model,detailed_data);
        uh = model.get_dofs_from_sim_data(sim);
        tic
        rS = rb_simulation(model,rD);
        online_time(i) = toc;
        
        RB = detailed_data.RB(:,1:N);
        uN = RB*rS.uN;
        
        error_truth(i) = sqrt(abs((uh - uN)' * W *(uh - uN)));
        error_est(i) = model.get_estimator_from_sim_data(rS);
        i
    end
    
    figure
    set(gcf, 'Position', get(0, 'Screensize'));
    
    %h=plot(testspace,error_est,'b^-',testspace,error_truth,'r-','MarkerSize',20);
    h=plot(testspace,error_est,'b',testspace,error_truth,'r--','MarkerSize',20);
    title(['N=' num2str(N)])
    xlabel('\mu')
    l=legend({'$\Delta_N^{\mathrm{Std}}$','$\|u^\mathcal{N} ( \mu) - u_N ( \mu)\|_{X^\mathcal{N}}$'},'interpreter','latex');
    set(l,'FontSize',30,'Location','northwest');
    set(gca,'FontSize',26)
    set(h(1),'linewidth',4);
    set(h(2),'linewidth',4);
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.jpg'];
    saveas(gcf,name)
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.eps'];
    saveas(gcf,name,'epsc')
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.fig'];
    saveas(gcf,name)
    
    figure
    set(gcf, 'Position', get(0, 'Screensize'));
    %h=semilogy(testspace,error_est,'b^-',testspace,error_truth,'r*-','MarkerSize',20);
    h=semilogy(testspace,error_est,'b',testspace,error_truth,'r--','MarkerSize',20);
    title(['N=' num2str(N)])
    xlabel('\mu')
    l=legend({'$\Delta_N^{\mathrm{Std}}$','$\|u^\mathcal{N} ( \mu) - u_N ( \mu)\|_{X^\mathcal{N}}$'},'interpreter','latex');
    set(l,'FontSize',30,'Location','northwest');
    set(gca,'FontSize',24)
    set(h(1),'linewidth',4);
    set(h(2),'linewidth',4);
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.jpg'];
    saveas(gcf,name)
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.eps'];
    saveas(gcf,name,'epsc')
    name = [filename '/DG_Maxwell_StdErrEst_N=' num2str(N) '.fig'];
    saveas(gcf,name)
    close all;
    
end


filename = [filename '/data'];
save(filename);