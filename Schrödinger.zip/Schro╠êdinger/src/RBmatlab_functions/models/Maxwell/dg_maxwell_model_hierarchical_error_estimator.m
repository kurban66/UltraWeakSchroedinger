function [model, model_data] = dg_maxwell_model_hierarchical_error_estimator()
%% First, load the model:

load('/Users/Flad/Desktop/DGMaxwell/DG_Maxwell_Refinement_5.mat');

model.use_comsol = 0;
model.mu_ranges={[1e9,50e9]};
model.RB_stop_Nmax = 50;
model.RB_numintervals = 4900;
model.gen_detailed_data = @lin_stat_gen_detailed_data_hier_err_est;
model.rb_simulation= @stabilized_lin_stat_rb_simulation;
model.rb_reconstruction = @rb_reconstruction_without_femdiscfunc;
model.RB_extension_algorithm = @RB_ext;
model.save_detailed_simulations = @save_detailed_simulations;
model.RB_detailed_train_savepath='';
model.reduced_data_subset = @reduced_data_subset;
model.RB_error_indicator = 'estimator';
model.get_estimator_from_sim_data = @est_from_sim_data;
model.get_residual_for_basis_extension = @(sim_data) sim_data.reduced_data_M.res_norm_sqr;
model.RB_generation_mode = 'model_RB_basisgen';
model.RB_basisgen = @rb_basis_generation_with_hier_err_est;


%% For error estimator:
model.constant_for_error_estimator = @get_constant_for_error_estimator;
model.discrepancy = 1;
model.RB_stop_epsilon = 1e-4;
model.plot_estimator = 0;
model.get_constant_for_error_estimator = @get_constant_for_error_estimator;
model.compute_constant = 1;

model.rb_init_data_basis = @maxwell_init_data_basis;

%% model_data anpassen:
model_data.W = [];
model_data.W = model_data.inner_product_matrices.DG;
end





function detailed_data = maxwell_init_data_basis(model,detailed_data)

first_mu = detailed_data.RB_info.M_train(1);

model=model.set_mu(model,first_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,1) = model.get_dofs_from_sim_data(sim_data);

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);


reduced_data = model.gen_reduced_data(model,detailed_data);
fct_temp = model.get_estimator_from_sim_data;
model.get_estimator_from_sim_data = @(sim_data) sim_data.res_norm_sqr(end);

model.N = 1;
post_errs = rb_test_indicator(model,...
    detailed_data, reduced_data,...
    detailed_data.RB_info.M_train,...
    []);


model.get_estimator_from_sim_data = fct_temp;


[max_res,ind] = max(post_errs);
detailed_data.RB_info.max_residual_sequence(1) = max_res;
second_mu = detailed_data.RB_info.M_train(:,ind);

model=model.set_mu(model,second_mu);
sim_data = detailed_simulation(model,detailed_data);
u(:,2) = model.get_dofs_from_sim_data(sim_data);


% Orthonormalisation of the Init-Data-Basis
W = detailed_data.W;
if(max(max(abs(u'*W*u)-eye(size(u,2))))>1e-12)
    disp('orthogonalising the init values')
    u = model_orthonormalize_qr(model, detailed_data ,u);
end

detailed_data = model.set_rb_in_detailed_data(...
    detailed_data,...
    u);


detailed_data.RB_info.mu_sequence(:,1) = first_mu;
detailed_data.RB_info.mu_sequence(:,2) = second_mu;
end




function err = est_from_sim_data(sim_data,reduced_data)

uN = sim_data.uN;
uM = sim_data.reduced_data_M.uN;

rDM = reduced_data.reduced_data_M;

theta = reduced_data.theta;

err_temp = abs(uM'*rDM.WMM*uM + uN'*rDM.WNN*uN - ...
    uM'*rDM.WMN*uN - uN'*rDM.WNM*uM);

err = 1/(1-(theta)) * (sqrt(err_temp)); 

end