function infsup_beta_LB = get_infsup_minTheta(model)
% function infsup_beta = get_infsup_minTheta(model)
%
% This function uses the min-Theta-Ansatz for calculating a lower bound of
% the inf sup constant. The inf sup constant must be known for one specific
% parameter mu. This information must be stored in 
% model.min_theta. ...
%
% Input:
% =======
% model: Maxwell model
%
% Required fields in model:
% -------------------------
%  model.min_theta.infsup_beta_strich : the inf sup constant for one specific parameter value
%  model.min_theta.coeff_mu_strich    : the coefficients for this parameter
%  model.min_theta.mu_strich          : the coefficient used for the detailed calculation of the inf sup constant
%
% Output:
% =======
% infsup_beta_LB: lower bound of inf sup constant calculated with the min theta ansatz
%
% Oliver Zeeb 15.01.2014



%get stored values for one specific parameter mu
beta_strich = model.min_theta.infsup_beta_strich;
%mu_strich = model.min_theta.mu_strich;
coeff_mu_strich = model.min_theta.coeff_mu_strich;

% calculate coefficient functions theta^q(mu)
model.decomp_mode=2;
A_coeff = model.operators(model,[]);


theta_quot = A_coeff./coeff_mu_strich;
infsup_beta_LB = beta_strich * min(theta_quot);


