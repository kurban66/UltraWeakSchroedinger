function [model, model_data] = dg_maxwell_model_standard_error_estimator()
%% First, load the model:

load('/Users/Flad/Desktop/DGMaxwell/DG_Maxwell_Refinement_5.mat');

model.use_comsol = 0;
model.mu_ranges={[1e9,50e9]};
model.RB_stop_Nmax = 50;
model.RB_numintervals = 4900;
model.gen_detailed_data = @lin_stat_gen_detailed_data_hier_err_est;
model.rb_simulation= @stabilized_lin_stat_rb_simulation;
model.rb_reconstruction = @rb_reconstruction_without_femdiscfunc;
model.RB_extension_algorithm = @RB_ext;
model.save_detailed_simulations = @save_detailed_simulations;
model.RB_detailed_train_savepath='';
model.get_inner_product_matrix = @(detailed_data,model) detailed_data.W;
model.gen_reduced_data = @stabilized_lin_stat_gen_reduced_data;
model.reduced_data_subset = @reduced_data_subset;
model.get_estimator_from_sim_data = @est_from_sim_data;
model.RB_error_indicator = 'estimator';
model.gen_detailed_data = @lin_stat_gen_detailed_data_std_err_est;
model.set_rb_in_detailed_data = @lin_stat_set_rb_in_detailed_data;
model.filecache_ignore_fields_in_model = {'N','Nmax'};
model.filecache_ignore_fields_in_detailed_data = {'RB_info'};
model.orthonormalize = @orthonormalize_qr;

%% model_data anpassen:
model_data.W = [];
model_data.W = model_data.inner_product_matrices.DG;

%% For error estimator:
mu = model.mu_ranges{1}(2);
model = model.set_mu(model,mu);
[A,~] = model.operators(model,model_data);
model.infsup_lb = real(get_infsup_mumps(model,A,model_data.W));

model.use_scm=0;
model.get_estimator_from_sim_data = ...
    @(sim_data) sim_data.res_norm/sim_data.infsup_lb;
model.rb_init_data_basis = @maxwell_init_data_basis;


end






function u = maxwell_init_data_basis(model,model_data)
    mu = model.mu_ranges{1}(1);
    model=model.set_mu(model,mu);
    sim_data = detailed_simulation(model,model_data);
    u(:,1) = model.get_dofs_from_sim_data(sim_data);
end



function err = est_from_sim_data(sim_data,reduced_data)

uN = sim_data.uN;
uM = sim_data.reduced_data_M.uN;

rDM = reduced_data.reduced_data_M;

theta = reduced_data.theta;

err_temp = abs(uM'*rDM.WMM*uM + uN'*rDM.WNN*uN - ...
    uM'*rDM.WMN*uN - uN'*rDM.WNM*uM);

err = 1/(1-(theta)) * (sqrt(err_temp)); 

end