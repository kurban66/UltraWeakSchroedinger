function alpha = get_coercivity_mumps(model,K,M)
%function beta = get_infsup_mumps(model,K,M)
%
% This function uses 'MUMPS' to calculate the coercivity constant for the
% Operator K with respect to the inner product matrix M
%
% Input:
% =======
% - model (not needed, maybe for later extensions of this file)
% - K : system matrix / operator
% - M : Mass matrix / Inner product matrix
%
% Output:
% =======
% beta: coercivity constant


  opts.maxit = 1e3;
  opts.tol = 1e-5;
  opts.isreal = false;
 
  
  %disp('preparing id_A')
  id_A = initmumps;
  id_A = zmumps(id_A); 
  id_A.JOB = 1;
  id_A=zmumps(id_A,K);
  id_A.JOB = 2;
  id_A = zmumps(id_A,K);
  %disp('done')

  lambda = eigs(@(x) stiffFun(x,id_A,K,M),size(K,1),1,'sm',opts);
  alpha = sqrt(lambda);
  
  id_A.JOB = -2;
  id_A=zmumps(id_A);
  
  
  
function y=stiffFun(x,id_A,A,B)
    
    id_A.JOB = 3;
    id_A.RHS = (B*x);
    id_A=zmumps(id_A,A);
    y = id_A.SOL;

    
    
    
