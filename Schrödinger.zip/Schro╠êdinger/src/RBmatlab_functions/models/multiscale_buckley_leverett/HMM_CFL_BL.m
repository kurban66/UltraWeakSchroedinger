function [DT,N_T,dx,dt,LAMBDA]=HMM_CFL_BL(DX,T,epsilon,M)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                     Bestimmung der Ortsschrittweiten                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [DT,N_T,dx,dt,LAMBDA]=HMM_CFL_BL(DX,T,epsilon,M)
%
% Input:  DX                   makroskopische Ortsschrittweite
%         T                    Endzeit (fuer Makrorechnung)
%         epsilon              Regularisierungsparameter
% Output: DT                   makroskopische Zeitschrittweite
%         N_T                  Anzahl makroskopische Ortsschritte
%         dx, dt               mikroskopische Orts- bzw. Zeitschrittweite
%         LAMBDA               Abkuerzungen fuer Verhaeltnisse


% mikroskopische Ortsschrittweiten
dx = 1.5*epsilon;
s = (0:0.001:1);
h = -(2*s*M.*(s-1))./(s.^2+M-2*M*s+M*s.^2).^2;
w = max(h);
clear h s
dt = 0.95*min(dx^2/(2*epsilon),dx/w);

DT=0.95*(DX/w); % makroskopische Zeitschrittweite mit CFL-Bedingung fuer grobes Gitter
N_T=round(T/DT);

LAMBDA=DT/DX;