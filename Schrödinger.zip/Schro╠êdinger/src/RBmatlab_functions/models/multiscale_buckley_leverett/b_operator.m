function [b,index_n]=b_operator(mu,u,index,M,epsilon,dx)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                b-Operator fuer Buckley-Leverett Problem             %%%
%%%               b = epsilon D(u)_x u_x + D(u)u_xx - f(u)_x            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input: mu        Parameter
%        u         Lsg u, wird komplett eingelesen und liest dann
%                  \in IR^{|index|x1} aus
%        index     Inidice-Menge, auf der lokale Lsg berechnet werden soll, 
%                  fuer index=[] global berechnen
%        M         Viskositaetsverhaeltnis
%        epsilon   Regularisierungsparameter
%        dx        Ortsschrittweite
% 
% Output: b        Auswertung des b-Operators, d.h. rechte Seite des
%                  BL-Problems, \in IR^{|index_n|x1}
%         index_n  neue Indexmenge, nimmt von jedem Miniintervall einen 
%                  Randpunkt weg

%

if isempty(index)   % globale Lsg
    
    n_x = length(u);
    b = zeros(n_x,1);   % initialisieren
    b(1) = epsilon*BL_D(u(1),M)*(u(2)-u(1))/(dx)^2;   % OE Intervall so groß, inflow/outflow
    for i=2:n_x-1  
        b(i) = epsilon*(BL_D(u(i),M)*(u(i+1)-u(i))-BL_D(u(i-1),M)*(u(i)-u(i-1)))/(dx^2)-(BL_f(u(i),M)-BL_f(u(i-1),M))/dx;
    end
    b(n_x) = -epsilon*BL_D(u(n_x-1),M)*(u(n_x)-u(n_x-1))/(dx)^2-(BL_f(u(n_x),M)-BL_f(u(n_x-1),M))/dx;
    index_n = [];
    
else   % lokale Lsg
    index = sort(index);
    B = [];
    Ie = [];
    Ia = 1;
    I = [];
    for i=1:length(index)-1;
        if index(i+1)-index(i)==0
            error('Index kommt doppelt vor');
        elseif index(i+1)-index(i)>1     % Zusaetzliche Abfrage, dass mind 3 aufeinanderfolgende Werte
            Ia = [Ia, i+1];
            Ie = [Ie, i];
        end
    end
    Ie = [Ie,length(index)];
        
    for i=1:length(Ie)
        ni = Ie(i)-Ia(i)+1;  % Anzahl aufeinanderfolgender Stuetzstellen
        if ni<=2
           error('Zu wenig aufeinanderfolgende Stuetzstellen.') 
        end
        
        uc = u(index(Ia(i)):index(Ie(i)));
        b = zeros(ni,1);   % initialisieren
        for k=2:ni-1  
            b(k) = epsilon*(BL_D(uc(k),M)*(uc(k+1)-uc(k))-BL_D(uc(k-1),M)*(uc(k)-uc(k-1)))/(dx^2)-(BL_f(uc(k),M)-BL_f(uc(k-1),M))/dx;
        end
        b(1) = [];
        b(end) = [];
                
        B = [B;b];
        I = [I,index(Ia(i)+1):index(Ie(i)-1)];
        
    end
    b = B;
    index_n = I;
    
end