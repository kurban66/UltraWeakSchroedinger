function [v,um]=HMM_UM_GESCHW_BL(u2,dx,n_x)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%    Berechnung des mittleren Zustands um und der Geschwindigkeit     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [v,um]=HMM_UM_GESCHW(u2,dx,n_x)
%
% Input:    u2         L?sung des mikroskopischen Modells
%           dx, n_x    mikroskopische Ortsschrittweite bzw. Anzahl
%                      mikroskopischer Ortsschritte
% Output:   v          Geschwindigkeit der Unstetigkeit
%           um         mittlerer Zustand


% Bestimmung der Geschwindigkeit v der Unstetigkeit.
% Bestimme in u die Stelle der Komponente, bei der die Steigung am geringsten
% ist, bevor sie wieder zum ersten mal steigt. Somit erhaelt man den
% Zwischenzustand um.


u2 = u2(end:-1:1);   % Vekor umdrehen



a=(u2>=0.5);
k=find(a==1, 1 );
S=zeros(1,n_x);
for i=k+1:n_x
    S(i)=abs((u2(i)-u2(i-1))/dx);
end
b=S(k+1:end);
S(1:k)=-1;   % damit spaeter nicht M darin liegt.
l=[];
for j=2:length(b)
    if b(j)>b(j-1)             % BESSER MIT ABBRUCHKRITERIUM IMPLEMENTIEREN
        l=[l j];
    end
end
z=l(1);
m=b(z-1);
M=find(S==m);
L=M(1);

% Wert des Zwischenzustandes
um=u2(L);

% Berechnung der Geschwindigkeit mit Rankine-Hugoniot-Bedingung
v=BL_f(um,2)/um;