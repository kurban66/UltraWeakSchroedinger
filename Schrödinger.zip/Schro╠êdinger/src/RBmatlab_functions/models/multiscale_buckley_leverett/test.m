function [fehler]=test(Tmicro,Ul,tau,n_x)
%
% function [fehler]=test(T,Ul,tau,n_x)
%
% Bsp: [fehler]=test(3*10^(-3),0.75,10,300)
%
% Input:   T              Endzeit fuer mikroskopische Problem
%          Ul             linker Anfangszustand
%          tau            Parameter
%          n_x            Anzahl mikroskopischer Ortsschritte
%                         Gitterpunkte einschliesslich Randpunkte
% Output:  fehler         Fehler zwischen globaler und lokaler Loesung



close all;

Time=3;   % Endzeit fuer HMM-Berechnung

% Regularisierungsparameter und Ortsskalierung
epsilon = 0.00001;

%  Intervall = x in [0, epsilon*1.5*n_x];

M = 2;   % water/oil viscosity ratio

%%%%%%%%%%%%%%%   makroskopische Ortsschrittweite   %%%%%%%%%%%%%%%%%%%%%%%
DX=0.02;

%%%%%%%%%%%   Anzahl der Schritte auf mikroskopischer Skala   %%%%%%%%%%%%%
n = n_x-2; 

%%%%%%%%%%%%%%%%%%%%%%%%   Anfangsdaten   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[U,Ur,xfront,lR,rR,X,N_X]=HMM_AB_U0_BL(DX,Ul);    

%%%%%%%%%%%%%%%%%%%%%%%%%   Schrittweiten   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[DT,N_T,dx,dt,LAMBDA]=HMM_CFL_BL(DX,Time,epsilon,M);
n_t=round(Tmicro/dt)-1;   % Anzahl mikroskopischer Zeitschritte

%%% Diskretisierungsmatrix A in IR^{(nx-2)x(nx-2)}
a = 2+dx^2/(epsilon^2*tau);
c = epsilon^2*tau/(dx^2);
A = c*(diag(a*ones(1,n))+diag(-ones(1,n-1),1)+diag(-ones(1,n-1),-1));

%%% Inverse der Tridiagonalmatrix A
%[T]=INVERSE_TRIDIAG(A);
T = inv(A);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % 1.Schritt: stueckweise konstante Rekonstruktion von u=RU
    [u,x,s]=HMM_REKONSTRUKTION(U,xfront,X,dx,n_x);
        
    disp(u)
%    keyboard;
    
    % 2.Schritt: Loesung des mikroskopischen Modells mit den Anfangsdaten u=RU
    % auf dem mikroskopischen Gitter -> gibt Loesung u zurueck
    
    for iter=1:n_t    % global Loesung zum Zeitpunkt T-dt
        [u_new,w]=HMM_MIKRO_teil(T,u,epsilon,tau,dx,dt,n_x,M);
	u_test = u + dt*w';	
	if ~isequal(u_new,u_test)
	  error('timestepping inconsistent');
	end;
	u = u_new;
    end
    u_sicher = u;
            
    i1=(15:1:20);
    i2=(150:1:170);
    i3=(190:1:210);
    i4=(230:1:235);
    index=[i1,i2,i3,i4];
         
    % lokale Loesung zum Zeitpunkt T
    [u,w,index_n]=HMM_MIKRO_teil(T,u_sicher,epsilon,tau,dx,dt,n_x,M,index); 
    X = x(index_n);
        
    % kontrolle/ global Loesung zum Zeitpunkt T
    [u_kontrolle,w_k]=HMM_MIKRO_teil(T,u_sicher,epsilon,tau,dx,dt,n_x,M);
    
    % Fehler zwischen globaler und lokaler Loesung
    fehler = max(abs(u_kontrolle(index_n)-u));
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  PLOT     

figure  % Plot zu u-Werten
plot(x,u_sicher,'g','LineWidth',2)
hold on
plot(x,u_kontrolle,'LineWidth',2)
plot(X,u,'ro')
title('u')
legend('globale Lsg bei T-dt','globale Lsg bei T','lokale Lsg bei T')
xlabel('x')

figure   % Plot zu w-Werten
plot(x,w_k*dt)
hold on
plot(X,w*dt,'ro')
title('w')
xlabel('x')