function [U0,Ur,xfront,lR,rR,X,N_X]=HMM_AB_U0_BL(DX,Ul)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                         ANFANGSDATEN FUER U                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [U0,Ur,xfront,lR,rR,X,N_X]=HMM_AB_U0_BL(DX,Ul)
%
% Input:  DX                makroskopische Ortsschrittweite
%         Ul                linker Anfangszustand
% Output: U0                Anfangsbedingung
%         Ur, xfront        rechter Zustand und Stelle der
%                           Unstetigkeit 
%         lR,rR             linker bzw. rechter Intervallrand
%         X                 Vektor mit Gitterpunkten
%         N_X               Anzahl makroskopische Gitterpunkte


lR=0;   % linker Intervallrand auf Makroskala
rR=6;   % rechter Intervallrand


Ur=0;
xfront=0;

X=(lR:DX:rR);
N_X=length(X);    % Anzahl Ortsschritte makroskopisches Gitter


% Initialisierung von U

U=zeros(1,N_X);    

for j=1:N_X
    if X(j)<=xfront
        U(j)=Ul;
    else
        U(j)=Ur;
    end
end

U0=U;
