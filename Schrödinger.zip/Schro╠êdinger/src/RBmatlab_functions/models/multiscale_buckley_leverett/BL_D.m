function D=BL_D(u,M)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%         Dispersion bei erweiterter Regularisierung der BL           %%%
%%% u_t + f(u)_{x} = epsilon (D(u)u_{x})_{x} + epsilon^{2}*tau*u_{xxt}  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% eigentlich muesste es 
%   u_t + f(u)_{x} = epsilon [D(u)(u_{x} + epsilon*tau*u_{xt})]_{x}
% sein.
% WIRD SO IN D(U)allg VERWENDET
%
% function D=BL_D(u)


D = zeros(size(u));

for k=1:length(u)
    %D(k) = 1;
    D(k) = (u(k)^2*(1-u(k))^2)/(u(k)^2+M*(1-u(k))^2);  % M=2 bis jetzt fest, entsprechend aendern!!! 
end
    