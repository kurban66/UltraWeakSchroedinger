function [u,x,s]=HMM_REKONSTRUKTION(U,xfront,X,dx,n_x)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%              stueckweise konstante Rekonstruktion                   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [u,x,s]=HMM_REKONSTRUKTION(U,xfront,X,dx,n_x)
%
% Input:  U          derzeitige makroskopische Loesung
%         xfront     Stelle der Unstetigkeit
%         X          Vektor, makroskopische Gitterpunkte
%         dx, n_x    mikroskopische Ortsschrittweite bzw. Anzahl
%                    mikroskopische Ortsschritte
% Output: u          stueckweise konstante Rekonstruktion der L?sung
%         x          Vektor, mikroskopische Gitterpunkte
%         s          Gitterpunkt an dem sich die Unstetigkeit befindet



x=(xfront:dx:xfront+(n_x-1)*dx);

% Berechnung des Intervalls I=(A,B], A,B \in X, so dass xfront \in I
a=(X<=xfront);
s=find(a==1, 1, 'last' );
%A=X(s);
%B=X(s+1);

% Konstruiere u=RU durch stueckweise konstante Rekonstruktion
u=zeros(1,n_x);   % initialisieren
if (s-1)<=0
    u(1)=U(1);
else
    u(1)=U(s-1);
end
for i=2:n_x
       u(i)=U(s+2);  
end            