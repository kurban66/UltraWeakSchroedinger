function sim_data = st_detailed_simulation(model,model_data)

old_mode = model.decomp_mode;

model.decomp_mode = 0;
[A,b] = model.operators(model,model_data);

sim_data =[];


uh.dofs = A\b;
uh.dofs;

% return results:
sim_data.uh = uh;

% % compute output
% if model.compute_output_functional
%   % the following can be used for any, also nonlinear functionals:
%   %sim_data.s =
%   %model.output_functional(model,model_data,sim_data.uh);
%   % for linear operators, get vector:
%   v = model.operators_output(model,model_data);
%   sim_data.s = (v(:)') * sim_data.uh.dofs;
% end;

model.decomp_mode = old_mode;