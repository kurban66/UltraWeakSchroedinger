clear, close, clc;


%% Initialization
mu = 1;
T = 1;

params.xrange = [0,1];
params.xnumintervals = 25;

params.trange=[0,T];
params.tnumintervals = 30;

params.pdeg = 3;
params.pdeg_time = 3;

model = dg_heatequation_model(params);
model = model.set_mu(model,mu);

model_data = model.gen_model_data(model);



%% A detailed solution:
[m,n] = size(model_data.operators.b);

A = [kron(model_data.operators.A_time, model_data.L2_space) - mu^2 * kron(model_data.L2_time, model_data.operators.A_space)];

b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);

uh = A\b;
%uh = gmres(A,b,10,1e-4,100000);

uh = reshape(uh(1:m*n),m,n);

model.mus = mu;

% Dirichlet in space:
uh = [zeros(1,n) ; uh ; zeros(1,n)];

% Dirichlet in time:
uh = [zeros(m+2,1) , uh];


%% Exact solution:
%u_ex = @(x) (1./(pi^2*mu^2))*(1-cos(t(i).*mu.*pi)).*sin(pi*x);
u_ex = @(t,x) (1./(pi^2*mu^2))*(1-cos(t.*mu.*pi)).*sin(pi*x);

%% Movie
model.plot_solution_movie(model,model_data,uh,u_ex);
%model.plot_solution_movie(model,model_data,uh,u_ex);

%% Plot
%{
temp_space = params.pdeg+1:params.pdeg+1:params.xnumintervals*(params.pdeg+1)-(params.pdeg+1); % Loesche doppelte Werte (DG)
temp_time = params.pdeg_time+1:params.pdeg_time+1:params.tnumintervals*(params.pdeg_time+1)-(params.pdeg_time+1); % Loesche doppelte Werte (DG)

uh(temp_space,:) = [];
uh(:,temp_time) = [];

space = linspace(0,1,size(uh,1));
time = linspace(0,T,size(uh,2));

for i = 1:length(time)
    y_values(:,i) = u_ex(time(i),space)';
    y_limit(i) = max(uh(:,i));
end

y_limit = max(y_limit);

for i=1:length(time)
    plot(space,uh(:,i),space,y_values(:,i),'linewidth',2)
    title([{'L\"osung der W\"armeleitungsgleichung f\"ur t = ' num2str(time(i))}],'interpreter','Latex')
    legend({'Numerische L\"osung','Exakte L\"osung'},'interpreter','Latex')
    xlabel({'x-Achse'},'interpreter','Latex')
    ylabel({'y-Achse'},'interpreter','Latex')
    ylim([0,y_limit])
    pause(0.2)
end
%}