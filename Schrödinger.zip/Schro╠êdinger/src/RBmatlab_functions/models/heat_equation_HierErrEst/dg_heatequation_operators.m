function [A,r] = dg_heatequation_operators(model,model_data)


if model.decomp_mode == 0 % == complete: simple addition
    
    
    % m = space
    % n = time
    [m,n] = size(model_data.operators.b);
    
    mu = model.get_mu(model);
    A = [kron(model_data.operators.A_time,model_data.L2_space) ...
        - (mu^2)*kron(model_data.L2_time, model_data.operators.A_space)];
    
    r = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
    r = r(:);
    
    %nr = length(r);
    %r = [zeros(nr,1);r];
    
    
elseif model.decomp_mode == 1 % == components: merge to cell arrays
    
    
    % m = space
    % n = time
    %[m,n] = size(model_data.operators.b);
    
    A{1} = kron(model_data.operators.A_time,model_data.L2_space);
    A{2} = kron(model_data.L2_time,model_data.operators.A_space);
    
    %A = [{kron(model_data.operators.A_time,model_data.L2_space)},...
    %    {kron(model_data.L2_time,model_data.operators.A_space)}];
    
    %A{1} = [kron(model_data.operators.A_time,model_data.L2_space) , sparse(1,1,0,m*n,m*n)];
    %A{2} = [sparse(1,1,0,m*n,m*n), kron(model_data.L2_time,model_data.operators.A_space)];
    %A{3} = [sparse(1,1,0,m*n,m*n), sparse(1,1,0,m*n,m*n) ;
    %    kron(eye(n),model_data.L2_space)];
    %A{4} = [sparse(1,1,0,m*n,m*n), sparse(1,1,0,m*n,m*n) ;
    %    sparse(1,1,0,m*n,m*n),kron(model_data.operators.A_time,model_data.L2_space)];
    
    
    r = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
    r = {r(:)};
    
    %nr = length(r);
    %r = {[zeros(nr,1);r]};
    
else % decomp_mode == 2, coefficients: merge coeff vectors
    mu = model.get_mu(model);
    
    A = [1;-mu^2];
    r = 1;
    
end;