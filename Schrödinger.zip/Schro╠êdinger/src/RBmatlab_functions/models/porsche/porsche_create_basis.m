function porsche_create_basis(step)

%Script zur Basisgenerierung f�r jeweils [mu_k_min, mu_k_original,
%mu_k_max]
switch step
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    %%% Aus mu_ranges maxima, minima und mittelpunkte f�r basis nehmen
    %%%%%%%%%%%%%%%%%%%%%%%%
    case 1
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        model = porsche_model;
        model_data = gen_model_data(model);
        model = elliptic_discrete_model(model,model_data.grid);
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen
        for k=1:length(model.mu_names)
            model_mus{k}=[model.mu_ranges{k}(1), model.(model.mu_names{k}), model.mu_ranges{k}(2)];
        end
        
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3_y3 model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data
       
        
    %%%%%%%%%%%%%%%%%%%%%%%%
    %%%% aus detailliertem Suchpfad die Snapshots erstellen
    %%%%%%%%%%%%%%%%%%%%%%%%
    case 2
        
        clear
        load SQP_sol_det_x3_y3
        model = porsche_model;
        model_data = gen_model_data(model);
        model=elliptic_discrete_model(model,model_data.grid);
        
        % L�sungs-mus in RB_mu_list schreiben:
        A=SQP_sol_det.mu_k';
        B=mat2cell(A,ones(length(SQP_sol_det.mu_k),1),2);
        model.RB_mu_list = B;
        
        %reduced_data generieren
        detailed_data=gen_detailed_data(model,model_data);
        reduced_data=gen_reduced_data(model,detailed_data);
        
        clear A B;
        save porsche_basis_SQP_det_path_x3_y4
        
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% circle-basis: unterteile den kreis in n punkte und erstelle zu
    %%%%%% jedem punkt einen snapshot
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 3
        TO BE DONE!!!
        
    
        
    %%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%% Normales Gridsearch in gewissem bereich xmin, xmax, ymin, ymax
    %%%%%%%%%%%%%%%%%%%%%%%%%
    case 4
        n=50; %Unterteilung des x-/y-Bereichs in jeweils n Punkte
        mu_range = 20; % optimalwert aus SQP_sol_det_x3_y3 +/- mu_range liefert parameterbereich
        
        model = porsche_model;
        model_data = gen_model_data(model);
        model=elliptic_discrete_model(model,model_data.grid);
        
        load SQP_sol_det_x3_y3
        xmin = SQP_sol_det.x_min - mu_range;
        xmax = SQP_sol_det.x_min + mu_range;
        ymin = SQP_sol_det.y_min - mu_range;
        ymax = SQP_sol_det.y_min + mu_range;
        
        x_vektor = linspace(xmin, xmax, n);
        y_vektor = linspace(ymin, ymax, n);
        
        l=0;
        for xind=1:n
            for yind=1:n
                l=l+1;
                RB_mu_list{l}=[x_vektor(xind), y_vektor(yind)];
            end
        end
        model.RB_mu_list=RB_mu_list;
        
        detailed_data = gen_detailed_data(model,model_data);
        reduced_data=gen_reduced_data(model,detailed_data);
        
        save porsche_basis_complete_grid_x3_y3_optplusminus20 model model_data detailed_data reduced_data

case 10
        %%%%%%%%%%%%%%%
        % Basis mit mu_min und mu_max als begrenzung, dazwischen noch 2
        % werte, also insgesamt 4 werte pro richtung, = 16 basisvektoren!
        %
        % --> �hnlich wie case 1, aber mit 4 statt 3 snapshots pro
        % richtung!
        % --> Insbesondere Verfeinerung von Basis mit 3 Punkten pro
        % richtung!!! --> sollte bessere werte f�r iteriertenverlauf
        % liefern!
        %%%%%%%%%%%%%%%    
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        model = porsche_model;
        model_data = gen_model_data(model);
        model = elliptic_discrete_model(model,model_data.grid);
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen
        for k=1:length(model.mu_names)
            %model_mus_bounds{k}=[model.mu_ranges{k}(1), model.mu_ranges{k}(2)];
            model_mus{k}=linspace(model.mu_ranges{k}(1),model.mu_ranges{k}(2),5);
        end
        
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3_y3_4steps model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data
        



case 11
        % Verfeinerung der Basis porsche_basis_2params_x3_y3
        % mit 5 statt 3 dimensionen pro richtung!
        % punkte kommen innen dazu!
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        load porsche_basis_2params_x3_y3
        clear detailed_data model_data reduced_data 
        
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen + zwischenpunkte erg�nzen        
        RB_mu_list_x = [model.RB_mu_list{1}(1), model.RB_mu_list{2}(1), model.RB_mu_list{3}(1)];
        model_mus{1} = [RB_mu_list_x(1), (RB_mu_list_x(1)+RB_mu_list_x(2))/2, RB_mu_list_x(2), (RB_mu_list_x(2)+RB_mu_list_x(3))/2, RB_mu_list_x(3)];
        
        RB_mu_list_y = [model.RB_mu_list{1}(2), model.RB_mu_list{4}(2), model.RB_mu_list{7}(2)];
        model_mus{2} = [RB_mu_list_y(1), (RB_mu_list_y(1)+RB_mu_list_y(2))/2, RB_mu_list_y(2), (RB_mu_list_y(2)+RB_mu_list_y(3))/2, RB_mu_list_y(3)];
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        model_data=gen_model_data(model);
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3_y3_5steps model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data 
        
case 12
        % Erweiterung der Basis porsche_basis_2params_x3_y3
        % mit 5 statt 3 dimensionen pro richtung!
        % au�en noch punkte anschlie�en
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        load porsche_basis_2params_x3_y3
        clear detailed_data model_data reduced_data 
        
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen + zwischenpunkte erg�nzen        
        RB_mu_list_x = [model.RB_mu_list{1}(1), model.RB_mu_list{2}(1), model.RB_mu_list{3}(1)];
        differenz_x =  model.RB_mu_list{2}(1) - model.RB_mu_list{1}(1);
        model_mus{1} = [RB_mu_list_x(1)-differenz_x, RB_mu_list_x(1), RB_mu_list_x(2), RB_mu_list_x(3), RB_mu_list_x(3)+differenz_x];
        
        RB_mu_list_y = [model.RB_mu_list{1}(2), model.RB_mu_list{4}(2), model.RB_mu_list{7}(2)];
        differenz_y = model.RB_mu_list{4}(2) - model.RB_mu_list{1}(2);
        model_mus{2} = [RB_mu_list_y(1) - differenz_y, RB_mu_list_y(1), RB_mu_list_y(2), RB_mu_list_y(3), RB_mu_list_y(3)+differenz_y];
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        model_data=gen_model_data(model);
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3_y3_5steps_extern model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data   
        
case 13
        % Erweiterung der Basis porsche_basis_2params_x3opt_y3opt_3steps
        % mit 5 statt 3 dimensionen pro richtung!
        % au�en noch punkte anschlie�en
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        load porsche_basis_2params_x3opt_y3opt_3steps
        clear detailed_data model_data reduced_data 
        
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen + zwischenpunkte erg�nzen        
        RB_mu_list_x = [model.RB_mu_list{1}(1), model.RB_mu_list{2}(1), model.RB_mu_list{3}(1)];
        differenz_x =  model.RB_mu_list{2}(1) - model.RB_mu_list{1}(1);
        model_mus{1} = [RB_mu_list_x(1)-differenz_x, RB_mu_list_x(1), RB_mu_list_x(2), RB_mu_list_x(3), RB_mu_list_x(3)+differenz_x];
        
        RB_mu_list_y = [model.RB_mu_list{1}(2), model.RB_mu_list{4}(2), model.RB_mu_list{7}(2)];
        differenz_y = model.RB_mu_list{4}(2) - model.RB_mu_list{1}(2);
        model_mus{2} = [RB_mu_list_y(1) - differenz_y, RB_mu_list_y(1), RB_mu_list_y(2), RB_mu_list_y(3), RB_mu_list_y(3)+differenz_y];
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end

        model.RB_mu_list=RB_mu_list;
        
        model_data=gen_model_data(model);
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3opt_y3opt_5steps_extern model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data          

        
case 14
        % gr�ber machen der basis!
        % nur 4 eckpunkte als basisvektoren
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        load porsche_basis_2params_x3_y3
        clear detailed_data model_data reduced_data 
        
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen + zwischenpunkte erg�nzen        
        RB_mu_list_x = [model.RB_mu_list{1}(1), model.RB_mu_list{2}(1), model.RB_mu_list{3}(1)];
        model_mus{1} = [RB_mu_list_x(1), RB_mu_list_x(3)];
        
        RB_mu_list_y = [model.RB_mu_list{1}(2), model.RB_mu_list{4}(2), model.RB_mu_list{7}(2)];
        model_mus{2} = [RB_mu_list_y(1), RB_mu_list_y(3)];
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        model_data=gen_model_data(model);
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3_y3_2steps model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data 
        

case 13
        % Verfeinerung der Basis porsche_basis_2params_x3opt_y3opt_3steps
        % mit 5 statt 3 dimensionen pro richtung!
    
        %%%%%%%%%%%%%%%
        % In model.mu_names die richtigen Daten eintragen!!!
        %%%%%%%%%%%%%%%
        
        load porsche_basis_2params_x3opt_y3opt_3steps
        clear detailed_data model_data reduced_data time2gen_detailed_data time2gen_reduced_data
        
        
        %erzeuge die richtige lagrangebasis:
        
        %mus aus model auslesen + zwischenpunkte erg�nzen        
        RB_mu_list_x = [model.RB_mu_list{1}(1), model.RB_mu_list{2}(1), model.RB_mu_list{3}(1)];
        model_mus{1} = [RB_mu_list_x(1), (RB_mu_list_x(1)+RB_mu_list_x(2))/2, RB_mu_list_x(2), (RB_mu_list_x(2)+RB_mu_list_x(3))/2, RB_mu_list_x(3)];
        
        RB_mu_list_y = [model.RB_mu_list{1}(2), model.RB_mu_list{4}(2), model.RB_mu_list{7}(2)];
        model_mus{2} = [RB_mu_list_y(1), (RB_mu_list_y(1)+RB_mu_list_y(2))/2, RB_mu_list_y(2), (RB_mu_list_y(2)+RB_mu_list_y(3))/2, RB_mu_list_y(3)];
        
        %mit diesen vektoren alle m�glichen kombinationen bilden
        combination_mus=createCombinations(model_mus);
        
        model.RB_mu_list=[];
        for k=1:size(combination_mus,2)
            RB_mu_list{k} = combination_mus(:,k)';
        end
        
        % RB_mu_list=RB_mu_list(1:2:end); %nur die halbe basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein viertel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein achtel der basis berechnen!
        % RB_mu_list=RB_mu_list(1:2:end); %nur ein sechzehntel der basis berechnen!
        model.RB_mu_list=RB_mu_list;
        
        model_data=gen_model_data(model);
        
        tic;
        disp('-------------------------------------');
        disp('start generation of detailed_data...');
        detailed_data = gen_detailed_data(model,model_data);
        disp('finished generation of detailed_data!');
        disp('-------------------------------------');
        time2gen_detailed_data = toc;
        
        tic;
        disp('-------------------------------------');
        disp('start generation of reduced_data...');
        reduced_data=gen_reduced_data(model,detailed_data);
        disp('finished generation of reduced_data!');
        disp('-------------------------------------');
        time2gen_reduced_data = toc;
        
        disp('saving the data...');
        save porsche_basis_2params_x3opt_y3opt_5steps model model_data detailed_data reduced_data time2gen_detailed_data time2gen_reduced_data
        

end