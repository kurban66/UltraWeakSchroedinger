function diff_tensor_comp=porsche_diffusivity_tensor_components(glob, params)
%function diff_tensor_comp=porsche_diffusivity_tensor_components(glob, params)
%
% function defining the diffusivity tensor components of the porsche_model
%
% input:
%  - params: model
%  - glob: n points of the microgrid (n-by-2-matrix)
%
% output:
% diff_tensor_comp = cell with (number of macro triangles)-by-4 entries,
% defining the diffusivity-tensor-components so the component-matrices of
% a(x) in the PDE -div( a(x) grad u(x) ) + ...
%
%
% for the notation of the variables in this function see also:
%  "Reduced basis approximation and error bounds for potential
%   flows in parametrized geometries"
% by Gianluigi Rozza
%    MATHICSE Technical Report, Nr 11.2010, July 2010   
%
% Oliver Zeeb, 06.05.11

diff_tensor_comp=cell(length(params.tmacro)*4,1);

pmic2tmac = pmicro2tmacro(glob,params);
q=0;
for k=1:length(params.tmacro)
    pts_in_tmacro_k=find(pmic2tmac==k);
    for l=1:4
        q=q+1;
        %row_position_in_matrix=repmat(l,length(pts_in_tmacro_k))
        diff_tensor_comp{q}=sparse(pts_in_tmacro_k,l,1,length(glob),4,length(pts_in_tmacro_k));
    end
end