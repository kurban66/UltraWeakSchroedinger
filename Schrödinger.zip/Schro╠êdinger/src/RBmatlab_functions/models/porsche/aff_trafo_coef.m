function [C, G] = aff_trafo_coef(coord_1, coord_2)
%function [C, G] = aff_trafo_coef(coord_1, coord_2)
%
% function giving the coefficients for the affine transformation
% from triangle 1 to triangle 2,
% i.e. T_i_aff(x;mu) = C_aff_i(mu) + sum_j=1_2 G_ij_k(mu) x_j;      j=1,2, i=1,2
% 
%    triangle 1      /| (x1(3),y1(3))              (x2(3),y2(3))  |\     triangle 2         
%                   / |                 ---T--->                  | \  
%    (x1(1),y1(1)) /__| (x1(2),y1(2))              (x2(1),y2(1))  |__\ (x2(2),y2(2))   
%
% function giving c1, c2, g11, g12, g21, g22
% so: C=[c1; c2] and G=[g11, g12; g21, g22]
%
% input: 
% coord_1: coordinates of triangle 1, 3-times-2 matrix
% coord_2: coordinates of triangle 2, 3-times-2 matrix
%
% output:
% affine transformation can be written as T(x) = C + G*x
% C: 2-by-1-vector
% G: 2-by-2-matrix
%
%
% Oliver Zeeb, 07.02.11

x1=zeros(3,1);
y1=zeros(3,1);
x2=zeros(3,1);
y2=zeros(3,1);

x1(1) = coord_1(1,1);
x1(2) = coord_1(2,1);
x1(3) = coord_1(3,1);
y1(1) = coord_1(1,2);
y1(2) = coord_1(2,2);
y1(3) = coord_1(3,2);

x2(1) = coord_2(1,1);
x2(2) = coord_2(2,1);
x2(3) = coord_2(3,1);
y2(1) = coord_2(1,2);
y2(2) = coord_2(2,2);
y2(3) = coord_2(3,2);

tria_2_coord = [x2(1); y2(1); x2(2); y2(2); x2(3); y2(3)];

B_aff =  [1, 0, x1(1), y1(1), 0, 0; ...
          0, 1, 0, 0, x1(1), y1(1); ...
          1, 0, x1(2), y1(2), 0, 0; ...
          0, 1, 0, 0, x1(2), y1(2); ...
          1, 0, x1(3), y1(3), 0, 0; ...
          0, 1, 0, 0, x1(3), y1(3)];
      
coef_vec = B_aff \ tria_2_coord;

C = [coef_vec(1); coef_vec(2)];
G = [coef_vec(3), coef_vec(4); coef_vec(5), coef_vec(6)];