function sol = porsche_x3_y3_grid_search(model,data)



% Gitter Grid-Search
% x3_min = model.mu_ranges{1}(1);
% x3_max = model.mu_ranges{1}(2);
% y3_min = model.mu_ranges{2}(1);
% y3_max = model.mu_ranges{2}(2);
% 
% X = x3_min:1:x3_max;
% Y = y3_min:1:y3_max;
% 
% for x_ind=1:length(X)
%     for y_ind=1:length(Y)
%         model = set_mu(model,[X(x_ind), Y(y_ind)]);
%         sim_data(x_ind,y_ind) = model.optimization.objective_function(model,data);
%     end
% end
% sol_quadrat.outputs = sim_data;
% sol_quadrat.X = X;
% sol_quadrat.Y = Y;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Kreis Grid-search
%
%Kreis parametrisieren:
r = 10; %Kreisradius
n= 10000; % anzahl der punkte auf dem kreis

x_fix = model.pmacro(3,1);
y_fix = model.pmacro(3,2);
t=linspace(0,2*pi,n);
circle = repmat([x_fix; y_fix],1,n) + r*[cos(t); sin(t)];
obj_function=zeros(1,n);
for k=1:n
    model = set_mu(model, circle(:,k));
    obj_function(k) = model.optimization.objective_function(model,data);
    disp(['Durchgang ', num2str(k), ' von ', num2str(n)]);
end
[min_obj, min_ind]=min(obj_function);
x_min=circle(1,min_ind);
y_min=circle(2,min_ind);

sol.obj_function = obj_function;
sol.min_obj = min_obj;
sol.min_ind = min_ind;
sol.x_min = x_min;
sol.y_min = y_min;
sol.circle = circle;

%nur zum speichern:
gridsearch_sol = sol;
save gridsearch_det_x3_y3_10000pts gridsearch_sol