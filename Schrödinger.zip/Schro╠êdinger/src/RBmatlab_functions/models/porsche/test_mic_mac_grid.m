%zum Testen: Micro und Macrogitter

macro_pts_x = [3,8,8,3];
macro_pts_y = [1,1,6,6];
macro_tria =  [1,2,4;...
               2,3,4];
           
micro_pts_x = [3, 8, 8, 3, 5.5, 3, 5.5, 8, 5.5];
micro_pts_y = [1, 1, 6, 6, 1, 3.5, 3.5, 3.5, 6];
micro_tria = [1, 5, 6;...
              5, 7, 6;...
              5, 2, 7;...
              2, 8, 7;...
              6, 7, 4;...
              7, 9, 4;...
              7, 3, 9;...
              7, 8, 3];
          
macrogrid = triagrid([macro_pts_x;macro_pts_y],macro_tria',[]);
microgrid = triagrid([micro_pts_x;micro_pts_y],micro_tria',[]);


% PDE-Toolbox:
% for k=1:size(macro_tria,1)
%     tria_pts_x = macro_pts_x(macro_tria(k,:)); 
%     tria_pts_y = macro_pts_y(macro_tria(k,:)); 
%     pdepoly(tria_pts_x, tria_pts_y, ['MakroT',num2str(k)])
% end
% 
% for k=1:size(micro_tria,1)
%     tria_pts_x = micro_pts_x(micro_tria(k,:)); 
%     tria_pts_y = micro_pts_y(micro_tria(k,:)); 
%     pdepoly(tria_pts_x, tria_pts_y, ['MikroT',num2str(k)])
% end
