Important note:

For computing the output properly, use
  sim_data.s = model.output_functional(model,model_data,sim_data.uh);
instead of
  v = model.operators_output(model,model_data);
  sim_data.s = (v(:)') * sim_data.uh.dofs;
in the file 'lin_stat_detailed_simulation.m' (in section: % compute output)

Otherwise there will be an error!

