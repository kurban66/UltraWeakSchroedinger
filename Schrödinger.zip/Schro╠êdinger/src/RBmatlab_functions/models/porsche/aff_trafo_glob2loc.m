function [C, G] = aff_trafo_glob2loc(x0, y0)
%function [C, G] = aff_trafo_glob2loc(x0, y0)
%
% function giving the coefficients for the affine transformation
% from original/global triangle to the reference/local one,
% i.e. T_i_aff(x;mu) = C_aff_i(mu) + sum_j=1_2 G_ij_k(mu) x_j;      j=1,2, i=1,2
% 
% triangle:                     /| (x0(3),y0(3))              (0,1)  |\            
%                              / |                ---T--->           | \  
%               (x0(1),y0(1)) /__| (x0(2),y0(2))              (0,0)  |__\ (1,0)   
%
% function giving c1, c2, g11, g12, g21, g22
% so: C=[c1; c2] and G=[g11, g12; g21, g22]
%
% input: 
% x0: 3-by-1-list of the x values of the original/global triangle
% y0: 3-by-1-list of the y values of the original/global triangle
%
% output:
% affine transformation can be written as T(x) = C + G*x
% C: 2-by-1-vector
% G: 2-by-2-matrix
%
% See also aff_trafo_loc2glob which gives the transformation in the other
% direction (local to global)
%
% Oliver Zeeb, 01.02.11

% standard triangle
x1 = 0;
y1 = 0;
x2 = 1;
y2 = 0;
x3 = 0;
y3 = 1;

ref_coord = [x1; y1; x2; y2; x3; y3];

B_aff =  [1, 0, x0(1), y0(1), 0, 0; ...
          0, 1, 0, 0, x0(1), y0(1); ...
          1, 0, x0(2), y0(2), 0, 0; ...
          0, 1, 0, 0, x0(2), y0(2); ...
          1, 0, x0(3), y0(3), 0, 0; ...
          0, 1, 0, 0, x0(3), y0(3)];
      
coef_vec = B_aff \ ref_coord;

C = [coef_vec(1); coef_vec(2)];
G = [coef_vec(3), coef_vec(4); coef_vec(5), coef_vec(6)];
% c1  = coef_vec(1);
% c2  = coef_vec(2);
% g11 = coef_vec(3);
% g12 = coef_vec(4);
% g21 = coef_vec(5);
% g22 = coef_vec(6);
