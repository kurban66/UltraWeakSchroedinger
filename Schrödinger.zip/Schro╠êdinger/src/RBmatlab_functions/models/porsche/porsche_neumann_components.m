function neu_comp = porsche_neumann_components(glob,params)
%function neu_comp = porsche_neumann_components(glob,params)
%
% function setting the neumann components (i.e. the speed) in the 
% porsche_model to the value given by model.speed
% 
% input
% params: the porsche_model
% glob: n-by-2-matrix with the points of the grid
%
% ouput
% neu_comp: cell with the neumann_components
%
% needed fields in model:
% model.speed
% model.xrange
%
% Oliver Zeeb, 09.05.11

neu_comp = zeros(size(glob,1),1);
ind_gamma_in = glob(:,1)<=params.xrange(1)+10*eps;
neu_comp(ind_gamma_in) = params.speed;
neu_comp={neu_comp};