function p = porsche_plot(model,model_data,sim_data,step)
%
%
%function plot_porsche_mit_sim_data(model,model_data,sim_data,step)
%
% function plotting the solution of the PDE on the reference or the original 
% porsche domain or plotting gradient and pressure  on the porsche domain 
% by interpolating the given gradients on a regular grid and cutting out
% those parts, that ly inside the porsche. This depends on the value of
% step:
% 1: plotting the solution on the reference domain
% 2: plotting the solution on the reshaped/original domain
% 3: plotting velocity and pressure on the reference domain
% 4: plotting velocity and pressure on the reshaped/original domain
%
%
% input:
% model
% model_data
% sim_data
%
% needed fields of model:
% - xrange, yrange: defining the box
% - cp: list of the car points
%
% needed fields of model_data:
% - model_data.microgrid
% - pdetoolbox_mesh.p
% - model_data.pdetoolbox_mesh.e
% - model_data.pdetoolbox_mesh.t
%   --> p, e, t exported from pdetoolbox, containing the grid information
%
% needed fields of sim_data (only for step 3 and 4)
% - gradx: n-by-1 vector with the x component of the gradient of 
%          the solution of the potential flow equation
%          n must be the number of vertices in the grid
% - grady: see gradx
% - pressure: n-by-1-vector with the values of the pressure correspnding to
%             the vertices in the grid
%
% Oliver Zeeb, 16.02.11




switch step
    case 1 %plot the solution on the reference domain
        lin_stat_plot_sim_data(model,model_data,sim_data);
        axis equal;
        title('solution on the reference domain');
 
        
    case 2
        sim_data_work=sim_data;
        sim_data_work.uh=copy(sim_data.uh);
        sim_data_work.uh.grid=grid_reshape(model, sim_data_work.uh.grid);
        lin_stat_plot_sim_data(model,model_data,sim_data_work);
        title('solution on the original domain');
        axis equal;

        
        
    case 3
        %%% Interpolate to a regular grid %%%
        xi = linspace(model.xrange(1),model.xrange(2),17); % Interpolation points x
        yi = linspace(model.yrange(1),model.yrange(2),20); % Interpolation points y
        [XI,YI] = meshgrid(xi,yi);
        gradxI = griddata(model_data.grid.X, model_data.grid.Y, sim_data.gradx, XI, YI);
        gradyI = griddata(model_data.grid.X, model_data.grid.Y, sim_data.grady, XI, YI);

        %check, which points are in the car, do not plot velocity arrows there!
        IN=inpolygon(XI,YI,model.cp(:,1),model.cp(:,2));
        XI(IN)=[];
        YI(IN)=[];
        gradxI(IN)=[];
        gradyI(IN)=[];

        % plot with pdeplot
        p = model_data.pdetoolbox_mesh.p;
        e = model_data.pdetoolbox_mesh.e;
        t = model_data.pdetoolbox_mesh.t;
        figure
        pdeplot(p,e,t,'xydata',sim_data.pressure,'mesh','off')
        axis equal
        hold on
        quiver(XI,YI,gradxI,gradyI)
        colormap(jet)
        title('pressure and velocity, reference domain')

        
    case 4
        %%% Interpolate to a regular grid %%%
        xi = linspace(model.xrange(1),model.xrange(2),17); % Interpolation points x
        yi = linspace(model.yrange(1),model.yrange(2),20); % Interpolation points y
        [XI,YI] = meshgrid(xi,yi);
        gradxI = griddata(model_data.grid.X, model_data.grid.Y, sim_data.gradx, XI, YI);
        gradyI = griddata(model_data.grid.X, model_data.grid.Y, sim_data.grady, XI, YI);
        
        %transform the ppoints before checking which velocity arrows to
        %plot
        cp_trafo=points_trafo(model,model.cp);

        %check, which points are in the car, do not plot velocity arrows there!
        IN=inpolygon(XI,YI,cp_trafo(:,1),cp_trafo(:,2));
        %IN=inpolygon(XI,YI,model.cp(:,1),model.cp(:,2));
        XI(IN)=[];
        YI(IN)=[];
        gradxI(IN)=[];
        gradyI(IN)=[];

        % plot with pdeplot
        p = model_data.pdetoolbox_mesh.p;
        e = model_data.pdetoolbox_mesh.e;
        t = model_data.pdetoolbox_mesh.t;
        pts_transformed = points_trafo(model,p')';
        figure
        pdeplot(pts_transformed,e,t,'xydata',sim_data.pressure,'mesh','off')
        axis equal
        hold on
        quiver(XI,YI,gradxI,gradyI)
        colormap(jet)
        title('pressure and velocity, reshaped domain')
        
    otherwise
        error('unknown step!');
end
p='dummy';
