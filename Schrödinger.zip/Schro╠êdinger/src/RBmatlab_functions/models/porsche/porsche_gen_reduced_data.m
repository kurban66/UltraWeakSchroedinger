function reduced_data=porsche_gen_reduced_data(model, detailed_data)
%function reduced_data=porsche_gen_reduced_data(model, detailed_data)
%
% this function generates the reduced_data for the porsche_model by using 
% lin_stat_gen_reduced_data. Afterwards, the output components are calculated.
% This has to be done this way, because in lin_stat_gen_reduced_data 
% it is not possible to use the gradient of the solution instead of the 
% solution itself for computing the output-functional.
%
% Oliver Zeeb, 16.05.11


old_compute_output_functional=model.compute_output_functional;
model.compute_output_functional=0;
reduced_data = lin_stat_gen_reduced_data(model, detailed_data);
model.compute_output_functional=old_compute_output_functional;
if model.compute_output_functional == 1
    old_decomp_mode = model.decomp_mode;
    model.decomp_mode = 1;
    %output_comp = porsche_operators_output_components(model,detailed_data);
    output_comp = model.operators_output(model,detailed_data);
    model.decomp_mode = old_decomp_mode;
    reduced_data.lN_comp = output_comp;
end


