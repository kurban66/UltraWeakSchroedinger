function func=porsche_objective_function(model,data)
%function func=porsche_objective_function(model,data)
%
% this function calculates and returns the output either detailed or with
% RBM.
% 
% needed fields in model:
% model.optimization.opt_mode: 'detailed' or 'reduced'
%
% Oliver Zeeb, 26.05.2011


if strcmp(model.optimization.opt_mode, 'detailed')
    sim_data = detailed_simulation(model,data);
elseif strcmp(model.optimization.opt_mode, 'reduced')
    sim_data = rb_simulation(model,data);
else
    warning('model.optimization.opt_mode is neither "detailed" nor "reduced"');
end
func = sim_data.s;

end
