function sim_data = porsche_detailed_simulation(model,model_data)
%function sim_data = porsche_detailed_simulation(model,model_data)
%
% function performing the detailed simulation of a lin-stat model,
% i.e. the matrix and rhs assembly and solving of the system,
% possibly also output computation

% B. Haasdonk 3.10.2013

old_mode = model.decomp_mode;
model.decomp_mode = 0; % complete

sim_data =[];

[A,r] = model.operators(model,model_data);

% solution variable:
uh = femdiscfunc([],model_data.df_info);
uh.dofs = A\r;    

% return results:
sim_data.uh = uh;

% compute output
if model.compute_output_functional
  % the following can be used for any, also nonlinear functionals:
  sim_data.s = model.output_functional(model,model_data,sim_data.uh);
  % for linear operators, get vector:
  %v = model.operators_output(model,model_data);
  %sim_data.s = (v(:)') * sim_data.uh.dofs;
end;

model.decomp_mode = old_mode;