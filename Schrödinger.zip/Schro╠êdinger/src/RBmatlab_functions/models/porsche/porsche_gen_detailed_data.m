function detailed_data=porsche_gen_detailed_data(model, model_data)
%function detailed_data=porsche_gen_detailed_data(model, model_data)
%
% function generating detailed_data of the porsche_model by using
% lin_stat_gen_detailed-data, then adding the points oh the car-front by
% copying them from model_data.
%
% Oliver Zeeb, 16.05.11

old_compute_output_functional = model.compute_output_functional;
model.compute_output_functional = 0;
detailed_data = lin_stat_gen_detailed_data(model, model_data);
model.compute_output_functional = old_compute_output_functional;
%add information of the front to detailed_data
detailed_data.front_ref_domain=model_data.front_ref_domain;


if model.compute_output_functional == 1
    %create 'dummy_fdf' containing the grid and the dofs, so that
    %disc_gradient can be used for the calculation of the gradient.
    dummy_fdf.grid=model_data.grid;
    glob=model_data.front_ref_domain.edge_midpts_front;
    for k=1:size(detailed_data.RB,2)
        dummy_fdf.dofs=detailed_data.RB(:,k);
        [gradx,grady] = disc_gradient(glob,dummy_fdf);
        grad_in_midpts_front{k}=[gradx,grady];
    end
    detailed_data.front_ref_domain.grad_in_midpts_front=grad_in_midpts_front;
end



