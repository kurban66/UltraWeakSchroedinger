function pts_transformed=points_trafo(model,glob)
%function pts_transformed=points_trafo(model,glob)
%
% function transforming points according to which macro-triangle they belong
% to.
%
% input:
% model
% glob: n-by-2 list of the points which shall be transformed
%
% ouput:
% pts_transformed: n-by-2 list of transformed points
%
% needed fields in model:
% mu_names
%
%
% Oliver Zeeb, 16.02.11

nr_macro_tri = size(model.tmacro,1);
pmacro_ref = model.pmacro; % points of the reference macrogrid
tmacro = model.tmacro;

% use the mus for setting the new macrogrid-points
pmacro_reshaped = model.pmacro; % coordinates of the reshaped macrogrid
% old: 12.05.11: funktioniert so nur, wenn alle punkte parameter sind!
% for k=1:nr_mus/2  % nr_mus = length(model.mu_names) should be even
%     x = getfield(model, model.mu_names{k});
%     y = getfield(model, model.mu_names{k+nr_mus/2});
%     pmacro_reshaped(k,:) = [x,y];
% end
%neu: 12.05.11:
for k=1:model.nr_macro_car_points  
    x = getfield(model, ['x',num2str(k)]);
    y = getfield(model, ['y',num2str(k)]);
    pmacro_reshaped(k,:) = [x,y];
end
%ende neu: 12.05.11

%now the reshaped macropoints are set

if isequal(pmacro_reshaped,pmacro_ref) %no points were changed, still the original grid
    pts_transformed=glob;
    disp(' mu=mu_ref: no transformation needed!')
else %some macropoints were changed, so the points mus be transformed
    %get the affine transformation for every macrogrid
    disp(' transforming points... ')
    C = zeros(2,nr_macro_tri);
    G = zeros(2,2,nr_macro_tri);
    for k=1:nr_macro_tri
        tria_pts_ref = pmacro_ref(tmacro(k,:),:);
        tria_pts_reshaped = pmacro_reshaped(tmacro(k,:),:);
        [C(:,k), G(:,:,k)] = aff_trafo_coef(tria_pts_ref, tria_pts_reshaped);
    end
    %which point of the microgrid belongs to which macrotriangle?
    pmic2tmac = pmicro2tmacro([glob(:,1),glob(:,2)], model);
    
    %transform the points
    pts_transformed = [glob(:,1)'; glob(:,2)'];
    for k = 1:nr_macro_tri
    pts_transformed(:,pmic2tmac==k) = repmat(C(:,k),1,length(pts_transformed(pmic2tmac==k)))...
        + G(:,:,k)*pts_transformed(:,pmic2tmac==k);
    end
    pts_transformed = pts_transformed';
end