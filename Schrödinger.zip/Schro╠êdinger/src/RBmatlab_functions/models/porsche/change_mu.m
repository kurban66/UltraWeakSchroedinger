function model = change_mu(model, mu_mod)
%function model = change_mu(model, mu_mod)
% 
% function changing the parameter vector mu in the model struct
%
% input:
% mu_mod = modification of the mu_vector 
%          mu_mod = [10, 0, -4, ...] means, mu_1 is incremented by 10, mu_2
%          is stays unchanged, mu_3 is decremented by 4, ...
% 
% required fields of model:
% mu_names : cell array of strings, indicating the fields, which are set
%            by the current routine
%
% Oliver Zeeb, 14.02.11

if length(mu_mod(:))~=length(model.mu_names)
  error('dimensionality of mu does not fit to model.mu_names');
end;

for i=1:length(mu_mod(:))
  model.(model.mu_names{i}) = model.(model.mu_names{i}) + mu_mod(i);
%   if (model.(model.mu_names{i}) < model.mu_ranges{i}(1) ...
%           || model.(model.mu_names{i}) > model.mu_ranges{i}(2))
%       warning('parameter out of range');
%   end
end;

