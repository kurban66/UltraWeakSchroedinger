function solution = SQP_algorithm(model,data,varargin)
%function solution = SQP_algorithm(model,data,varargin)
%
% This funtion uses an SQP-Algorithm to optimize the shape of the
% porsche_model. This Version was used in Oliver Zeeb's Diploma-thesis.
%
% input
% model: the porsche_model
% data: reduced_data or model_data
%
% output
% solution: cell, containing information about the optimization-process
%
% needed fields in model:
% model.optimization.opt_mode: according to which data is given either
% 'detailed' (mdoel_data) oder 'reduced' (reduced_data)
%
% 
%
% Oliver Zeeb, 30.05.11

tic;

%initialize some values
nr_constr = model.optimization.nr_constraints;

% (S.0) Startwerte setzen
k = 0; % Nr of SQP iterations
l_eq = zeros(nr_constr,1);

mu = get_mu(model); 

mu_save = mu;
mu_diff = zeros(length(model.mu_names),1);
l_eq_diff = zeros(size(l_eq));


%(S.1)
% needed for first SQP_kkt_check
grad_J  = model.optimization.get_Jacobian(model,data);
hes_Lag = model.optimization.get_Hes_Lag(model,data,l_eq);
H       = model.optimization.get_eq_constr(model);
grad_H  = model.optimization.get_grad_eq_constr(model); %(entspricht B)


while ~SQP_kkt_check(grad_J, H, grad_H, l_eq) 
    %(S.2)
    %L�sen des SQP Teilproblems:
    %Matrix aufstellen, vgl. Satz 1.4, bzw. Gleichung (2.28)
    A=[hes_Lag, grad_H'; grad_H, zeros(size(grad_H,1))];
    b=[-grad_J';-H'];

    Dmu_lambda= A\b; 
    
    %L�sung des LGS aufteilen in Lagrangemultiplikatoren
    Dmu = Dmu_lambda(1 : length(mu));
    l_eq = Dmu_lambda(length(mu)+1 : end);
    %mu update
    mu = mu + Dmu;
    
    mu_save(:,k+2) = mu;
    %mu_diff = [mu_diff, mu_save(:,k+2) - mu_save(:,k+1)];
    l_eq_save(:,k+2) = l_eq(:);
    %l_eq_diff = [l_eq_diff, l_eq_save(:,k+2) - l_eq_save(:,k+1)];

    
    
    %(S.1)
    model=set_mu(model,mu);
    grad_J  = model.optimization.get_Jacobian(model,data);
    hes_Lag = model.optimization.get_Hes_Lag(model,data,l_eq);
    H       = model.optimization.get_eq_constr(model);
    grad_H  = model.optimization.get_grad_eq_constr(model); %(entspricht B)
    
    
    % (S.3)
    k=k+1;
%     if mod(k,15)==0
%         keyboard
%         %break
%     end
end

solution.obj_function = model.optimization.objective_function(model,data);

% save the solution
solution.nr_iterations=k;
solution.mu_opt = mu;
solution.x_opt = mu(1);
solution.y_opt = mu(2);
solution.mu_k = mu_save;
solution.l_eq = l_eq;
solution.l_eq_k = l_eq_save;
solution.time_elapsed = toc;
