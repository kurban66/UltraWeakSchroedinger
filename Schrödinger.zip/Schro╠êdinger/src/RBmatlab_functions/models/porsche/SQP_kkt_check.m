function is_kkt=SQP_kkt_check(grad_J, H, grad_H, l_eq) 

% This function checks, if the current iterae is a KKT-point.
% returns 1 if the iterate is a KKT-point
% returns 0 if the iterate is not a KKT-point
%


%tol_grad_L = 1e-5;
%tol_H = 1e-10;
tol_grad_L = 1e-3;
tol_H = 1e-5;

% check gradient of Lagrange-function
sum_grad_eq_constr = zeros(1,size(grad_H,2));
for k=1: length(l_eq)
    sum_grad_eq_constr = sum_grad_eq_constr + l_eq(k)*grad_H(k,:);
end
grad_L = grad_J + sum_grad_eq_constr;
% \nabla L = 0 ???
if (max(grad_L) <= tol_grad_L && min(grad_L) >= -tol_grad_L)
    is_kkt_L = 1;
else
    is_kkt_L = 0;
end


% check the equality-constraints:
if (max(H) <= tol_H && min(H) >= -tol_H)
    is_kkt_H = 1;
else
    is_kkt_H = 0;
end

% check if both conditions (grad_L=0 and h=0) are complied
if is_kkt_L==1 && is_kkt_H==1
    is_kkt = 1;
else
    is_kkt = 0;
end
