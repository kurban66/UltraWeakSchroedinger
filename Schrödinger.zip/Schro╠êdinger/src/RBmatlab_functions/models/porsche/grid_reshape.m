function grid_reshaped = grid_reshape(model,grid)
% function grid_reshaped = grid_reshape(model,grid)
%
%
% input:
% grid: triagrid
% model
%
% required fields of model:
% pmacro: list of the points of the macro-triangulation
% tmacro: vertex-list of the macro-triangles
% mu_names: array with the names of the parameters (should be even numbers
% of parameters)
%
% output:
% grid: reshaped triagrid
%
% function is reshaping a grid, according to the mus set in the model.
% that means the macrogrid is transformed, and all the points of the grid
% are transformed acoording to the corresponding corresponding
% transformation of the macrogrid they belong to.
%
% Oliver Zeeb, 09.02.11

%disp('in grid_reshape.m: be careful! grid is corrupted afterwards!!! only use for plotting!')
nr_macro_tri = size(model.tmacro,1);
nr_mus = length(model.mu_names);
pmacro_ref = model.pmacro; % points of the reference macrogrid
pmacro_reshaped = model.pmacro; % coordinates of the reshaped macrogrid
tmacro = model.tmacro;

for k=1:length(model.mu_names)
    position_in_pmacro = str2double(model.mu_names{k}(2));
    x_or_y = model.mu_names{k}(1);
    if x_or_y == 'x'
        x_or_y = 1;
    elseif x_or_y == 'y'
        x_or_y = 2;
    else
        error('unknown entry in model.mu_names');
    end
    mu_k = getfield(model, model.mu_names{k});
    pmacro_reshaped(position_in_pmacro,x_or_y) = mu_k;
end

%get the affine transformation for every macrogrid
C = zeros(2,nr_macro_tri);
G = zeros(2,2,nr_macro_tri);
for k=1:nr_macro_tri
    tria_pts_ref = pmacro_ref(tmacro(k,:),:);
    tria_pts_reshaped = pmacro_reshaped(tmacro(k,:),:);
    [C(:,k), G(:,:,k)] = aff_trafo_coef(tria_pts_ref, tria_pts_reshaped);
end

%which point of the microgrid belongs to which macrotriangle?
pmic2tmac = pmicro2tmacro([grid.X,grid.Y], model);

% transform every point of the microgrid with the corresponding affine trafo
pts_micro_reshaped = [grid.X'; grid.Y'];
for k = 1:nr_macro_tri
    pts_micro_reshaped(:,pmic2tmac==k) = repmat(C(:,k),1,length(pts_micro_reshaped(pmic2tmac==k)))...
        + G(:,:,k)*pts_micro_reshaped(:,pmic2tmac==k);
end


%%%%%%%%%%%%%%%%%%%%%%%
%%% LIKE THIS, NOT A REAL NEW GRID IS GENERATED! 
%%% e.g. A and A_inv are not touched and therefore are wrong for the ne
%%% grid
%%% BUT STILL SUFFICIENT FOR ONLY PLOTTING A GRID!!!
%%%%%%%%%%%%%%%%%%%%%%%
grid_reshaped = triagrid(grid);
grid_reshaped.X = pts_micro_reshaped(1,:)';
grid_reshaped.Y = pts_micro_reshaped(2,:)';

% coordinates of vertices: XX(elnum, vnum)
XX = reshape(grid_reshaped.X(grid_reshaped.VI(:)),size(grid_reshaped.VI));
YY = reshape(grid_reshaped.Y(grid_reshaped.VI(:)),size(grid_reshaped.VI));
grid_reshaped.CX = mean(XX,2);
grid_reshaped.CY = mean(YY,2);