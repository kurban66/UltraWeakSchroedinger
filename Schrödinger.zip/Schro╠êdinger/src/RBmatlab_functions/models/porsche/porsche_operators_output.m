function out_func=porsche_operators_output(model,detailed_data)
%function out_func=porsche_operators_output(model,detailed_data)
% 
% This function calculates the coefficients or components of the 
% output_functional, i.e.
% \int_{\Omega_{front,ref}} v \times t dx for every snapshot( saved in 
% detailed_data.RB)
% 
% needed fields in detailed_data:
% front_ref_domain.grad_in_midpts_front: k-cell of n-by-2-matrices 
%                                        containing the gradients of the 
%                                        points on the front domain for
%                                        all of the k snapshots
% front_ref_domain.tangent_front: n-by-2-matrix containing the
%                                 tangent-vectors in the midpoints 
%                                 of the edges of the front part of the 
%                                 reference-car
% front_ref_domain.edge_length_front: n-vector containing the length of the
%                                     edges of the front-domain of the
%                                     reference-car
%
% Oliver Zeeb, 18.05.11

switch model.decomp_mode
    case 0
        error(['for detailed simulation with computation of output functional please use line 27 '...
            'in lin_stat_detailed_simuation.m instead of lines 29-30!'])

    case 1
        for k=1:size(detailed_data.RB,2)
            %getting the data from detailed_data
            grad_in_mid_pts_front = detailed_data.front_ref_domain.grad_in_midpts_front{k};
            tangent_front = detailed_data.front_ref_domain.tangent_front;
            edge_length = detailed_data.front_ref_domain.edge_length_front;
            %calculating the integrand
            grad_phi_times_t =  grad_in_mid_pts_front .* tangent_front;
            grad_phi_times_t = grad_phi_times_t(:,1) + grad_phi_times_t(:,2);
            %summing up all the integrands multiplied by edge-length
            sum_x = grad_phi_times_t' * edge_length;
            out_func{k}=sum_x;
        end
        
    case 2
        error('model.decomp_mode = 2 should not bee needed!');
        
    otherwise
        error('wrong decomp_mode! porsche_operators_output_components is only usable with decomp_mode=1!');
end