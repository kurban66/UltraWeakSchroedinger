function p = compute_pressure(model, gradx, grady)
%
% function, computing the pressure according to bernoulli equation on every
% point of a grid
% this function is adapted to the porsche_model
%
% input:
% model
% gradx : x-vector of the gradient of the solution of the PDE (physically
%         this is the x-coordinate of the velocity-field in every point
%         of the grid
% grady : y-vector of the gradient of the solution of the PDE (physically
%         this is the x-coordinate of the velocity-field in every point
%         of the grid
%
% needed fields of model:
% model.speed : defining the speed of the car, that means the speed of the
% air on the left boundary
%
% output: 
% p: vector with the pressure according to bernoulli equation
%
% 
%
p_in = 101325; % standard pressure in pascal = kg/(m*s²) = N/m2
rho = 1.2041; % airdensity in kg/m3
u_in_sqr = model.speed^2 * 3.6^2; % model.speed is 
                % in km/h, so conversion to m/s2 is needed
abs_vel_sqr = (gradx.^2 + grady.^2) * 3.6^2; 
                % absolute value of velocity square for every point in m/s2
p = (p_in + 0.5*rho * (u_in_sqr - abs_vel_sqr)); % pressure p in pascal
p = p*1e-5; %pressure p in bar

 
