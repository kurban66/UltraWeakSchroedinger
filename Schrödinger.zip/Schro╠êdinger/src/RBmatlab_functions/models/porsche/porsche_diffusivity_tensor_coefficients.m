function diff_tensor_coeff=porsche_diffusivity_tensor_coefficients(glob, params)
%function diff_tensor_coeff=porsche_diffusivity_tensor_coefficients(glob, params)
%
% function defining the diffusivity tensor coefficients of the porsche_model
%
% input:
%  - params: model
%  - glob: n points of the microgrid (n-by-2-matrix)
%
% output:
% diff_tensor_coeff = (number of macro triangles)-by-4 vector, defining the diffusivity-tensor-coefficients 
% so the coefficients a(x) in the PDE -div( a(x) grad u(x) ) + ...
%
%
% for the notation of the variables in this function see also:
%  "Reduced basis approximation and error bounds for potential
%   flows in parametrized geometries"
% by Gianluigi Rozza
%    MATHICSE Technical Report, Nr 11.2010, July 2010   
%
% Oliver Zeeb, 06.05.11
   
   % get the affine transformatins for every makrotriangle:
   % e.g. the transformation from reference to original domain.
   
   % macro points of the original domain:
   pmacro_ref=params.pmacro;     % macro points of the reference domain
   pmacro_glob = params.pmacro;  % macro points of the original/global domain
   % first points in pmacro_glob are the car points, all the others are
   % points on the rectangular, so only the first points have to be
   % changed:
   
   %alt: 12.05.2011, gilt so nur, wenn alle 7 punkte des models als parameter gef�hrt werden!
%    for k=1:length(params.mu_names)/2
%        x = getfield(params, params.mu_names{k});
%        y = getfield(params, params.mu_names{k+length(params.mu_names)/2});
%        pmacro_glob(k,:) = [x,y];
%    end
   %neu: 12.05.11: lese alle felder aus!
   for k=1:params.nr_macro_car_points
       x = getfield(params, ['x', num2str(k)]);
       y = getfield(params, ['y', num2str(k)]);
       pmacro_glob(k,:) = [x,y];
   end;

   % get all the transformations of the macrotriangles to the
   % reference-triangle, calculate the K-Matrices and add them to the
   % coefficient-vector
   K_o = eye(2);
   q = 1; %iteration variable
   diff_tensor_coeff = zeros(length(params.tmacro)*4,1);
   for k=1:length(params.tmacro)       
       tria_pts_ref  = pmacro_ref(params.tmacro(k,:),:);
       tria_pts_glob = pmacro_glob(params.tmacro(k,:),:);
       [C, G] = aff_trafo_coef(tria_pts_ref, tria_pts_glob);
       det_G=det(G); 
       G_inv = inv(G);
       
       %define the K-matrices (see equation (6.22) )
       % K_o,k = eyes for potential flow!
       K=det_G*G_inv*K_o*G_inv';
       for l=1:2
           for m=1:2
           diff_tensor_coeff(q) = K(m,l);
           q=q+1;
           end
       end
   end
   
