function rb_sim_data = porsche_rb_simulation(model,reduced_data)
%function rb_sim_data = porsche_rb_simulation(model,reduced_data)
% 
% this function performs a reduced simulation by using lin_stat_rb_simulation.
% After this, the output is calculated.
% This has to be done this way, because in lin_stat_rb_simulation 
% it is not possible to use the gradient of the
% solution instead of the solution itself for computing the
% output-functional.
%
% generated fields in rb_sim_data:
% - uN:      coefficients of the reduced solution
% - Delta:   error bound of the solution
% - Delta_s: error bound of the output 
% - s:       output (calculated by reduced basis method)
%
old_compute_output_functional=model.compute_output_functional;
model.compute_output_functional=0;
rb_sim_data = lin_stat_rb_simulation(model, reduced_data);
model.compute_output_functional=old_compute_output_functional;
if model.compute_output_functional == 1
    rb_sim_data.s = lincomb_sequence(reduced_data.lN_comp, rb_sim_data.uN);
end