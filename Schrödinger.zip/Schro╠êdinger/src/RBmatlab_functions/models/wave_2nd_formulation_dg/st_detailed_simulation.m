function sim_data = st_detailed_simulation(model,model_data)


old_mode = model.decomp_mode;
model.decomp_mode = 1; % complete

sim_data =[];

mu = model.mus;
A = [kron(model_data.operators.A_time,model_data.L2_space) + kron(model_data.L2_time, mu.^2*model_data.operators.A_space);
        kron(model_data.L2_time,model_data.L2_space)];
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time'; 
b = b(:); 

nb = length(b);
b = [zeros(nb,1);b];

uh.dofs = A\b;
uh.dofs;

% return results:
sim_data.uh = uh;

% % compute output
% if model.compute_output_functional
%   % the following can be used for any, also nonlinear functionals:
%   %sim_data.s =
%   %model.output_functional(model,model_data,sim_data.uh);
%   % for linear operators, get vector:
%   v = model.operators_output(model,model_data);
%   sim_data.s = (v(:)') * sim_data.uh.dofs;
% end;

model.decomp_mode = old_mode;