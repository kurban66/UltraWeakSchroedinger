clear, close, clc;

params.xrange=[0,1];
params.xnumintervals=10;
T=1;
params.trange=[0,T];
params.tnumintervals=10000;
params.pdeg_time = 1;
params.pdeg = 3;

model = dg_wave_model(params);

model_data = model.gen_model_data(model);




%% A detailed solution:
mu = 1e-12;

[m,n] = size(model_data.operators.b);


A = [kron(model_data.operators.A_time,model_data.L2_space) , -kron(model_data.L2_time,model_data.L2_space) ;
        mu*kron(model_data.L2_time,model_data.operators.A_space) , kron(model_data.operators.A_time,model_data.L2_space)];
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);

nb = length(b);
b = [zeros(nb,1);b];

uh = A\b;


%{
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);
nb = length(b);
b = [zeros(nb,1);b];

matvec = @(x) Ax(x,model,model_data);
uh = gmres(matvec,b);

%}


uh = reshape(uh(1:m*n),m,n);

model.mus = mu;

% Dirichlet in space:
uh = [zeros(1,n) ; uh ; zeros(1,n)];

% Dirichlet in time:
uh = [zeros(m+2,1) , uh];


%% Exact solution:

%U_ex = @(x) (1./(pi^2*mu^2))*(1-cos(t(i).*mu.*pi)).*sin(pi*x);
u_ex = @(t,x) (1./(pi^2*mu))*(1-cos(t.*sqrt(mu).*pi)).*sin(pi*x);
model.plot_solution_movie(model,model_data,uh,u_ex);




