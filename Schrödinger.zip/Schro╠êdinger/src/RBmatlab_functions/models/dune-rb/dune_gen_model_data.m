function model_data = dune_gen_model_data(model)
% function model_data = dune_gen_model_data(model[, params])
%
% method which produces all H dependent data, that is required for a
% detailed simulations and is independent of the parameter mu.
%
% This function does no create any fields in model_data

% call the mexptr
W = model.mexptr( 'gen_model_data' );

% model data is saved in mex process, the following is just for compatibility
% with RBmatlab models.
model_data        = [];
model_data.W      = W;
model_data.grid   = 'initialized in mexfile';
model_data.mexptr = model.mexptr;

%| \docupdate 
