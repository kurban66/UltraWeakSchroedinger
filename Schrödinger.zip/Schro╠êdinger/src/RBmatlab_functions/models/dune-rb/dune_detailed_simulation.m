function sim_data = dune_detailed_simulation(model, model_data)



% call mexptr, old mu values are backup'd and restored
sim_data = [];
U = model.mexptr( 'detailed_simulation' );
sim_data.U = U;
%| \docupdate 
