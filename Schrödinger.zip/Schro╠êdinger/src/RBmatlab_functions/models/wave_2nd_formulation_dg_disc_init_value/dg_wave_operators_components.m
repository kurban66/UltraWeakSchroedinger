function [A_space,A_time,r,h] = dg_wave_operators_components(model,model_data)

A_space = 0;
A_time = 0;
r = [];

% Prepare for the space:
model = transform_wave_model_space(model);
model_data.grid = model_data.grid_space;
model_data.df_info = model_data.df_info_space;

model.mus=1;

AA = dg_assembly_matrices(model,model_data);

for i=1:size(AA,1)
    A_space = A_space+AA{i};
end

model.decomp_mode=0;
X = model_data.grid_space.X;


for el_time=1:model_data.grid_time.nelements
    for i=1:length(model_data.df_info_time.LGL_nodes_on_element{el_time});
        ind = model_data.df_info_time.LGL_nodes_on_element{el_time}(i);
        k = model_data.df_info_time.elements_glob{el_time}(i);
        model.t = model_data.grid_time.X(ind);
        r(:,k) = zeros(model_data.df_info.nnodes,1);
        
        coeff = model.source(X(:),model);
        
        for el = 1:model_data.grid_space.nelements
            
            ind = model_data.df_info_space.elements_glob{el};
            r(ind,k) = coeff(model_data.df_info_space.LGL_nodes_on_element{el});
            
        end
        
        
    end
end
% Cautious with the boundary-terms!
if model.has_dirichlet_values 
    dir = model_data.df_info_space.dirichlet_ind;
    r(dir(:,1),:)=[];
end


% Now for time:
model = transform_wave_model_time(model);
model_data.grid = model_data.grid_time;
model_data.df_info = model_data.df_info_time;

model.has_dirichlet_values = 0;

AA = dg_assembly_matrices(model,model_data);


for i=1:size(AA,1)
    A_time = A_time+AA{i};
end



model.has_dirichlet_values = 1;
k = 1;
h(:,k) = zeros(model_data.df_info_space.nnodes,1);
coeff = model.dirichlet(X(:),model);

for el = 1:model_data.grid_space.nelements
    
    ind = model_data.df_info_space.elements_glob{el};
    h(ind,k) = coeff(model_data.df_info_space.LGL_nodes_on_element{el});
    
end

if model.has_dirichlet_values
    dir = model_data.df_info_space.dirichlet_ind;
    h(dir(:,1),:)=[];
end

end