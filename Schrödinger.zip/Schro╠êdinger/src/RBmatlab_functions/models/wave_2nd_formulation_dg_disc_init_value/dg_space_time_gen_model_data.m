function model_data = dg_space_time_gen_model_data(model)

model_data = [];

% First in space
model = transform_wave_model_space(model);
model_data.grid = dg_construct_grid(model);
model_data.df_info = dg_seminfo(model,model_data.grid);

W_semi = dg_compute_inner_product_matrix_h1_semi(model,model_data);
L2 = dg_compute_inner_product_matrix_l2(model,model_data);
W = W_semi+L2;
model_data.W_space = 0.5*(W+W');
model_data.W_semi_space = 0.5*(W_semi+W_semi');
model_data.L2_space = 0.5*(L2+L2');

model_data.grid_space = model_data.grid;
model_data.df_info_space = model_data.df_info;

model_data.grid_space.inner_product_matrix_h10 = model_data.W_space;
model_data.df_info_space.inner_product_matrix_h10 = model_data.W_space;


%% Now the same in time...
model=transform_wave_model_time(model);
model.has_dirichlet_values = 1;

model_data.grid_time = dg_construct_grid(model);
model_data.df_info_time = dg_seminfo(model,model_data.grid_time);

model_data.grid = model_data.grid_time;
model_data.df_info = model_data.df_info_time;

model.has_dirichlet_values = 0;

W_semi = dg_compute_inner_product_matrix_h1_semi(model,model_data);
L2 = dg_compute_inner_product_matrix_l2(model,model_data);

W = W_semi+L2;
model_data.W_time = 0.5*(W+W');
model_data.W_semi_time = 0.5*(W_semi+W_semi');
model_data.L2_time = 0.5*(L2+L2');
model_data.grid_time.inner_product_matrix_h10 = model_data.W_time;
model_data.df_info_time.inner_product_matrix_h10 = model_data.W_time;



[A_space,A_time,r,h] = dg_wave_operators_components(model,model_data);
model_data.operators.A_space = A_space;
model_data.operators.A_time = A_time;
model_data.operators.b = r;
model_data.operators.h = h;

[m,n]=size(r);

model_data.W = [kron(model_data.L2_time,model_data.L2_space) , sparse(1,1,0,m*n,m*n) ;
         sparse(1,1,0,m*n,m*n) , kron(model_data.L2_time,model_data.W_space)];



