function x = Ax(x,model,model_data)


[m,n] = size(model_data.operators.b);

mu = model.mus;

u = reshape(x(1:m*n),m,n);
w = reshape(x(m*n+1:end),m,n);

U = model_data.L2_space*u*model_data.operators.A_time' - model_data.L2_space*w*model_data.L2_time';
W = mu*model_data.operators.A_space*u*model_data.L2_time' + model_data.L2_space * w * model_data.operators.A_time;

x = [U(:);W(:)];