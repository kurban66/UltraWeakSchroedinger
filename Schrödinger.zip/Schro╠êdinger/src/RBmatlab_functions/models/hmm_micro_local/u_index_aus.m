function [u_index]=u_index_aus(u,index)
%
% Liest aus dem globalen Loesungsvektor u die Werte an den Indexstellen
% aus.
%
% Input:  u        globaler Loesungsvektor 
%         index    Indexmenge fuer lokale Lsg.
%
% Output: u_index  Lsg u an den angegebenen Indexstellen


index = sort(index);
Ie = [];
Ia = 1;
u_index = [];
for i=1:length(index)-1;
    if index(i+1)-index(i)==0
        error('Index kommt doppelt vor');
    elseif index(i+1)-index(i)>1     % Zusaetzliche Abfrage, dass mind 5 aufeinanderfolgende Werte
        Ia = [Ia, i+1];
        Ie = [Ie, i];
    end
end
Ie = [Ie,length(index)];

for i=1:length(Ie)
    ni = Ie(i)-Ia(i)+1;  % Anzahl aufeinanderfolgender Stuetzstellen
    if ni<=4
       error('Zu wenig aufeinanderfolgende Stuetzstellen.') 
    end
        
    uc = u(index(Ia(i)):index(Ie(i)));
    u_index = [u_index; uc];
end