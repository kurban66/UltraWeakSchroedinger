function [w]=g0(a,b,c,d)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Funktion fuer Flussberechnung in FD Verfahren nach LeFloch & Hayes  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [w]=g0(a,b,c,d)

w = (-d^3+7*c^3+7*b^3-a^3)/12;