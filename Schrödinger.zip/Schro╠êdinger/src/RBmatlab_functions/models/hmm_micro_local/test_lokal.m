function [u,dx,fehler]=test_lokal(Time,ul,ur,alpha,n_x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%   1D, skalare Erhaltungsgleichung                                       %
%                                                                         %
%   mikroskopisches Modell (lokale Regularisierung)                       %
%         u_t+f(u)_x = epsilon u_{xx} + alpha*epsilon^2 u_{xxx}           %
%   mit f(u) = u^3                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Input: Time     Endzeit Mikroproblem, z.B.: 2.24*10^(-5)
%        ul       linker Zustand, z.B.: 4
%        ur       rechter Zustand, z.B.: -2 
%        alpha    Parameter, z.B.: 4
%        n_x      Anzahl Ortsschritte, z.B.: 300
%
% Output: u       Lsg 
%         dx      Ortsschrittweite
%         fehler  Fehler zw. lokaler und globaler Lsg
%
% Bsp: [u,dx,fehler]=test_lokal(2.24*10^(-5),4,-2,4,300)

%close all
clc

epsilon = 10^(-5);  % Regularisierungsparameter
dx=2*epsilon/5;            % Ortsschrittweite
x = (-40*dx:dx:-40*dx+(n_x-1)*dx);  % Gitter
w = max(abs(ul),abs(ur));
dt = 0.06*min([dx/(3*w^2), dx^2/(2*epsilon), dx^3/(3*alpha*epsilon^2)]); % Zeitschrittweite  %% fuer 
                                                                         % ul<-4 vorne 0.06 durch 0.01 ersetzen!!! 
n_t=round(Time/dt);  % Anzahl Zeitschritte

u = zeros(length(x),1);   % initialisieren
for i=1:length(x)
    if x(i)<0
        u(i) = ul;
    else
        u(i) = ur;
    end
end


% Loesen des Mikroproblems - Lsg zum Zeitpunkt T
for j=1:n_t    % ueber Zeit
    [u]=Phasen_lokal(u,epsilon,alpha,[],dx,dt);
end

u_sicher = u;

% Indices, auf denen Lsg lokal berechnet werden soll
i1=(15:1:20);
i2=(150:1:170);
i3=(190:1:200);
index=[i1,i2,i3];
         
% Auslesen der u-Daten an den Index-Stellen
[u_index]=u_index_aus(u_sicher,index);

% lokale Loesung zum Zeitpunkt T+dt
[u,index_n]=Phasen_lokal(u_index,epsilon,alpha,index,dx,dt);
X = x(index_n);
        
% Kontrolle/ global Loesung zum Zeitpunkt T+dt
[u_kontrolle]=Phasen_lokal(u_sicher,epsilon,alpha,[],dx,dt);
    
% Fehler zwischen globaler und lokaler Loesung
fehler = max(abs(u_kontrolle(index_n)-u));
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  PLOT     

figure  % Plot zu u-Werten
hold on
plot(x,u_kontrolle,'LineWidth',2)
plot(X,u,'ro')
title('u')
legend('globale Lsg bei T+dt','lokale Lsg bei T+dt')
xlabel('x')

% Bestimmung mittlerer Zustand um und Geschwindigkeit
%[um,v]=HMM_UM_GESCHW(u_kontrolle,dx,n_x,ul);
