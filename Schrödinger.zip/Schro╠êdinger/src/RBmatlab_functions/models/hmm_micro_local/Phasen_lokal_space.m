function [uinc,index_n]=Phasen_lokal_space(u,epsilon,alpha,index,dx,dt)
%
% Loest mikroskopische Modell u_t+f(u)_x = epsilon u_{xx} + alpha*epsilon^2 u_{xxx}
% als increment, wird spaeter mit dt multipliziert
% 
% Input: u          Lsg. vor Zeitschritt
%        epsilon    Regularisierungsparameter
%        alpha      Parameter
%        index      Indexmenge, fuer lokale Lsg, [] ergibt globale
%        dx,dt      Ortsschrittweite bzw. Zeitschrittweite
% 
% Output: dt_u      diskrete Ableitung fuer u 
%         index_n   neue Indexmenge, nimmt von jedem Miniintervall 2
%                   Randpunkte weg


beta = 2*epsilon/dx;                  % Verhaeltnisse
gamma = 3*alpha*(epsilon/dx)^2;

if isempty(index)     % globale Lsg
  uinc = zeros(size(u));
  n_x = length(u);
  uc=u;
%  uinc(1) = uc(1);  % OE: Intervall so gross, dass linker bzw. rechter Rand const. (inflow/outflow)
  uinc(1) = 0;  % OE: Intervall so gross, dass linker bzw. rechter Rand const. (inflow/outflow)
  uinc(2) = uc(2);
  for i=3:(n_x-2)    
    uinc(i)= REGULARlok_space(uc,i,beta,gamma,dx,dt);
  end
%  u(n_x-1) = uc(n_x-1);
%  u(n_x) = uc(n_x);
  uinc(n_x-1) = 0;
  uinc(n_x) = 0;
            
else      % lokale Lsg
    index = sort(index);
    U = [];
    Ie = [];
    Ia = 1;
    I = [];
    for i=1:length(index)-1;
        if index(i+1)-index(i)==0
            error('Index kommt doppelt vor');
        elseif index(i+1)-index(i)>1     % Zusaetzliche Abfrage, dass mind 5 aufeinanderfolgende Werte
            Ia = [Ia, i+1];
            Ie = [Ie, i];
        end
    end
    Ie = [Ie,length(index)];
        
    for i=1:length(Ie)
        ni = Ie(i)-Ia(i)+1;  % Anzahl aufeinanderfolgender Stuetzstellen
        if ni<=4
           error('Zu wenig aufeinanderfolgende Stuetzstellen.') 
        end
        
        % Mikroproblem auf Intervall loesen
        uc = u(index(Ia(i)):index(Ie(i)));
        u_local = zeros(ni,1);
        for k=3:(ni-2)    
            u_local(k)=REGULARlok(uc,k,beta,gamma,dx,dt);
        end
        u_local(1:2)=[];
        u_local(end-1:end)=[]; 
        U = [U;u_local];
        I = [I,index(Ia(i)+2):index(Ie(i)-2)];
        
    end
    u = U;
    index_n = I;
    
end