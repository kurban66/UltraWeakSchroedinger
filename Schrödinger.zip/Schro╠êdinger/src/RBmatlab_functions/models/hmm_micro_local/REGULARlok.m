function [ui]=REGULARlok(u,i,beta,gamma,dx,dt)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   Diskretisierung der lokalen Regularisierung                       %%%
%%%   u_t + f(u)_x = epsilon u_xx + alpha*epsilon^2 u_xxx               %%%
%%%                                                                     %%%
%%%   nach dem paper von LeFloch & Hayes                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [ui]=Regular(u,i,beta,gamma,dx,dt)

ui = u(i)+dt/dx*(g0(u(i-2),u(i-1),u(i),u(i+1))-g0(u(i-1),u(i),u(i+1),u(i+2)))+beta*dt/(2*dx)*(u(i+1)-2*u(i)+u(i-1))+gamma*dt/(6*dx)*(u(i+2)-2*u(i+1)+2*u(i-1)-u(i-2));