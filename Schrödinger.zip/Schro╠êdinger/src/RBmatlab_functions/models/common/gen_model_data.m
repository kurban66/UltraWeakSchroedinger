function model_data = gen_model_data(model)
%function model_data = gen_model_data(model)
%
% function computing model_data from model
% simple evaluation of function pointer in model

% Bernard Haasdonk 26.8.2009

model_data = model.gen_model_data(model);

