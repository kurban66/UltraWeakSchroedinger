function dune_demo_rb_gui(varargin)
% function dune_demo_rb_gui(model,detailed_data,[reduced_data],plot_params[,title, callbackfigure, cbhandle])
% reduced basis demo with sliders for a remotely running DUNE-rb server
% application
%

% Martin Drohmann 08.02.2012
% Bernard Haasdonk 20.7.2006

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% open figure
if nargin < 6 % no callback,open new figure
  f = figure;
  ud = [];
  list = varargin;
  if nargin==0
    error(['no arguments passed, cannot load a reduced basis']);
  end;

  if nargin <3
    list{3} = [];
  end;
  if nargin <4
    list{4} = [];
  end;
  if nargin <5
    list{5} = 'Dune RB Demo GUI';
  end;

  ud.model = list{1};
  ud.descr = ud.model.descr;
  if isa(list{2}, 'IDetailedData')
    ud.detailed_data = list{2};
  end;

%  if ud.model.crb_enabled
%    ud.model.set_Mratio(ud.detailed_data, 0.5);
%  end

  if ~isfield(ud.descr,'is_stationary')
    ud.descr.is_stationary = 0; % for evolution problems
  end

  ud.plot_params = list{4};
  if isempty(ud.plot_params)
    % copy some fields from model
    if isfield(ud.descr,'yscale_uicontrols')
      ud.plot_params.yscale_uicontrols = ud.descr.yscale_uicontrols;
    end;
    if isfield(ud.descr,'xscale_gui');
      ud.plot_params.xscale_gui = ud.descr.xscale_gui;
    end;
    if isfield(ud.descr,'clim');
      ud.plot_params.clim = ud.descr.clim;
    end;
    if isfield(ud.descr,'show_colorbar');
      ud.plot_params.show_colorbar = ud.descr.show_colorbar;
    end;
  end;
%  ud.grid = ud.detailed_data.grid;
  if isempty(list{3})
    disp('Preparing offline-quantities...')
    %      keyboard;
    ud.reduced_data = gen_reduced_data(ud.model, ud.detailed_data);
  else
    ud.reduced_data = list{3};
  end;
  if length(list) > 4;
    set(f,'Name',list{5});
  end;
  ud.timestep = 0;
  set(f,'Userdata',ud);
  di = 0.05; % relative distance between gui_objects
  textwidth= 0.15;
  textheight = 0.05;
  yscale_uicontrols = 1.0;
  xscale_gui = 1.0;

  if isfield(ud.plot_params,'yscale_uicontrols')
    yscale_uicontrols = ud.plot_params.yscale_uicontrols;
  end;
  if isfield(ud.plot_params,'xscale_gui')
    xscale_gui = ud.plot_params.xscale_gui;
  end;

  % xscale gui
  p = get(gcf,'Position');
  p(3) = p(3) * xscale_gui;
  set(gcf,'Position',p);

  % create one txt and slider for each mu_name
  for i=1:length(ud.model.mu_names)
    % set mu-param-values to minimum of ranges as the position of a
    % slider does not seem to be adjustable
    tmprange = cell2mat(ud.model.mu_ranges);
    ud.model = set_mu(ud.model,tmprange(1:2:end));
    mu = get_mu(ud.model);
    val = mu(i);
    ra = ud.model.mu_ranges{i};
    norm_val = (val-ra(1))/(ra(2)-ra(1));
    txt(i) = uicontrol(f,'Style','text','Units','normalized',...
                       'Position',...
                       [di,(i*di+(i-1)*textheight)*yscale_uicontrols,...
                        textwidth,textheight*yscale_uicontrols],...
                       'String',[ud.model.mu_names{i},'=',num2str(val)],...
                       'Tag',['text_',ud.model.mu_names{i}]);
    slider(i) = uicontrol(f,'Style','slider','Units','normalized',...
                          'Position',...
                          [ 2*di+textwidth, ...
                          (i*di+(i-1)*textheight)*yscale_uicontrols, ...
                          1-3*di-textwidth,...
                          textheight*yscale_uicontrols],...
                          'Tag',['slider_',ud.model.mu_names{i}],...
                          'Min',0, ...
                          'Max',1, ...
                          'value',norm_val, ...
                          'Callback','dune_demo_rb_gui([],[],[],[],[], gcbf,gcbo)');
    %                     'Min',ud.model.mu_ranges{i}(1), ...
%                         'Max',ud.model.mu_ranges{i}(2), ...

  end;
  set(f,'Userdata',ud);

  % N = number of RB slider
  i = length(ud.model.mu_names)+1;
  txt(i) = uicontrol(f,'Style','text','Units','normalized',...
                     'Position', ...
                     [di,(i*di+(i-1)*textheight)*yscale_uicontrols,...
                      textwidth,textheight*yscale_uicontrols],...
                     'String',['RB-size N = ',num2str(get_rb_size(ud.detailed_data, ud.model))],...
                     'Tag','text_N');
  slider(i) = uicontrol(f,'Style','slider','Units','normalized',...
                        'Position',...
                        [2*di+textwidth, ...
                        (i*di + (i-1)*textheight)*yscale_uicontrols, ...
                        1-3*di-textwidth,textheight*yscale_uicontrols],...
                        'Tag','slider_N',...
                        'min',1,'max', ...
                        get_rb_size(ud.detailed_data, ud.model),...
                        'value',ud.model.N, ...
                        'Callback','dune_demo_rb_gui([],[],[],[],[],gcbf,gcbo)',...
                        'sliderstep',...
                        [1/((get_rb_size(ud.detailed_data, ud.model))-1),0.1]);


  % M = number of CRB slider
  if ud.model.crb_enabled
    i = length(ud.model.mu_names)+2;
    txt(i) = uicontrol(f,'Style','text','Units','normalized',...
                       'Position', ...
                       [di,(i*di+(i-1)*textheight)*yscale_uicontrols,...
                        textwidth,textheight*yscale_uicontrols],...
                       'String',['CRB-size M = ',num2str(get_Mratio(ud.model,ud.detailed_data))],...
                       'Tag','text_M');
    slider(i) = uicontrol(f,'Style','slider','Units','normalized',...
                          'Position',...
                          [2*di+textwidth, ...
                          (i*di + (i-1)*textheight)*yscale_uicontrols, ...
                          1-3*di-textwidth,textheight*yscale_uicontrols],...
                          'Tag','slider_M',...
                          'min',0,'max',1,'value',...
                          get_Mratio(ud.model,ud.detailed_data), ...
                          'Callback','dune_demo_rb_gui([],[],[],[],[],gcbf,gcbo)',...
                          'sliderstep',[1/100,0.1]);
  end; % if nonlin-evol

  % time slider
  if ~ud.descr.is_stationary
    i = i+1;  %length(ud.params.mu_names)+2; % or +3 if M-slider available!
    txt(i) = uicontrol(f,'Style','text','Units','normalized',...
                       'Position', ...
                       [di,(i*di+(i-1)*textheight)*yscale_uicontrols,...
                       textwidth,textheight*yscale_uicontrols],...
                       'String','timestep 0','Tag','text_time');
    slider(i) = uicontrol(f,'Style','slider','Units','normalized',...
                          'Position',...
                          [2*di+textwidth, ...
                          (i*di + (i-1)*textheight)*yscale_uicontrols, ...
                          1-3*di-textwidth,textheight*yscale_uicontrols],...
                          'Tag','slider_time',...
                          'min',0,'max',ud.descr.nt,'value',0, ...
                          'Callback','dune_demo_rb_gui([],[],[],[],[],gcbf,gcbo)',...
                          'sliderstep',[1/ud.descr.nt,0.1]);
  end

  pos = [10 300 100 10];
  ht = uicontrol(f,'Style','Text','Position',pos);
  string = {'This is a string for the left text uicontrol.',...
            'to be wrapped in Units of Pixels,',...
            'with a position determined by TEXTWRAP.'};
  % Wrap string, also returning a new position for ht
  [outstring,newpos] = textwrap(ht,string)

  replot(f,'new');
%  set(f,'Resize','on');
end;

if nargin >=6 % callback-function
  cbf = varargin{6};
  cbo = varargin{7};
  ud = get(cbf,'Userdata');
%  disp('performing callback call of plot_fv_data');
  % set new parameters in ud.params
  tag = get(cbo,'Tag');
  if isequal(tag,'slider_time')
    val = round(get(cbo,'value'));
    set(cbo,'value',val);
%    disp('check value of timestep!');
%    keyboard;
    ud.timestep = val;
    txt = findobj(cbf,'Tag','text_time');
    set(txt,'String',['timestep = ',num2str(val)]);
    sourcestr = 'time';
  elseif isequal(tag,'slider_N')
    val = round(get(cbo,'value'));
    set(cbo,'value',val);
    ud.model.N = val;
    txt = findobj(cbf,'Tag','text_N');
    set(txt,'String',['RB-size N = ',num2str(val)]);
    sourcestr = 'N';
  elseif isequal(tag,'slider_M')
    val = get(cbo,'value');
    set(cbo,'value',val);
    ud.model.M = ceil(val * get_ei_size(ud.detailed_data.datatree));
    txt = findobj(cbf,'Tag','text_M');
    set(txt,'String',['CRB-size M = ',num2str(val)]);
    sourcestr = 'M';
  else
    found_cbo = 0;
    for i=1:length(ud.model.mu_names)
      if isequal(tag,['slider_',ud.model.mu_names{i}])
%       keyboard;
        found_cbo = 1;
        val = get(cbo,'value')*...
                  (ud.model.mu_ranges{i}(2)-...
                   ud.model.mu_ranges{i}(1)) + ...
                   ud.model.mu_ranges{i}(1);

        mu = get_mu(ud.model);
        mu(i) = val;
        ud.model = set_mu(ud.model,mu);

        txt = findobj(cbf,'Tag',['text_',ud.model.mu_names{i}]);
        set(txt,'String',[ud.model.mu_names{i},' = ',num2str(val)]);
        sourcestr = 'mu';
      end;
    end;
    if ~found_cbo
      error('callback object unknown!!');
    end;
  end;
  set(cbf,'Userdata',ud);
  replot(cbf,sourcestr);
end;

function replot(f,tag)
ud = get(f,'Userdata');

enable_error_estimator = ud.model.enable_error_estimator;

data_reload_required = false;
% if required perform new RB simulation
if ismember(tag,{'new','mu','N','M'})
  % in our problem the two bounds can be chosen 1
  %  ud.model.descr.error_norm = 'l2';

  data_reload_required = true;

  mu = get_mu(ud.model);
  % prepare mu-independent but N-dependent online-data
  %ud.params.N = size(ud.detailed_data.RB,2);
  if ud.model.crb_enabled
    disp(['performing RB simulation with N = ',num2str(ud.model.N),...
          ', M = ', num2str(ud.model.M),...
          ' for mu = [',num2str(mu(:)'),']']);
  else
    disp(['performing RB simulation with N = ',num2str(ud.model.N),...
          ' for mu = [',num2str(mu(:)'),']']);
  end;
  reduced_data = extract_reduced_data_subset(ud.model,ud.reduced_data);

  % perform RB-simulation
  ud.model = set_mu(ud.model,mu);

  simulation_data = rb_simulation(ud.model,reduced_data);

  rb_sim_data = rb_reconstruction(ud.model,ud.detailed_data,simulation_data);
  if enable_error_estimator
    ud.Delta = ud.model.get_estimators_from_sim_data(simulation_data);
    if isfield(simulation_data,'reslog')
      ud.reslog = simulation_data.reslog;
      ud.eilog = simulation_data.eilog;
    end
  end
  ud.sim_data = rb_sim_data;
  if isfield(ud.descr,'name_output_functional')
    ud.s = simulation_data.s;
    if enable_error_estimator
      ud.Delta_s = simulation_data.Delta_s;
    end
  end;
  if ~isfield(ud.plot_params,'clim')
    U = ud.model.get_dofs_from_sim_data(rb_sim_data);
    ud.cmin = min(min(U));
    ud.cmax = max(max(U));
    if (ud.cmin==ud.cmax)
      ud.cmin = ud.cmin-eps;
      ud.cmax = ud.cmax+eps;
    end;
    clear('U');
  else
    ud.cmin = ud.plot_params.clim(1);
    ud.cmax = ud.plot_params.clim(2);
  end
  set(f,'Userdata',ud);

end

% plot current slice;

if enable_error_estimator
  disp(['error_estimator Delta(',num2str(ud.timestep),') = ',...
        num2str(ud.Delta(ud.timestep+1))]);
  if isfield(ud.descr,'name_output_functional')
    disp(['output-estimator s(U(',num2str(ud.timestep),')) = ',...
          num2str(ud.s(ud.timestep+1))]);
    disp(['output-error-estimator Delta_s(',num2str(ud.timestep),...
          ') = ', num2str(ud.Delta_s(ud.timestep+1))]);
  end;
  if isfield(ud,'reslog')
    disp(['error_estimator reslog(',num2str(ud.timestep),') = ',...
          num2str(ud.reslog(ud.timestep+1))]);
    disp(['error_estimator eilog(',num2str(ud.timestep),') = ',...
          num2str(ud.eilog(ud.timestep+1))]);
  end
end
fprintf('plotting...');

ud.plot_params.timestep = ud.timestep;
ud.plot_params.gcf      = gcf;
ud.plot_params.reload_required = data_reload_required;
plot_sim_data(ud.model.detailed_model, ...
              ud.detailed_data, ...
              ud.sim_data, ...
              ud.plot_params);

fprintf('done\n');

%| \docupdate 
