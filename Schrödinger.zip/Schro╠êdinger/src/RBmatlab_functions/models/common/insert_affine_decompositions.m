function model = insert_affine_decompositions(model)
%function model = insert_affine_decompositions(model)
% the field '<name>' is created as a parameter separable function, if both
% '<name>_components' and '<name>_coefficients' are present fields of model

names = fieldnames(model);

for i = 1:length(names)
    
    index = regexp(names{i}, '_components');
    
    if ~isempty(index) && isfield(model, [names{i}(1:index-1), '_coefficients'])
        
        model.(names{i}(1:index-1)) = @(varargin) eval_affine_decomp_general(...
            model.(names{i}), ...
            model.([names{i}(1:index-1), '_coefficients']), ...
            varargin{:});
    end
end

end