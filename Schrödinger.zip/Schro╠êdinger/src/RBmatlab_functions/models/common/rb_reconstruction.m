function rb_sim_data = rb_reconstruction(model,detailed_data,rb_sim_data)
%function rb_sim_data = rb_reconstruction(model,detailed_data,rb_sim_data)
% 
% function performing an rb reconstruction.
% simple call of pointer in model

% Bernard Haasdonk 28.8.2009

rb_sim_data = model.rb_reconstruction(model,detailed_data, rb_sim_data);

