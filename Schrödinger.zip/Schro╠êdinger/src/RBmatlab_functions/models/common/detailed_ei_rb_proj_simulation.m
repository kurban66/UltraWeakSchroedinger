function sim_data = detailed_ei_rb_proj_simulation(model,model_data)
%function sim_data = detailed_ei_rb_proj_simulation(model,model_data)
%
% method performing detailed simulation with empirically interpolated operators
% and results are projected onto the RB space after each time step.  
% models should have default parameters.
% simple call of pointer in model

% Martin Drohmann and Bernard Haasdonk 21.7.2009

sim_data = model.detailed_ei_rb_proj_simulation(model, model_data);

%| \docupdate 
