function res = discrete_volume_values(func,varargin)
%function res = discrete_volume_values(func,varargin)
% Convert a volume function with global evaluation to local evaluation

if nargin == 5
  loc = varargin{3};
  if numel(loc) == 0
    glob = [];
  else
    glob = local2global(varargin{1},varargin{2},loc);
  end;
elseif nargin == 3
  glob = varargin{1};
else
  error('incorrect number of inputs');
end;
res = func(glob,varargin{end});

end
