


function a0 = rb_init_values(model, detailed_data)
%function a0 = rb_init_values(model, detailed_data)
%
% function calling the rb_init_values method in the model
%
% Required fields of model:
%   rb_init_values: handle
%

  a0 = model.rb_init_values(model, detailed_data);
end

