function model=unitcube(model)
% function model=unitcube(model)
% function adding fields to model for generating a 2D rectgrid with '100 x 100'
% elements on the unit-square

model.gridtype      = 'rectgrid';
model.xrange        = [0,1];
model.yrange        = [0,1];
model.xnumintervals = 100;
model.ynumintervals = 100;

