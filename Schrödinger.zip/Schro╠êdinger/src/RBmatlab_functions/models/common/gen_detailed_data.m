function detailed_data = gen_detailed_data(model, model_data)
%function detailed_data = gen_detailed_data(model, model_data)
%
% function computing detailed_data from model and model_data
% simple evaluation of function pointer in model

% Bernard Haasdonk 26.8.2009

detailed_data = model.gen_detailed_data(model, model_data);
 
