function [opt_data,model] = optimize(model, model_data, detailed_data, reduced_data)
%opt_data = optimize(model, model_data, detailed_data, reduced_data)
%
%Method starting optimization and returning results in opt_data.
%
% Markus Dihlmann 28.04.2010
%

[opt_data,model] = model.optimization.optimizer(model, model_data, detailed_data, reduced_data);

