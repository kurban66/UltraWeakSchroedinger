function res = discrete_boundary_values(val,varargin)
%function res = discrete_boundary_values(val,varargin)
% Convert a boundary function with global evaluation to local evaluation

if nargin == 6
  lloc = varargin{4};
  if numel(lloc) == 0
    glob = [];
  else
    loc = llocal2local(varargin{1},varargin{3},lloc);
    glob = local2global(varargin{1},varargin{2},loc);
  end;
elseif nargin == 3
  glob = varargin{1};
else
  error('incorrect number of inputs');
end;  
res = val(glob,varargin{end});

end
