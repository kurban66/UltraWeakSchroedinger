function sim_data = detailed_ei_simulation(model,model_data)
%function sim_data = detailed_ei_simulation(model,model_data)
%
% method performing detailed simulation with empirically interpolated operators
% models should have default parameters.
% simple call of pointer in model

% Martin Drohmann and Bernard Haasdonk 21.7.2009

if nargin == 2
  params = [];
end

sim_data = model.detailed_ei_simulation(model, model_data);

%| \docupdate 
