function data = postprocess_gravity(data, glob, params)
%function data = postprocess_gravity(data, glob, params)
% subtracts a previously added addent induced by gravitational effects.
%
% In case of a numerical scheme for the Richard's equation it is possible to
% model gravity by adding a defect growing with height to the initial data
% function. This way, the resulting concentration gradient diffuses a down-ward
% flow is created.
%
% required fields of params:
%   - 'gravity':   gravitational factor

data = data - glob(:,2) * params.gravity;

end
%| \docupdate 
