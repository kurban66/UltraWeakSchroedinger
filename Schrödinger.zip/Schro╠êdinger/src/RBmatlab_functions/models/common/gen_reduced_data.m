function reduced_data = gen_reduced_data(model, detailed_data)
%function reduced_data = gen_reduced_data(model, detailed_data)
%
% function computing reduced_data from model and detailed_data 
% simple evaluation of function pointer in model

% Bernard Haasdonk 26.8.2009

reduced_data = model.gen_reduced_data(model, detailed_data);

