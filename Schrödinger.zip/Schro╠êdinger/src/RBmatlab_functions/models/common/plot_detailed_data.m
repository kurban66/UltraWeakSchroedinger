function plot_detailed_data(model, detailed_data, plot_params)
%function plot_detailed_data(model, detailed_data, plot_params)
%
% function plotting the detailed data in a problem specific manner
% simple call of pointer in model

% Bernard Haasdonk 26.8.2009
%

if nargin <= 2
  plot_params = [];
end

model.plot_detailed_data(model,detailed_data,plot_params);


