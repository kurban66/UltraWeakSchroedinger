function rb_sim_data = rb_simulation(model,reduced_data)
%function rb_sim_data = rb_simulation(model,reduced_data)
%
% method performing reduced simulation.
% simple call of pointer in model

% Martin Drohmann and Bernard Haasdonk 21.7.2009

rb_sim_data = model.rb_simulation(model, reduced_data);

