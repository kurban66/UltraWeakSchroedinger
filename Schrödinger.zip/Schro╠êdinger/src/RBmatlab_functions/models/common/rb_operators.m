function varargout = rb_operators(model, detailed_data)
%function varargout = rb_operators(model, detailed_data)
%
% function calling the rb_operators method in the model
%
% Required fields of model:
%   rb_operators: handle
%

  [varargout{1:nargout}] = model.rb_operators(model, detailed_data);
end

