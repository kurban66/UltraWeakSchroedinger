function model=model_default(model, T, nt)
% model = model_default(model)

model.t               = 0;
model.tstep           = 1;
model.decomp_mode     = 0;
model.verbose         = 0;
model.debug           = 0;
model.orthonormalize  = @model_orthonormalize_qr;
model.dt              = model.T / model.nt;
model.ei_time_indices = 1:model.nt+1;
model.mu              = zeros(size(model.mu_names));
%| \docupdate 
