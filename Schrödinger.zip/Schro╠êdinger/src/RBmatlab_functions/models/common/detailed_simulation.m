function sim_data = detailed_simulation(model,model_data)
%function sim_data = detailed_simulation(model,model_data)
%
% method performing detailed simulation 
% models should have default parameters.
% simple call of pointer in model

% Martin Drohmann and Bernard Haasdonk 21.7.2009

sim_data = model.detailed_simulation(model, model_data);
%| \docupdate 
