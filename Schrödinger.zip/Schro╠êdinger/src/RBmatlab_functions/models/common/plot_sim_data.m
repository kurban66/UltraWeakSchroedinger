function p = plot_sim_data(model,model_data,sim_data,plot_params)
%function p = plot_sim_data(model,model_data,sim_data,plot_params)
% function performing the plot of the simulation results as specified in model.
%
% parameters:
%   plot_params : parameter structure controlling the output of the plot. Refer
%                 to the documentation of 'model.plot_sim_data' for more
%                 details. For time dependent problems 'plot_params' are often
%                 passed to plot_element_data() and plot_sequence().
%
% required fields of model:
%   plot_sim_data : problem specific function actually performing the plot.
%
% return values:
%   p : plot handle

% Bernard Haasdonk 4.9.2009

p = model.plot_sim_data(model,model_data,sim_data,plot_params);

