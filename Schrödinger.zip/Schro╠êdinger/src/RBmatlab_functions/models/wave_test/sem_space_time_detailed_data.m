function detailed_data = st_detailed_data(model,model_data)


detailed_data = [];
detailed_data.grid = model_data.grid;
detailed_data.df_info = model_data.df_info;
detailed_data.W = model_data.W;
detailed_data.operators = model_data.operators;


detailed_data.W_space = model_data.W_space;
detailed_data.W_semi_space = model_data.W_semi_space;
detailed_data.L2_space = model_data.L2_space;
detailed_data.grid_space = model_data.grid_space;
detailed_data.df_info_space = model_data.df_info_space;
detailed_data.grid_time = model_data.grid_time;
detailed_data.df_info_time = model_data.df_info_time;
detailed_data.W_time = model_data.W_time;
detailed_data.W_semi_time = model_data.W_semi_time;
detailed_data.L2_time = model_data.L2_time;

detailed_data = rb_basis_generation(model,detailed_data);