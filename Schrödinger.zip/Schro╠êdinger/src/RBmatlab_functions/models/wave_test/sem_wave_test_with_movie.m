clear, close, clc;

params.xrange=[-4,4];
params.xnumintervals=800;
T=5;
params.trange=[0,T];
params.tnumintervals=5000;
params.pdeg_time = 2;
params.pdeg = 2;

model = sem_wave_model(params);

model_data = model.gen_model_data(model);




%% A detailed solution:
mu = 1;
model.mus = mu;

[m,n] = size(model_data.operators.b);


A = [kron(model_data.operators.A_time,model_data.L2_space) , -kron(model_data.L2_time,model_data.L2_space) ;
        mu*kron(model_data.L2_time,model_data.operators.A_space) , kron(model_data.operators.A_time,model_data.L2_space)];
    
b = (model_data.L2_space * model_data.operators.b) * model_data.L2_time';
b = b(:);

nb = length(b);
b = [zeros(nb,1);b];

uh = A\b;

uh = reshape(uh(1:m*n),m,n);


% Dirichlet in space:
%uh = [zeros(1,n) ; uh ; zeros(1,n)];

% Dirichlet in time:
%uh = [zeros(m+2,1) , uh];


model.plot_numerical_sol_with_movie(model.model_data,uh);
