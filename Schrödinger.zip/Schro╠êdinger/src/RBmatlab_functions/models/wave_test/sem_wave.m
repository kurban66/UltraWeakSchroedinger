clear, close, clc;

params.xrange=[0,1];
params.xnumintervals=10;
T=1;
params.trange=[0,T];
params.tnumintervals=100;
params.pdeg_time = 1;
params.pdeg = 1;

model = sem_wave_model(params);
model.RB_stop_epsilon=1e-12;
N=50;
model.RB_stop_Nmax = N;
model.mu_ranges={[1 2]};
numintervals=10;
model.RB_numintervals = numintervals;



model_data = model.gen_model_data(model);



%% Generate detailed_data:
detailed_data = model.gen_detailed_data(model,model_data);


%% save data
filename = ['xnumintervals=' num2str(params.xnumintervals) 'pdeg=' num2str(params.pdeg(1)) ...
    'tnumintervals=' num2str(params.tnumintervals) 'pdeg=' ...
    num2str(params.pdeg_time(1)) 'tol=' num2str(model.RB_stop_epsilon) ...
    'RBnumintervals=' num2str(numintervals) ...
    'mu_ranges=[' num2str(model.mu_ranges{1}(1)) ',' ...
    num2str(model.mu_ranges{1}(2)) ']'];
save(filename);