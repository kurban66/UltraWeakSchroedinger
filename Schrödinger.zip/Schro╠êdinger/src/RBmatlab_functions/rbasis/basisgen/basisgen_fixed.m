function detailed_data = basisgen_fixed(model,detailed_data)
%function detailed_data = basisgen_fixed(model,detailed_data)
%
% script demonstrating the generation of a reduced basis with
% a fixed training set approach. 
%
% RB is started with initial data by varying all parameters over M_train.
% The basis is extended by searching for the vector in the training set
% Mu_train with the maximum posterior error estimator or true error, for
% this mu a single vector is chosen for basisextension. 
% The resulting reduced basis vectors are returned in RB which is a 
% matrix of columnwise reduced basis vector-DOFS
% The algorithm supports restart, i.e. continuing of prescribed
% initial basis RB.
%
% outputs of detailed_data:
%           RB,V,W etc. : collection of orthonormal reduced basis DOF
%                vectors
%           RB_info: datastructure with basis-generation
%                information, see RB_greedy_extension for details
%
% required fields of detailed_data:
%           RB_info.M_train : matrix with columnwise parameter
%                             vectors to use in greedy search
%           grid : numerical grid, is constructed if not existent.
%
% required fields of model and detailed_data such that a reduced basis
% simulation can be performed and RB_greedy_extension can be performed.

% Bernard Haasdonk 27.3.2007

% We assume, that detailed_data is reasonably filled, e.g. contains
% the grid.
%
% generate grid
%if ~isfield(detailed_data,'grid') || isempty(detailed_data.grid)
%  detailed_data.grid = construct_grid(model); 
%end;

%%%%%%%%%%%%%%% specific settings for fixed algorithm

if (model.get_rb_size(model,detailed_data)==0)  
  % generate RBstart: all initial data constellations
  RB = model.rb_init_data_basis(model, detailed_data);
  detailed_data = model.set_rb_in_detailed_data(detailed_data,RB);
%  if (get_rb_size(detailed_data)==0) % check if reduced basis is empty
%  detailed_data = model.RB_init_data_basis(model, detailed_data, ...
%                                           detailed_data.RB_info.M_train);
end;
%prepare model 
%model.Nmax = size(detailed_data.RB,2);

disp('Starting RB extension loop');

% start time measurement
tic;
start_time_basisgen_fixed = tic;

% extend basis 
detailed_data = RB_greedy_extension(model, ...
                                    detailed_data);

disp(['Generated RB basis on fixed M_train with ',...
      num2str(model.get_rb_size(model,detailed_data)), ...
      ' basis vectors.']);
t = toc(start_time_basisgen_fixed);
disp(['Runtime = ',num2str(t)]);




%| \docupdate 
