function test_err = rb_test_projection_error(model,detailed_data,reduced_data,M_test,...
                                  savepath)
%function test_err = rb_test_projection_error(model,detailed_data,reduced_data,M_test,...
%                                 savepath)
%
% function determining the test-projection-errors, i.e. L2([0,T],X)
% error for the given set of vectors `\mu`
% (columns in 'M_test') of the full simulation projected on the
% current RB space.
%
% parameters:
%   M_test: matrix with column vectors of parameter tuples `\mu` for which the
%           error between reduced and detailed simulation shall be computed.
%   savepath: directory path where the detailed simulations shall be saved to
%             with save_detailed_simulations().
%
% optional fields of model:
%
% return values:
%   test_err: vector of errors

% Bernard Haasdonk 7.9.2011

% import model specific methods

nmus = size(M_test,2);
test_err = zeros(nmus,1);

if isempty(savepath)
  error('savepath must be provided in case of error as target value!');
end;
save_detailed_simulations(model, detailed_data, M_test, savepath);
W = model.get_inner_product_matrix(detailed_data);
RB = model.get_rb_from_detailed_data(detailed_data);

parfor i = 1:nmus
  fprintf('.');
  tmodel = model;

  tmodel = tmodel.set_mu(tmodel, M_test(:,i));
%  rb_sim_data = rb_simulation(tmodel,reduced_data);
  sim_data = load_detailed_simulation(i, ...
                                      savepath,...
                                      tmodel);
  X = tmodel.get_dofs_from_sim_data(sim_data);
  Xproj_err = X- RB * ((RB' * W) * X); 
  err = sum(sum((W * Xproj_err).*Xproj_err));  
%  keyboard;
%  err = errs(end);
%  disp('warning, check monotonicity in errs!!!');
  test_err(i) = err;
%  if (i==2) & (mod(size(detailed_data.RB,2),30) == 0)
%    save(['errs',num2str(size(detailed_data.RB,2))],'errs');
%  end;
end;

disp(test_err');

