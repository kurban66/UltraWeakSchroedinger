classdef SimpleDetailedData < IDetailedData
  % a very simple detailed data implementation gathering several detailed
  % snapshots spanning the reduced basis space.
  %
  % If this IDetailedData implementation is used, a simple reduced basis
  % with snapshots from detailed simulations for directly specified
  % parameters is generated. The list of parameters is given by 'mu_list'.
  % Alternatively, the basis generation method can be customized with
  % the field 'customized_basis_generation_ptr'.

  properties
    % matrix of size 'H x N' holding the Dof vectors of the reduced basis
    % snapshot vectors spanning the reduced basis space `{\cal W}_{\text{red}}
    % \subset {\cal W}_h`
    RB;

    % a list of mu vectors for which snapshots shall be added to the
    % reduced basis space
    %
    % @default: By default only the barycenter of the parameter domain defined
    % by ModelDescr.mu_ranges is in this list.
    %
    mu_list;

    % boolean flag indicating whether a POD shall be applied to the reduced
    % basis vectors.
    do_pod = false;

    % boolean flag indicating whether the reduced basis vectors shall be
    % orthonormalized.
    do_orthonormalize = false;

    % function handle to custom basis generation algorithm, the 
    customized_basis_generation_ptr = [];

  end

  methods
    function sdd = SimpleDetailedData(rmodel, model_data)
      % function sdd = SimpleDetailedData(rmodel, model_data)
      % constructor for the SimpleDetailedData class
      %

      sdd = sdd@IDetailedData(rmodel.bg_descr, model_data);

      if ~isempty(sdd.customized_basis_generation_ptr)
        sdd.RB = sdd.customized_basis_generation_ptr(rmodel, sdd);
      else
        if isempty(sdd.mu_list)
          sdd.mu_list = {cellfun(@mean, rmodel.descr.mu_ranges, 'UniformOutput', true)};
        end

        Utot = [];
        for m = 1:length(sdd.mu_list)
          set_mu(rmodel,sdd.mu_list{m});
          sim_data = detailed_simulation(rmodel,model_data);
          if isempty(Utot)
            Utot = rmodel.get_dofs_from_sim_data(sim_data);
          else
            U = rmodel.get_dofs_from_sim_data(sim_data);
            Utot = [Utot U];
          end;
        end;

        if sdd.do_pod
          Utot = PCA_fixspace(Utot, []);
        end
        if sdd.do_orthonormalize
          A    = rmodel.descr.get_inner_product_matrix(model_data);
          Utot = orthonormalize_gram_schmidt(Utot, A);
        end
        sdd.RB      = Utot;
      end
    end

    function delete_rb(this, index)
      % function this = delete_rb(this, index)
      % removes certain reduced basis functions.
      %
      % Parameters:
      %   index:  an index vector of reduced basis functions to be removed
      this.RB = this.RB(:,setdiff(1:size(this.RB,2), index));
    end

    function siz = get_rb_size(this, dummy)
      % function siz = get_rb_size(this, dummy)
      % returns the dimension of the stored reduced basis space

      siz = size(this.RB, 2);
    end

  end

end
