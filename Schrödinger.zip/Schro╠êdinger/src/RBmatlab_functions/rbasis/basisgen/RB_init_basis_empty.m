function RBinit = RB_init_basis_empty(model,detailed_data)
%function RBinit = RB_init_basis_empty(model,detailed_data)
% 
% function generating an empty initial reduced basis.
  
% Bernard Haasdonk 11.2.2014

ndofs = size(model.get_inner_product_matrix(detailed_data),1);
RBinit = zeros(ndofs,0);

