function inspect_mu_distribution(mu_sequence,model)
%
% function plotting 2d parameter distribution and allowing
% interactive browsing over order

% B. Haasdonk 3.3.2012

ntrain = size(mu_sequence,2);
plot_mu_frequency(mu_sequence,model);

% plot figure with error decay and ruler
f1 = figure;
ax = axes('Position',[0.025,0.2,0.95,0.75]);
s = uicontrol('Parent', f1, 'Style', 'slider','String',['greedy' ...
		    ' step'],'Position',[10,10,400,40],'Tag','slider',...
	      'Callback',...
	      @(s,dummy) my_plot_mu_distribution(s,dummy,ax,mu_sequence),...
	      'Min',1,'Max',size(mu_sequence,2),...
	      'Sliderstep',[1/(ntrain-1),0.1],...
	      'Value',1);

%  plot(gca,'detailed_data.RB_info.max_err_sequence');
my_plot_mu_distribution(s,[],ax,mu_sequence);

function my_plot_mu_distribution(slider,dummy,ax,mu_sequence)
% f1: contains slider
value = round(get(slider,'Value'));
axes(ax);
cla;
ntrain = size(mu_sequence,2);
nred = 10;
oldcolor = [0.75,0.75,0.75];%[0,0,0];
greycolor = [0.75,0.75,0.75];
newcolor = [1,0.0,0.0];
if (nred<ntrain)
  plot(mu_sequence(1,1:(value-nred)),mu_sequence(2,1:(value-nred)),...
       'Marker','o','MarkerEdgeColor',...
       oldcolor,'MarkerFaceColor',greycolor, ...
       'Linestyle','none');
end;
hold on;
for i = min(nred,value):-1:1;
  w = 1-(i-1)/min(nred,value);
  plot(mu_sequence(1,value-i+1),mu_sequence(2,value-i+1),...
       'Marker','o',...
       'MarkerEdgeColor',...
       w*newcolor+(1-w)*oldcolor,...
       'MarkerFaceColor',...
       w*newcolor+(1-w)*oldcolor...
       );
end;
set(gca,'Xlim',[min(mu_sequence(1,:)), max(mu_sequence(1,:))]);
set(gca,'Ylim',[min(mu_sequence(2,:)), max(mu_sequence(2,:))]);
title(num2str(value));

