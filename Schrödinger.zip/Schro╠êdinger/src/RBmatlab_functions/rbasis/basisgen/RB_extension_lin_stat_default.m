function [RBext,dummy] = RB_extension_lin_stat_default(model, detailed_data)
%function RBext = RB_extension_lin_stat_default(model, detailed_data)
%
%
% function for basis extension in stationary cases.
% A detailed simulation is performed and the solution is orthogonalised to
% the existing basis.
%

% Markus Dihlmann 06.11.2012

dummy = [];

sim_data = detailed_simulation(model, detailed_data);
vec = model.get_dofs_from_sim_data(sim_data);

%orthonormalize
A = model.get_inner_product_matrix(detailed_data);
ovec = vec - detailed_data.RB * (detailed_data.RB'*A*vec);
%norm
n=sqrt(max(ovec'*A*ovec,0));
onvec = ovec./n;

%return orthonormal vector
RBext = onvec;

