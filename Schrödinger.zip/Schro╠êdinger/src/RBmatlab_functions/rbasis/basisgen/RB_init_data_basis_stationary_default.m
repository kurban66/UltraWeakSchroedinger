function RBinit = RB_init_data_basis_stationary_default(model,detailed_data)
%function RBinit = RB_init_data_basis_sationary_default(model,detailed_data)
%
% function taking the first entry in M_train and returning the solution to
% this parameter as initial basis.
%
% required fields of detailed_data:
%     RB_info.M_train : Training set

  
% Markus Dihlmann 06.11.2012

model = set_mu(model, detailed_data.RB_info.M_train(:,1));

sim_data = detailed_simulation(model, detailed_data);

%normalizing the vector
u = model.get_dofs_from_sim_data(sim_data);
A = model.get_inner_product_matrix(detailed_data);
n = sqrt(u'*A*u);


RBinit = u./n;