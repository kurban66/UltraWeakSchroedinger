function [enlarged, dummy] = dune_RB_extension_PCA_fixspace( model, detailed_data )
  k = 1; % we could still define how many functions should
         % be added to the space
  dummy    = [];

  enlarged = model.mexptr( 'rb_extension_PCA', model.mu, k );
end
%| \docupdate 
