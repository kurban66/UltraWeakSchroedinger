function debugdisp(msg)
% DEBUGDISP - Function that displays a message only if a global debug flag
%             is activated
%
%  msg   (string) the message to display
%
% Andreas Schmidt, 2016

if strcmp(getenv('RBMATLABDEBUG'), 'true')
    display(msg);
end

end