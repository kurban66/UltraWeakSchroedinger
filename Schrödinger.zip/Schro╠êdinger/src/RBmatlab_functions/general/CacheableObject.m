classdef CacheableObject < handle
  % class which wraps an object pointer to an object that is stored somewhere
  % on the hdd (in a cache)
  %
  % As the wrapped object is already stored somewhere, it is not stored if the
  % CacheableObject is stored. Instead only the filename and some consistency
  % hash are stored on the hdd, from which the wrapped object can be reliably
  % restored. (with a consistency check on the data)
  %

  properties
    % the file name where the wrapped object is stored
    matfile;

    % a hash computed from the cache file
    md5;

    % the pointer to the wrapped object
    obj;

    % the full path to the file where the wrapped object is stored
    matfile_path;
  end

  methods
    function co = CacheableObject(matfile, fieldname)
      % function co = CacheableObject(matfile, fieldname)
      % constructor
      %
      % At construction time, the #obj attribute is tried to be filled with the
      % obj stored in 'matfile'.
      %
      % Parameters:
      %   matfile: a string specifying the full path or only the file name of
      %            the mat-file where the object is stored.
      %   fieldname: a string specifying a fieldname that shall be passed as
      %              second argument to the load method. (@default = [])

      if nargin == 0
        matfile = evalin('base', 'matfile');
      end
      if exist(matfile, 'file') || exist([matfile, '.mat'], 'file')
        matp                  = matfile;
        [dummy, matfile, ext] = fileparts(matfile);
      else
        matp = fullfile(rbmatlabresult, matfile);
      end
      if ~exist(matp, 'file') && ~exist([matp, '.mat'], 'file')
        matp = fullfile(rbmatlabresult, '..', matfile);
        if ~exist(matp, 'file') && ~exist([matp, '.mat'], 'file')
          [st, matp] = system(['find ', fullfile(rbmatlabresult, '..', '..'), ' -iname ''', matfile, '*'' | head -1']);
          if ~exist(matp, 'file')
            error(['could not load file: ', matfile]);
          end
        end
      end
      if ~exist(matp, 'file')
        matfile = [matfile, '.mat'];
        matp    = [matp, '.mat'];
      end
      co.matfile      = matfile;
      co.matfile_path = matp;
      co.md5          = CacheableObject.compute_hash(matp);
      if nargin >= 2 && ~isempty(fieldname)
        co.obj          = load(matp, fieldname);
      else
        co.obj          = load(matp);
      end
    end


    function obj = saveobj(this)
      % function obj = saveobj(this)
      % saves all fields except for the #obj handle
      %
      % Return values:
      %   obj: struct to be stored in file
      obj.matfile_path = this.matfile_path;
      obj.matfile      = this.matfile;
      obj.md5          = this.md5;
    end

  end

  methods(Static = true)
    function this = loadobj(obj)
      % function this = loadobj(obj)
      % restores the CacheableObject object and fills the #obj handle again.
      this = CacheableObject(obj.matfile_path);

      if ~isequal(obj.md5, this.md5)
        this = [];
        error('RBMatlab:CacheableObject:Consistency', 'Consistency check failed! The stored object has changed!');
      end
    end
  end

  methods(Static=true, Access=private)
    function md5 = compute_hash(matpath)
      fid=fopen(matpath, 'r');
      md5='';
      while ~feof(fid)
        tmp=fread(fid, 1e5);
        md5 = hash([tmp; uint8(md5)'], 'md5');
      end
      fclose(fid);
    end
  end
end
