function plot_trajectories(rmodel, detailed_data, plot_params, mu_set, imsavepath, plot_name, opts)
% function plot_trajectories(rmodel, detailed_data, plot_params, mu_set, imsavepath, plot_name, opts)
% function generating a tikz graphic showing trajectories for certain selected
% parameters
%
% Parameters:
%   plot_params: a structure coming with a field 'plot' for plotting
%   mu_set:      a cell array of parameter vectors for which a trajectory shall
%                be generated.
%   imsavepath:  a string specifying the directory name, where the generated
%                files are stored.
%   plot_name:   a string naming this plot.
%   opts:        optional settings.
%
% optional fields of opts:
%   'timeinstants':   time instants to include into trajectory. Default is
%                     '[ 0, 1/3, 2/3, 1 ] * model.T'
%   'width':          width of single snapshot. Default is 5cm;
%   'subline_coord':  coordinate at which a subline plot shall be created
%   'subline_dir':    either 'x' or 'y' specifying the direction of the subline plot.
%   'sim_type':       simulation type (either 'reduced' or 'detailed')
                      @default 'reduced'

% optimize plot_params

  if ~isfield(plot_params, 'plot_type')
    plot_params.plot_type = 'patch';
  end
  if isequal(plot_params.plot_type, 'contour')
    plot_params.no_lines               = 0;
  end
  plot_params.no_axes                = 1;
  plot_params.axes_equal             = 1;
  plot_params.transparent_background = 1;
  plot_params.show_colorbar          = 0;
  if isfield(opts, 'timeinstants')
    timeinstants = opts.timeinstants;
  else
    timeinstants = [0, 1/3, 2/3, 1] * rmodel.descr.T;
  end
  if ~isfield(opts, 'field')
    opts.field = @(sim_data, model_data, t) sim_data.U(:,t);
  end

  if isfield(opts, 'sim_type')
    sim_type = opts.sim_type;
  else
    sim_type = 'reduced';
  end

  tsteps = max(1,floor(timeinstants/rmodel.descr.T .* rmodel.nt));

  if isfield(opts, 'width')
    width = opts.width;
  else
    width = 3;
  end

  if isfield(opts, 'pic_scale')
    picscale = opts.pic_scale;
  else
    picscale = 3;
  end

  if isfield(opts, 'subline_coord')
    subline = true;
  else
    subline = false;
  end

  % generate reduced_data
  reduced_data = gen_reduced_data(rmodel, detailed_data);

  % disable error estimator
  rmodel.Mstrich                = 0;
  rmodel.enable_error_estimator = 0;

  reduced_data = extract_reduced_data_subset(rmodel, reduced_data);

  if subline
    g = detailed_data.model_data.grid;
    if isequal(opts.subline_dir, 'x')
      subline = find(g.CY > opts.subline_coord ...
                   & g.CY < opts.subline_coord+g.hmin);
      subline_title = {'X'};
    elseif isequal(opts.subline_dir, 'y')
      subline = find(g.CY > opts.subline_coord ...
                   & g.CY < opts.subline_coord+g.hmin);
      subline_title = {'Y'};
    end
    subline_values = g.CX(subline)';
  end

  if ~exist(imsavepath, 'dir')
    mkdir(imsavepath);
  end

  sample_dir_name = [plot_name, '_data'];
  sample_dir_path = fullfile(imsavepath, sample_dir_name);
  if ~exist(sample_dir_path, 'dir')
    mkdir(sample_dir_path);
  end

  file       = '\\pgfplotsset{width=6cm,compat=newest};';

  xshift = width+0.2;
  yshift = -width-0.2;

  for mi=1:length(mu_set)
    set_mu(rmodel, mu_set{mi});
    set_mu(rmodel.detailed_model, mu_set{mi});
  %  newmodel.newton_epsilon = 1e-9;

    if isequal(sim_type, 'reduced')
      rb_sim_data = rb_simulation(rmodel, reduced_data);
      rb_sim_data = rb_reconstruction(rmodel, detailed_data, rb_sim_data);
    else
      rb_sim_data = detailed_simulation(rmodel.detailed_model, detailed_data.model_data);
    end

    mu = mu_set{mi};

    mustring = strrep(strrep(strrep(strrep(mat2str(mu),' ', '_'),'[',''),']',''),'.','p');

    for nt=1:length(tsteps)

      fn = [plot_name, '_mu_', mustring, '_tstep_', num2str(nt)];

      disp(['Processing ', fn, '...']);

      file = add_to_tikzfile(file, plot_name, xshift, yshift, mi, mu, fn, nt, timeinstants(nt));

      f = figure;
      set(f, 'Visible', 'off');
      U = opts.field(rb_sim_data, detailed_data.model_data, tsteps(nt));
      plot_params.plot(detailed_data.model_data.grid, U, plot_params);
      set(gca,'PlotBoxAspectRatio',[1 1 1]);

      if subline
        Uline = U(subline);
        subline_title = [ subline_title, [mustring,'_t_',num2str(nt) ] ];
        subline_values = [ subline_values; reshape(Uline, 1, length(Uline)) ];
      end

      tikzparams.filename   = fn;
      tikzparams.filepath   = sample_dir_path;
      tikzparams.relpath    = fullfile(['\', plot_name, 'TrajRelpath'], [plot_name, '_data']);
      tikzparams.width      = width;
      tikzparams.print_axes = 0;
      tikzparams.pic_scale  = picscale;
      if(nt == 1 && (mi == 1 || ~isfield(plot_params, 'clim')))
        tikzparams.save_colorbar = 1;
        cbfn = [fn,'colorbar'];
      else
        tikzparams.save_colorbar = 0;
      end

%      tclim = [0 1];
      tclim = Postprocess.plot_as_tikzfile(tikzparams);
      close(f);
      if verLessThan('matlab', '7.6.1')
        pause(2);
      end
      pause(0.5);
    end
    colorbar_xshift = nt*xshift+1;
    colorbar_yshift = (mi-1)/2*yshift;
    file = create_colorbar_file(file, plot_name, colorbar_xshift, colorbar_yshift, 0.2, width+0.2, 5, tclim, imsavepath, cbfn);
  end

  if subline
    datafn = [plot_name, 'sublines.dat'];
    f2=figure;
    plot(subline_values(1,:), subline_values(2:end,:));
    print_datatable(fullfile(imsavepath, datafn), subline_title, subline_values);
  end


  tfn = fullfile(imsavepath, [plot_name,'_illustration.tikz']);
  fid = fopen(tfn, 'w');
  fwrite(fid,file);
  fclose(fid);

  relpathcmd = ['\', plot_name, 'TrajRelpath'];
  tfntex = fullfile(imsavepath, [plot_name,'illustration_out.tex']);
  fid = fopen(tfntex, 'w');
  fprintf(fid, ['\\documentclass[a4paper,11pt]{article}\n',...
        '\\usepackage[x11names,rgb]{xcolor}\n',...
        '\\usepackage{tikz,pgfplots}\n',...
        '\\pgfplotsset{plot coordinates/math parser=false}\n',...
        '\\usepackage{amsfonts}\n',...
        '\\usepackage{amsmath}\n',...
        '\\usetikzlibrary{arrows,snakes,shapes,decorations.pathmorphing,backgrounds,fit}\n',...
        '\\usepackage[active,tightpage]{preview}\n',...
        '\\PreviewEnvironment{tikzpicture}\n',...
        '\\oddsidemargin -10mm\n',...
        '\\evensidemargin -10mm\n',...
        '\\topmargin 5mm\n',...
        '\\headheight 0mm\n',...
        '\\headsep 0mm\n',...
        '\\textheight 247mm\n',...
        '\\textwidth 160mm\n',...
        '\\begin{document}\n',...
        ' \\newcommand{%s}{./}\n', ...
        ' \\begin{tikzpicture}[scale=0.5]\n',...
        '  \\input{%s}\n',...
        ' \\end{tikzpicture}\n',...
        '\\end{document}\n'],relpathcmd, tfn);
  fclose(fid);

end

function file = create_colorbar_file(file, plot_name, xshift, yshift, cwidth, cheight, ticks, tclim, cbfp, cbfn)
  % test

  % colorbar
  sample_dir_name = [plot_name, '_data'];
  relpathcmd      = ['\', plot_name, 'TrajRelpath'];
  ytstr = '';
  for i = 1:ticks
    ytstr = [ytstr, ...
      sprintf('%.2fcm/%.1f', (cheight) * (i-1)/(ticks-1),...
      (tclim(2)-tclim(1))*(i-1)/(ticks-1) + tclim(1))];
    if i ~= ticks
      ytstr = [ytstr, ', '];
    end
  end

  cbfrel   = fullfile(relpathcmd, sample_dir_name, cbfn);
  outfrel  = fullfile(sample_dir_name, [cbfn, '.tikz']);
  outfn    = fullfile(cbfp, sample_dir_name, [cbfn, '.tikz']);

  cfid = fopen(outfn, 'w');
  fprintf(cfid, [' \\pgfdeclareimage[width=%scm,height=%scm]{colorbar}{%s}\n',...
    ' \\pgftext[at=\\pgfpoint{0}{0},left,base]{\\pgfuseimage{colorbar}};\n',...
    ' \\foreach \\y/\\ytext in {%s}\n', ...
    '  \\draw[shift={(0,\\y)}] (1pt,0pt) -- (-1pt,0pt) node[left] (coordsy) {${\\scriptscriptstyle \\ytext}$};\n'], ...
    num2str(cwidth), num2str(cheight), cbfrel, ytstr);
  fclose(cfid);

  file = [file, sprintf(['\n',...
    '\\begin{scope}[xshift=%scm,yshift=%scm]\n',...
    ' \\input{%s}\n',...
    '\\end{scope}\n']',...
    num2str(xshift), num2str(yshift), outfrel)] ;
end

function file = add_to_tikzfile(file, plot_name, xshift, yshift, mi, mu, mufn, nt, ti)

  sample_dir_name = [plot_name, '_data'];
  mufnrel   = fullfile(sample_dir_name, mufn);

  xmulabel = -0.3;
  ymulabeloff = -0.45*yshift;
  ytimelabel = -yshift+0.1;
  xtimelabeloff = 0.4*xshift;


  ymulabel = (mi-1)*yshift+ymulabeloff;
  muname   = num2str(mu(1));
  for mni=2:length(mu);
    muname = [muname, ', ', num2str(mu(mni))];
  end

  file = [file, sprintf(['\n',...
    '\\draw (%scm,%scm) node [rotate=90]',...
    '{$\\scriptstyle \\boldsymbol \\mu = (%s)$};'], ...
    num2str(xmulabel), num2str(ymulabel), muname)];

  if mi == 1
    xtimelabel = (nt-1)*xshift+xtimelabeloff;
    file = [file, sprintf(['\n',...
      '\\draw (%scm,%scm) node {$\\scriptstyle t = %.3f$};'], ...
      num2str(xtimelabel), num2str(ytimelabel), ti )];
  end

  xcoord = (nt-1) * xshift;
  ycoord = (mi-1) * yshift;

  file = [file, sprintf(['\n\n',...
    '\\begin{scope}[xshift=%scm,yshift=%scm]\n',...
    ' \\input{%s}\n'],...
    num2str(xcoord), num2str(ycoord), [mufnrel, '.tikz']),...
    '\end{scope}'];

end
