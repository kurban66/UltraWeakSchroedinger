function s = copy_field_if_exists(s,source,fieldname,defaultvalue)
%function s = copy_field_if_exists(s,source,fieldname,defaultvalue)
%
% function setting the field fieldname in the struct s. Either the
% field is copied from source if it exists, or the defaultvalue is set

% Bernard Haasdonk 19.3.2010

if isfield(source,fieldname)
  s = setfield(s,fieldname,getfield(source,fieldname));
else
  s = setfield(s,fieldname,defaultvalue);
end;