function [s1] = structcpy(s1,s2)
% function [s1] = structcpy(s1,s2)
% copies the fields of structure s2 into structure s1. If the field to be
% copied does not exist in s1 yet, a field with the appropriate name is
% created.
%

% Martin Drohmann, 01.09.2009

f2 = fieldnames(s2);
for i = 1:length(f2)
  s1.(f2{i}) = s2.(f2{i});
end

