function print_datatable(fname, title, values, blocksize)
% function print_datatable(fname, title, values, blocksize)
%
% print a matrix in a tabulator separated table stored in file 'fname'. This
% can be used by all pgfplots commandos in LaTeX.
%
% arguments:
% 'fname': file name of file where the table is stored
% 'title': vector of column titles
% 'values': matrix or 2d-cell array whose rows are written to the table
% 'blocksize': separate blocksize values with a new line in each column,
% needed for patch plots
%

if nargin < 4
  blocksize = size(values,2);
end

numblocks = size(values,2)/blocksize;

assert(numblocks-floor(numblocks)==0);

fid=fopen(fname,'w');

assert(length(title) == size(values, 1));

fpstring  = [repmat('%s\t', 1, length(title)), '\n'];
fprintf(fid, fpstring, title{:});
if iscell(values)
  fpstring2 = cellfun(@formatter, values(:,1) , 'UniformOutput', false);
  fpstring2 = [fpstring2{:}, '\n'];
else
  fpstring2 = [repmat('%e\t', 1, length(title)), '\n'];
end
for i=1:numblocks
  if iscell(values)
    fprintf(fid, fpstring2, values{:,(i-1)*blocksize+(1:blocksize)});
  else
    fprintf(fid, fpstring2, values(:,(i-1)*blocksize+(1:blocksize)));
  end
  fprintf(fid, '\n');
end

fclose(fid);

end

function ft = formatter(value)
  if isnumeric(value)
    ft = '%e\t';
  elseif ischar(value)
    ft = '%s\t';
  elseif islogical(value)
    ft = '%d\t';
  else
    error('Do not know how to print out the values in cell array...');
  end
end
