function Mstr = matrix2str(M)
%function Mstr = matrix2str(M)
%
% function generating a string (matlab format) of a given double
% matrix M

% Bernard Haasdonk 30.1.2009

fstr = [repmat('%30.18d, ',1,size(M,2)-1),'%30.18d; ...\n'];
Mstr = ['[ ',sprintf(fstr,M'), '];'];%| \docupdate 
