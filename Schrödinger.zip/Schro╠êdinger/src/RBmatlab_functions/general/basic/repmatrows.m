function rmat = repmatrows(A,times)
%
% Function stretching a matrix in first direction by 
% copying the rows

% Bernard Haasdonk 19.7.2006

rmat = reshape(repmat(A',times,1),...
	       size(A,2),size(A,1)* times)';
%| \docupdate 
