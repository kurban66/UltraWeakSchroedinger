function str = disp_deprecated(varargin)
%function str = disp_deprecated([alternative])
%
% determine name of caller and print deprecated message plus
% eventual alternative

% Bernard Haasdonk 4.9.2009

s = dbstack;
fname = s(2).name;
disp(['warning: ',fname,' deprecated!!!']);
if (length(varargin)>0)
  disp(['         ',varargin{1},' should be used instead.']);
end;
%| \docupdate 
