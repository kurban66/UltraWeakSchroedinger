function c = extend_class_from_struct(classname,s)
%function c = extend_class_from_struct(s)

% function setting fields of a class by corresponding fields of
% struct s. 
% for this, the default constructor of the string classname is
% called and then the member variables are copied. 

% B. Haasdonk 1.10.2013

eval(['c = ',classname,';']);
fs = fields(s);
for i = 1:length(fs)
  setfield(c,fs{i},getfield(s,fs{i}));
end;

