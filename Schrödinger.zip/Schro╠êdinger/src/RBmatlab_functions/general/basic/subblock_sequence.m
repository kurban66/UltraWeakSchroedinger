function subseq = subblock_sequence(seq,varargin)
%function subseq = subblock_sequence(seq,ind1[,ind2,...])
%
% For a given cell-array with matrix entries, an identically sized 
% cell-array subseq is generated, in which only the
% matrix-components ind1 x ind2 are copied, e.g. 1:N, 1:M would be
% suitable ranges to be passed in ind1, ind2.

% Bernard Haasdonk 15.5.2007

subseq = cell(size(seq));
for ci = 1:numel(seq);
  subseq{ci} = seq{ci}(varargin{:});
end;

%| \docupdate 
