function res = isequal_ignore_handles(s1,s2)
%function res = isequal_ignore_handles(s1,s2)
%
% generalization of isequal for structures with possibly
% function_handles. as isequal does not work for these,
% function_handles are skipped
%
% parameters:
%  s1: general variable to be compared
%  s2: general variable to be compared
%
% return value:
%  boolean, indicating wether the two variables are identical (while ignoring
%  function handles)

res = 0;

if ~isequal(class(s1),class(s2))
  return;
end;
  
switch class(s1)
 case 'function_handle'
  res = 1; 
  return
 case {'double'};
  % isequal does not work for nan entries!!!
  %res = isequal(s1,s2);
  i1 = find(~isnan(s1));
  i2 = find(~isnan(s2));
  res = (isequal(size(s1),size(s2))) && ...
	(isequal(i1,i2)) && isequal(s1(i1),s2(i1));
 case {'char','single','logical','rectgrid','triagrid','onedgrid'}
  res = isequal(s1,s2);
 case 'cell'
  if length(s1)~=length(s2)
    return;
  else
    res = 1;
    for i=1:length(s1)
      res = res && isequal_ignore_handles(s1{i},s2{i});
    end;
  end;
 case 'struct'
  fn1 = fieldnames(s1);
  fn2 = fieldnames(s2);
  if length(intersect(fn1,fn2))~=length(fn1)
    res = 0;
    return;
  end;
  res = 1;
  for i = 1:length(fn1)
    res = res && ...
	  isequal_ignore_handles(s1.(fn1{i}),s2.(fn1{i}));
  end;
 otherwise
  error('class type not yet supported');
end;

