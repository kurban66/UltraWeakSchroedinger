function M_array = add_to_array(M,idx,M_array_old)
%function M_array = add_to_array(M,idx,M_array_old)
%
% add M into array M_array_old at position idx
%

if (isempty(M_array_old)) || (length(M_array_old)<idx)
    M_array = M_array_old;
    M_array{idx}=M;
else
    
    M_array = [M_array_old(1:idx-1), M, M_array_old(idx:end)];
%    for i=1:idx-1
%        M_array{i} = M_array_old{i};
%    end
%    M_array{idx}=M;
%    for i=(idx+1):(length(M_array_old)+1)
%        M_array{i}=M_array_old{i-1};
%    end
    
end
    
