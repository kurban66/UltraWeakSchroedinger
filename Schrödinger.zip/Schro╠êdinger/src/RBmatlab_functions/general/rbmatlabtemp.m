function tmpstr = rbmatlabtemp
%  function tmpstr = rbmatlabtemp
%
% function returning the home environment variable at which the
% large space for data is available
  
% Bernard Haasdonk 21.7.2006
  
tmpstr = getenv('RBMATLABTEMP');

%  homestr = getenv('HOME');
 %  if isequal(homestr(1:3),'C:\')
 %    homestr = [homestr,'sync_lcars'];
 %  end;
 %  homestr = fullfile(homestr,'matlab','RBmatlab');
  
% TO BE ADJUSTED TO NEW SYNTAX
%| \docupdate 
