function res = veccomp1(v)
%function res = veccomp1(v)
%
% stupid function giving the first component of object v.
% for simplifaciton of reading of integral-kernel-functions.

% Bernard Haasdonk 12.1.2011

res = v(1);
