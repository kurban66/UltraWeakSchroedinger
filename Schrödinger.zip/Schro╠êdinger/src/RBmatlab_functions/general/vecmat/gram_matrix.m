function res = gram_matrix(X1,X2)
%function res = gram_matrix(X1,X2)
%
% function computing a gram matrix between the two vector sets X1
% and X2

% Bernard Haasdonk 28.1.2009

if nargin < 2
  X2 = X1;
end;
dim = size(X1,1);
n1 = size(X1,2);
n2 = size(X2,2);
XX1 = repmat(reshape(X1,dim,n1,1),[1,1,n2]);
XX2 = repmat(reshape(X2,dim,1,n2),[1,n1,1]);
res = reshape(sum(XX1.*XX2,1),n1,n2);
%| \docupdate 
