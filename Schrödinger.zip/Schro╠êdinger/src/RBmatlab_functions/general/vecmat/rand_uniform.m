function M = rand_uniform(N,intervals)
%function M = rand_uniform(N,intervals)
%
% function generating uniformly distributed random data in a hypercube
% N vectors are generated as columns of the matrix M, intervals is a 
% cell array indicating the borders of the intervals
%  
% example: rand_uniform(100,{[0,1],[100,1000]})
  
% Bernard Haasdonk 29.3.2007
  
  mu_dim = length(intervals);
  M = rand(mu_dim,N);
  for i=1:mu_dim
    mu_range = intervals{i};
    M(i,:) = M(i,:)*(mu_range(2)-mu_range(1))+mu_range(1);
  end;  
  
  
% TO BE ADJUSTED TO NEW SYNTAX
%| \docupdate 
