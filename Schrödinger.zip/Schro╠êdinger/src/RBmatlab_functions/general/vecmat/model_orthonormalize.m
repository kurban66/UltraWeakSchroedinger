function onvec = model_orthonormalize(model, model_data, vec,epsilon)
% function onvec = model_orthonormalize(vec[,A,epsilon])
%
% deprecated function. simply forward to Gram-Schmidt orthonormalization

% Bernard Haasdonk 13.6.2002

disp('Orthonormalize deprecated. Use orthonormalize_[qr/gram_schmidt] instead.')

if nargin < 4
  epsilon = 1e-7; % => for nonlinear evolution this value is required.
end;

onvec = model_orthonormalize_gram_schmidt(model, model_data, vec,epsilon);

