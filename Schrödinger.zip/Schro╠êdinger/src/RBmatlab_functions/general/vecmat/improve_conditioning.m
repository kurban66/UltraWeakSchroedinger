function UO = improve_conditioning(U,K);
%function UO = improve_conditioning(U,K);
%
% function performing svd of U, therefore making columns of U more
% linearly
% independent. Finally, the UO columns are scaled wrt its K-norm.
% Note that this is "normalization" wrt the K-scalarproduct, but
% NOT orthogonalization wrt K, but only orthogonalization wrt. the
% Euclidean scalar product.

% Bernard Haasdonk 28.2.2012

if (cond(U'*K*U)>1e6);
%  disp('improving conditioning!');
  
  % perform not exact orthongonalization, but 
  % conditioning improvement.
%  keyboard;
  [u,s,v] = svd(U,0);
  UO = u;
  unorminv = (sqrt(sum((K * UO).*UO,1))).^(-1);
  UO = UO * diag(unorminv(:));
%  disp(['new cond=',num2str(cond(UO'*K*UO))]);
  %% the following performs repeated qr orthogonalization
  %UO = orthonormalize_qr(U,K,eps);
  %KN = UO' * K * UO;
  %e = (max(max(abs(KN-eye(size(KN))))));
  %while e > 1e-12
  %  disp('PERFORMING REPEATED ORTHONORMALIZATION');
  %  disp('Detected orthonormalization accuracy problem.');
  %  UO = orthonormalize_qr(UO,K,2e-16);
  %  KN = UO' * K * UO;
  %  e = (max(max(abs(KN-eye(size(KN))))));
  %  %    error('error in orthonormalization, please check!');
  %end;

else
  UO = U;
end;

