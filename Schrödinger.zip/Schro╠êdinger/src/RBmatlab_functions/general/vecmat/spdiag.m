function A = spdiag(entries,n)
%function A = spdiag(entries,n)
% 
% generate sparse diagonal matrix with entries along the diagonal
A = sparse(1:n,1:n,entries,n,n);