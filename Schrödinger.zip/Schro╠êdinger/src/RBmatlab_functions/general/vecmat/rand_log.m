function M = rand_log(N,intervals)
%function M = rand_log(N,intervals)
%
% function generating logarithmically uniform distributed random
% data in a hypercube
% N vectors are generated as columns of the matrix M, intervals is a 
% cell array indicating the borders of the intervals
%  
% example: rand_log(100,{[0.01,10],[0.1,1000]})
  
% Bernard Haasdonk 4.7.2012

log_intervals = intervals;
for i = 1:length(intervals);
  log_intervals{i} = log(intervals{1});
end;
log_M = rand_uniform(N,log_intervals);
M = exp(log_M);
