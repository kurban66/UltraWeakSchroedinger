function saveasshown(fh, varargin);
%function saveasshown(fh, varargin);
%
% function saving the given figure as shown in matlab,
% i.e. overriding the printing options by current window settings.

% B. Haasdonk, 24.2.2014

set(fh,'Units','inches');
screenposition = get(fh,'Position');
set(fh,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
saveas(fh,varargin{:});