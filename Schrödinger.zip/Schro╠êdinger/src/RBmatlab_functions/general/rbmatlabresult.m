function resdirstr = rbmatlabresult
%  function resdirstr = rbmatlabresult
%
% function returning the result directory name large space for data for results
% is available
%
% Return values:
%   resdirstr:  directory name

resdirstr = getenv('RBMATLABRESULT');
