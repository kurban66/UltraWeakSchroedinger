function homestr = rbmatlabhome
%  function homestr = rbmatlabhome
%
% function returning the home environment variable pointing to the 
% RBmatlab-subdirectory 
  
% Bernard Haasdonk 21.7.2006
 
 %%%  the following call is very inefficient, i.e. 1400 calls = 4 sec!!!! 
 %homestr = [fileparts( which('startup_rbmatlab')),filesep]; 

 %%% better: environment-variable method: fraction of a second for
 %1000 calls. good.
 
 homestr = getenv('RBMATLABHOME');
 
 %  homestr = getenv('HOME');
 %  if isequal(homestr(1:3),'C:\')
 %    homestr = [homestr,'sync_lcars'];
 %  end;
 %  homestr = fullfile(homestr,'matlab','RBmatlab');
  
% TO BE ADJUSTED TO NEW SYNTAX
%| \docupdate 
