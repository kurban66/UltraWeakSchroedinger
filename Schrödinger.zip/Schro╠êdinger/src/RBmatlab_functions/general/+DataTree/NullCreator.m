classdef NullCreator < DataTree.CreatorDefault
  % Simple DataTree::ICreator copying the original tree and applying a custom function to
  % its leafs returning nothing.
  %
  % This creator is used by the INode::leaf_func() method.

  properties

    % function_handle to a custom function applied to all leaf elements
    %
    % The function synopsis is: 'funcptr(arg_node)'
    funcptr;

  end

  methods
    function sc = NullCreator(funcptr)
      % function sc = NullCreator(funcptr)
      % constructor of this creator
      %
      % Parameters:
      %   funcptr:  function handle to a custom function applied to all leaf elements
      sc.funcptr = funcptr;
    end

    function create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % function create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % @copybrief DataTree::ICreator::create_leaf_node()
      %
      % @copydetails DataTree::ICreator::create_leaf_node()
      this.funcptr(arg_node);
    end
  end
end
