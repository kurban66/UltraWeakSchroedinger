classdef ILeafNode < DataTree.INode
  % Interface for a leaf node of a data tree
  %
  % See DataTree::INode for more information on data trees::

  methods
    function children = length(dummy)
      % function children = length(dummy)
      % @copybrief DataTree::INode::length()
      %
      % Default implementation
      %
      % Return values:
      %   children: '=0'
      children = 0;
    end

    function index = get_index(dummy1, dummy2, dummy3, dummy)
      % function index = get_index(dummy1, dummy2, dummy3, dummy)
      % @copybrief DataTree::INode::get_index()
      %
      % Default implementation
      %
      % Return values:
      %   index: '=[]'
      index = [];
    end

%    function index = get_path_index(dummy1, dummy2, dummy3, dummy)
%      % function index = get_path_index(dummy1, dummy2, dummy3, dummy)
%      % @copybrief DataTree::INode::get_path_index()
%      %
%      % Default implementation
%      %
%      % Return values:
%      %    index: '=[]'
%      index = [];
%    end

    function this = set(dummy1, dummy2, value)
      % function this = set(dummy1, dummy2, value)
      % @copybrief DataTree::INode::set()
      %
      % Default implementation
      %
      % Parameters:
      %   value: object of type ::DataTree::INode which replaces the leaf node with a
      %          new data tree.
      %
      % Return values:
      %   this: reference to newly set data node
      this = value;
    end

    function data = get(this, index)
      % function data = get(this, index)
      % @copybrief DataTree::INode::get()
      %
      % Default implementation
      %
      % Parameters:
      %   index: the index needs to be empty.
      %
      % Return Values:
      %   data: returns this data leaf node
      assert( isempty(index) );
      data = this;
    end

    function node = get_active_leaf(this, model, id)
      % function node = get_active_leaf(this, model, id)
      % @copybrief DataTree::INode::get_active_leaf()
      %
      % @copydetails DataTree::INode::get_active_leaf()
      %
      % Parameters:
      %   model: of type DataTree::IModel
      %
      % Return values:
      %   node: of type ::DataTree::ILeafNode
      %
      % Required fields of model:
      %   descr: ModelDescr object speciyfing the problem discretization.

      node = this;
    end

    function tree = create_tree(this, creator, ids, mu_cube, tslice, basepath)
      % function tree = create_tree(this, creator, ids, mu_cube, tslice, basepath)
      % @copybrief DataTree::INode::create_tree()
      %
      % @copydetails DataTree::INode::create_tree()
      %
      % Default implementation: This method calls DataTree::ICreator::create_leaf_node()
      % method of the 'creator' argument.

      if nargin < 4
        mu_cube = [];
      end
      if nargin < 5
        tslice = [];
      end
      if nargin < 6
        basepath = [];
      end

      tree = create_leaf_node(creator, this, basepath, mu_cube, tslice);
    end

  end
end
