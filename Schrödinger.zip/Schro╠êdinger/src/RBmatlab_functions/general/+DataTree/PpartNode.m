classdef PpartNode < DataTree.DefaultNode
  properties
  end
end
