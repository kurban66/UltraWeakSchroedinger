classdef DummyMerger < DataTree.CreatorDefault
  % a test implementation of an DataTree::ICreator that actually merges two
  % trees together and creates new leaf elements out of the leafs of the two
  % base trees.

  properties
    % restriction to special IDs of the trees.
    idsearch = {'id1','id2'};
  end

  properties(Transient)
    % transient boolean specifying whether we are in the first (left) tree.
    in_left_tree = true;

    % a handle of type DataTree::INode holding the right tree.
    right_tree   = [];

    % last travelled node of type DataTree::LeafNode in the left tree.
    leftnode     = [];
  end

  methods

    function dmtc = DummyMerger(idsearch)
      % function dmtc = DummyMerger(idsearch)
      % constructor of this dummy test example class merging two trees.
      %
      % Paramters:
      %   idsearch:  a cell array of IDs to restrict the created trees to these
      %              IDs.
      if nargin == 1
        dmtc.idsearch = idsearch;
      end
    end

    function tree = merge(this, left_tree, right_tree)
      % function tree = merge(this, left_tree, right_tree)
      % main entry function. This merges a left and a right tree and returns
      % the merged one.
      %
      % Parameters:
      %   left_tree: left tree of type DataTree.INode
      %   right_tree: right tree of type DataTree.INode
      %
      % Return values:
      %   tree: merged tree of type DataTree.INode
      this.in_left_tree = true;
      this.right_tree = right_tree;
      tree = create_tree(left_tree, this, [], [], [], []);
    end

    function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % merges the leaf nodes
      %
      % This method expects leafs storing strings and creates new strings with
      % content '[left_string, '''' + '''', right_string]' out of it.
      %
      % @copydetails DataTree::ICreator::create_leaf_node()
      if this.in_left_tree
        this.leftnode = arg_node;
        this.in_left_tree = false;
        node = create_tree(this.right_tree,...
                           this, ...
                           this.idsearch, mu_cube, tslice,...
                           []);
        this.in_left_tree = true;

      else
        newval = [num2str(this.leftnode.value), '+', num2str(arg_node.value)];
        node = DataTree.DummyLeafNode(newval);
      end
    end
  end
end
