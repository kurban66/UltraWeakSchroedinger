classdef TpartNode < DataTree.DefaultNode
  % Data Tree element which can be filtered by time instants.
  %
  % The children branches of this data tree node are all tagged with a time
  % interval, either discrete (time steps) or continuous (time instants).
  %
  % The branches can then be accessed via the 'nt' argument of the get_index()
  % method.
  %

  properties (SetAccess = protected)
    % an object of type XPartMap holding the time intervals.
    tpart_map;
  end

  properties (Constant)
    % Data node type identifier
    data_node_type = 'TPart';
  end

  properties (Access = protected)
    % struct mapping between time instants and indices of children. (?)
    invmap;

    % an optional argument specifying whether the time slices overlap, and how
    % much they do...
    overlap     = 0;
%    refiner     = [];%DefaultRefiner;
  end

  methods
    function tpdn = TpartNode(tpart_map, initvalues, overlap)
      % function tpdn = TpartNode(tpart_map, initvalues, overlap)
      % constructor of initializing a TpartNode
      %
      % Paramters:
      %   tpart_map: the T-partitioning map of type XPartMap.
      %   initivalues: a cell array of DataTree.INode objects for the initial
      %                values of the children.
      %   overlap:     initial value for #overlap property.

      if nargin >= 3
        tpdn.overlap = overlap;
      end
      if isempty(tpart_map)
        tpart_map = XPartMap(1);
      elseif isnumeric(tpart_map)
        tpart_map = XPartMap(1, 2, tpart_map([1,end]), tpart_map');
      else
        tpart_map = copy(tpart_map);
      end
      tpdn.tpart_map   = tpart_map;
      tpdn.values      = cell(1,tpart_map.siz);

      if nargin >= 2;
        assert(length(initvalues) == length(tpdn.values))
        tpdn.values = initvalues;
      end
    end

    function tstop = index_valid_till(this, index)
      % function tstop = index_valid_till(this, index)
      % returns the last valid time instance of a given entity in the
      % #tpart_map.
      %
      % Parameters:
      %   index:  index of the T-Partitioning interval.
      %
      % Return values:
      %   tstop:  time instance when the requested time interval ends.

      if ~isempty(index)
        gid      = this.tpart_map.leaf_enum(index);
        interval = get_coords(this.tpart_map, gid);
        tstop    = interval(2);
        tstop    = min(tstop, index_valid_till(get(this, index(1)), index(2:end)));
      else
        tstop = Inf;
      end
    end

    %% interface methods

    function index    = get_index(this, id, mu, nt)
      % function index    = get_index(this, id, mu, nt)
      % @copybrief DataTree::INode::get_index()
      %
      % @copydetails DataTree::INode::get_index()
      if isempty(nt)
        index = [];
      else
        index = coords2elem(this.tpart_map, nt);

        if index == -1
          index = [];
        end
      end
    end

    function indices = get_indices_in_region(this, ids, mu_geo, tslice)
      % function indices = get_indices_in_region(this, ids, mu_geo, tslice)
      % needs to be implemented... @todo implement
    end

    function tree = create_tree(this, creator, ids, mu_cube, tslice, basepath)
      % function tree = create_tree(this, creator, ids, mu_cube, tslice, basepath)
      % @copybrief DataTree::INode::create_tree()
      %
      % @copydetails DataTree::INode::create_tree()
      %
      % Calls DataTree::Creator::create_tpart_node() to build new elements.

      if nargin < 3
        ids = [];
      end
      if nargin < 4
        mu_cube = [];
      end
      if nargin < 5
        tslice = [];
      end
      if nargin < 6
        basepath = [];
      end
      if isempty(tslice)
         tslice = [-inf; inf];
      end

      [stm, old_leaf_enum] = sub_xpart_map(this.tpart_map, tslice);

      initvalues = cell(1, length(old_leaf_enum));
      for i = 1:length(old_leaf_enum)
        % crop local tslice if necessary
        new_tslice = stm.get_coords(stm.leaf_enum(i));
        old_child  = get(this, old_leaf_enum(i));
        old_bp     = [basepath, old_leaf_enum(i)];
        initvalues{i} = create_tree(old_child, creator, ids, mu_cube, new_tslice, old_bp);
      end

      if length(old_leaf_enum) == 1
        tree = initvalues{1};
      elseif isempty(old_leaf_enum)
        throw('Merge of trees failed because given time region was not found!');
      else
        tree = create_tpart_node(creator, stm, initvalues);
      end
    end

    %% Other methods
    function refine(this, indices, midpoints)
      % function refine(this, indices, midpoints)
      % refines the T-Partitioning by refining the #tpart_map.
      %
      % Parameters:
      %   indices:  indices of partitioning intervals to be refined.
      %   midpoints: optional parameter for the refinement method
      %              XPartMap.refine() specifying how the geometries shall be
      %              split. (default = '[]')
      if nargin < 3
        midpoints = [];
      end
      [co, new] = tpart_refine(this, this.storage2lid(indices), midpoints);
      oldvalues = this.values(co);

      this.values           = [this.values(setdiff(1:length(this.values), co)),...
                               cell(1,length(new(:)))];
      this.values(new(1,:)) = oldvalues;
    end
  end
end
