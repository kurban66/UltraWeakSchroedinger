classdef DefaultNode < DataTree.INode
  % Default implementation for a DataTree.INode
  %
  % This class implements the methods get(), get_index(), set() and
  % length().

  properties
    % cell array of DataTree.INode elements, holding the childrens of this
    % DataTree.INode.
    values      = [];
  end

  methods
    function data     = get(this, index)
      % function data     = get(this, index)
      % @copybrief DataTree::INode::get()
      %
      % @copydetails DataTree::INode::get()
      if length(index) > 1
        data = get(this.values{index(1)}, index(2:end));
      elseif length(index) == 1
        data = this.values{index};
      else
        data = [];
      end
    end

    function path     = get_index(this, id, mu, nt)
      % function path     = get_index(this, id, mu, nt)
      % @copybrief DataTree::INode::get_index()
      %
      % @copydetails DataTree::INode::get_index()
      path = get_index(this, id, mu, nt);
      if ~isempty(path)
        path = [path, get_path_index(this.values{path}, id, mu, nt)];
      end
    end

    function children = length(this)
      % function children = length(this)
      % @copybrief DataTree::INode::length()
      %
      % @copydetails DataTree::INode::length()
      children = length(this.values);
    end

    function this     = set(this, index, value)
      % function this     = set(this, index, value)
      % @copybrief DataTree::INode::set()
      %
      % @copydetails DataTree::INode::set()
      if length(index) > 1
        set(this.values{index(1)}, index(2:end), value);
      elseif length(index) == 1
        this.values{index} = value;
      end
    end
  end
end
