classdef LeafDescription < DataTree.ICreator
  % DataTree.ICreator implementation which does not create a tree, but a cell
  % array of descriptions for all leafs in the tree.

  methods
    function node = create_tpart_node(this, t_part_map, initvalues)
      % function node = create_tpart_node(this, t_part_map, initvalues)
      % @copybrief DataTree::ICreator::create_tpart_node()
      %
      % @copydetails DataTree::ICreator::create_tpart_node()
      for i = 1:length(initvalues)
        tslice = get_coords(t_part_map, t_part_map.leaf_enum(i));
        bary   = barycenter(t_part_map, t_part_map.leaf_enum(i));
        for j = 1:length(initvalues{i})
          if isempty(initvalues{i}(j).tslice)
            initvalues{i}(j).tslice = tslice;
            initvalues{i}(j).t_bary = bary;
          end
        end
      end

      node = [initvalues{:}];
    end

    function node = create_idmap_node(this, id_map, initvalues)
      % function node = create_idmap_node(this, id_map, initvalues)
      % @copybrief DataTree::ICreator::create_idmap_node()
      %
      % @copydetails DataTree::ICreator::create_idmap_node()

      for i = 1:length(initvalues)
        for j = 1:length(initvalues{i})
          if isempty(initvalues{i}(j).id)
            initvalues{i}(j).id = DataTree.IdMapNode.flatten_cell_array(id_map{i});
          end
        end
      end
      node = [initvalues{:}];
    end

    function node = create_ppart_node(this, p_part_map, initvalues)
      % function node = create_ppart_node(this, p_part_map, initvalues)
      % @copybrief DataTree::ICreator::create_ppart_node()
      %
      % @copydetails DataTree::ICreator::create_ppart_node()
      for i = 1:length(initvalues)
        mu_cube = get_coords(p_part_map, p_part_map.leaf_enum(i));
        mu_bary = barycenter(p_part_map, p_part_map.leaf_enum(i));
        for j = 1:length(initvalues{i})
          if isempty(initvalues{i}(j).mu_cube)
            initvalues{i}(j).mu_cube = mu_cube;
            initvalues{i}(j).mu_bary = mu_bary;
          end
        end
      end

      node = [initvalues{:}];
    end

    function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % @copybrief DataTree::ICreator::create_leaf_node()
      %
      % @copydetails DataTree::ICreator::create_leaf_node()

      node = struct('tslice', [], 't_bary', [], 'id', [], 'mu_cube', [], 'mu_bary', [], 'basepath', basepath);

    end

  end
end
