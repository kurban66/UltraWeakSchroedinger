classdef DummyLeafNode < DataTree.ILeafNode
  % Dummy implementation for a DataTree.ILeafNode that stores a single data
  %
  % This class is used for tests and as a leaf for the DataTree.IdMapNode
  %

  properties
    % data stored in leaf node
    value;
  end

  methods
    function dln = DummyLeafNode(value)
      % function dln = DummyLeafNode(value)
      % constructor
      %
      % Parameters:
      %   value: data stored in leaf node
      dln.value = value;
    end

    function index = get_index(this, dummy, dummy2, dummy3)
      % function index = get_index(this, dummy, dummy2, dummy3)
      % @copybrief DataTree::INode::get_index()
      %
      % Return values:
      %   index: '=[]'
      index = [];
    end

    function value = get(this, index)
      % function index = get(this, index)
      % @copybrief DataTree::INode::get()
      %
      % Parameters:
      %   index: needs to be equal to '1'.
      %
      % Return values:
      %   value: the data stored with this leaf element
      assert(isscalar(index) && index==1)
      value = this.value;
    end

    function this = set_values(this, value)
      % function this = set_values(this, value)
      % sets the value of the LeafNode

      this.value = value;
    end
  end
end
