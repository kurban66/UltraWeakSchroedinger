classdef ScalarCreator < DataTree.CreatorDefault
  % Simple DataTree::ICreator copying the original tree and applying a custom function to
  % its leafs returning a scalar value.
  %
  % This creator is used by the INode::create_scalar_tree() method.


  properties

    % function_handle to a custom function applied to all leaf elements
    %
    % The function synopsis is: 'ret = funcptr(arg_node)'
    funcptr;
  end

  methods
    function sc = ScalarCreator(funcptr)
      % function sc = ScalarCreator(funcptr)
      % constructor of this creator
      %
      % Parameters:
      %   funcptr:  function handle to a custom function applied to all leaf elements
      sc.funcptr = funcptr;
    end

    function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % function node = create_leaf_node(this, arg_node, basepath, mu_cube, tslice)
      % @copybrief DataTree::ICreator::create_leaf_node()
      %
      % @copydetails DataTree::ICreator::create_leaf_node()
      svalue = this.funcptr(arg_node);
      node   = DataTree.DummyLeafNode(svalue);
    end
  end
end
