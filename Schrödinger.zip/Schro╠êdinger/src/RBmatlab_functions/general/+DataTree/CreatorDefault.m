classdef CreatorDefault < DataTree.ICreator
  % default implementation of the DataTree::ICreator interface
  %
  % This simply copies the t-partitioning, p-partitioning and ID-mapped nodes
  % of a DataTree.
  %
  % The only function left to implement is the
  % @ref DataTree::ICreator::create_leaf_node() "leaf creation" method.

  methods
    function node = create_tpart_node(this, t_part_map, initvalues)
      node = DataTree.TpartNode(t_part_map, initvalues);
    end

    function node = create_idmap_node(this, id_map, initvalues)
      node = DataTree.IdMapNode(id_map, initvalues);
    end

    function node = create_ppart_node(this, p_part_map, initvalues)
      node = DataTree.PpartNode(p_part_map, initvalues);
    end

  end
end
