classdef LUPQ_Handle < handle
    % handle for passing l-u-p-q-factors to functions
    
    properties
        % factors
        L; U; P; Q;
    end
    
    methods
        
        % constructor
        function this = LUPQ_Handle(varargin)
            if nargin == 1
                [this.L, this.U, this.P, this.Q] = lu(varargin{1});  
            elseif nargin == 4
                this.L = varargin{1};
                this.U = varargin{2};
                this.P = varargin{3};
                this.Q = varargin{4};
            end
        end
        
        % matrix multiplication
        function mat = mtimes(this, mat)
            mat = this.P' * (this.L * (this.U * (this.Q' * mat)));
        end
        
        % matrix left division
        function mat = mldivide(this, mat)
            mat = this.Q * (this.U \ (this.L \ (this.P * mat)));
        end
        
    end    
end