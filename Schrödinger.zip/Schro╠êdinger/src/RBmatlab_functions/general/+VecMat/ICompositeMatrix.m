classdef ICompositeMatrix < handle
    %classdef ICompositeMatrix
    % Handle class holding a cell array for a "composite-matrix".
    
    
    %% properties
    properties (Access = protected)
        M; % cell array storing the matrices
    end
    
    
    %% methods    
    methods (Abstract)
        % s = size(this, dim)
        % returns a characteristic size
        s = size(this, dim);
        
        % mat = getMatrix(this)
        % returns one matrix
        mat = getMatrix(this);
        
        % res = copy(this)
        % creates deep copy
        res = copy(this);
    end
    
    methods (Sealed)
        
        function res = length(this)
            % length of cell array
            res = length(this.M);
        end
        
        function this = set(this, mat, index)
            % sets one cell
            if index > length(this)
                error('ICompositeMatrix:set', 'index too large');
            end
            this.M{index} = mat;
        end
        
        function mat = get(this, index)
            % returns one cell or sub-matrix
            if max(index) > length(this)
                error('ICompositeMatrix:get', 'index too large');
            end
            if length(index) == 1
                mat = this.M{index};
            else
                mat = copy(this);
                mat.M = mat.M(index);
            end
        end
        
        function obj1 = horzcat(obj1, obj2)
            % horizontal concatenation
            if isempty(obj1)
                if isa(obj2, 'handle')
                    obj1 = copy(obj2);
                else
                    obj1 = obj2;
                end
            else
                for i = 1:obj2.length
                    obj1.M{i} = horzcat(obj1.M{i}, obj2.M{i});
                end
            end
        end
        
        function mat = ctranspose(this)
            % transposition, returns matrix
            mat = ctranspose(this.getMatrix);
        end
        
        function mat = plus(obj1, obj2)
        % matrix addition
            if isa(obj1, 'VecMat.ICompositeMatrix')
                if isa(obj2, 'VecMat.ICompositeMatrix')
                    mat = getMatrix(obj1) + getMatrix(obj2);
                else
                    mat = getMatrix(obj1) + obj2;
                end
            else
                mat = obj1 + getMatrix(obj2);
            end
        end
        
        function mat = minus(obj1, obj2)
        % matrix subtraction
            if isa(obj1, 'VecMat.ICompositeMatrix')
                if isa(obj2, 'VecMat.ICompositeMatrix')
                    mat = getMatrix(obj1) - getMatrix(obj2);
                else
                    mat = getMatrix(obj1) - obj2;
                end
            else
                mat = obj1 - getMatrix(obj2);
            end
        end
        
        function mat = mtimes(obj1, obj2)
            % multiplication with array or composite-matrix
            if isa(obj1, 'VecMat.ICompositeMatrix')
                if isa(obj2, 'VecMat.ICompositeMatrix')
                    mat = getMatrix(obj1) * getMatrix(obj2);
                else
                    mat = getMatrix(obj1) * obj2;
                end
            else
                mat = obj1 * getMatrix(obj2);
            end
        end
        
        function mat = mldivide(obj1, mat)
            % matrix division
            mat = mldivide(getMatrix(obj1), mat);
        end
        
        function varargout = subsref(this, S)
           % subscript reference to matrix
           if S.type(1) == '.'
               [varargout{1:nargout}] = builtin('subsref', this, S);
           else
               [varargout{1:nargout}] = subsref(getMatrix(this), S);
           end
        end
        
        function M = subsasgn(this, S, B)
            % return matrix
            M = subsasgn(getMatrix(this), S, B);
        end        
    end
    
end