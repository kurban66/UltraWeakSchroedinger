classdef CompositeMatrixDefault < VecMat.ICompositeMatrix
    %classdef CompositeMatrixDefault
    % For block-diagonal matrices
    
    
    %% properties
    
        
    %% methdos
    methods
        
        function obj = CompositeMatrixDefault(length)
            obj.M = cell(1, length);
        end
        
        function s = size(obj, dim)
            sizes = cellfun(@(mat)size(mat, dim), obj.M);
            s = sum(sizes);
        end
        
        function mat = getMatrix(obj)
            M = cell(1, length(obj));
            for i = 1:length(M)
                if isa(obj.M{i}, 'VecMat.ICompositeMatrix')
                    M{i} = getMatrix(obj.M{i});
                else
                    M{i} = obj.M{i};
                end
            end
            mat = blkdiag(M{:});
        end
        
        function res = copy(this)
            res = VecMat.CompositeMatrixDefault(this.length);
            for i = 1:this.length
                tmp = get(this, i);
                if isa(tmp, 'handle') && ismethod(tmp, 'copy')
                    res = set(res, copy(tmp), i);
                else
                    res = set(res, get(this, i), i);
                end
            end
        end
        
    end
    
end