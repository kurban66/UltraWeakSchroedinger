function varargout = gram_schmidt_reiterate(X, K, epsilon, n_on)
% function varargout = gram_schmidt_reiterate(X, k, epsilon, n_on)
% performs classical gram schmidt orthonormalization algorithm with
% re-orthogonalization. loss of orthogonality is a multiple of machine
% precision.
%
% Input parameter
% - X: vectors to be orthonormalized
% - K: inner product matrix
% - epsilon: norm threshold
% - n_on: if given, first n_on vectors are assumed to be already orthonormal
% Output parameter
% - varargout{1}: orthonormalized vectors
% - varargout{2}: indices of vectors included in onb

if nargin < 4
    n_on = 0;
end

Xon = X(:, 1:n_on);
ind = 1:n_on;
% storing matrix avoids multiple computation of inner products
KXon = K * Xon;

for i = (n_on + 1):size(X, 2)
    
    v = X(:, i);
    
    norm = sqrt(v' * K * v);
    
    if norm > epsilon
        
        % two orthogonalization iterations suffice
        for j = 1:2
            
            v = v - Xon * (KXon' * v);
        end
        
        w = K * v;
        norm = sqrt(v' * w);
        
        % include new vector
        if norm > epsilon
            ind = [ind, i];
            Xon = [Xon, v / norm];
            KXon = [KXon, w / norm];
        end
    end
end

varargout{1} = Xon;
varargout{2} = ind;

end
