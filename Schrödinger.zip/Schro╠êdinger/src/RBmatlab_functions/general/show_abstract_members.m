function show_abstract_members(class_name)
  % function show_abstract_members(class_name)
  % displays unimplemented abstract methods of class with name 'class_name'
  m = meta.class.fromName(class_name);

  a_props         = m.Properties(cellfun(@(x) x.Abstract, m.Properties));
  una_props       = m.Properties(cellfun(@(x) ~x.Abstract, m.Properties));
  a_props_names   = cellfun(@(x) x.Name, a_props, 'UniformOutput', false);
  una_props_names = cellfun(@(x) x.Name, una_props, 'UniformOutput', false);
  a_props_names = setdiff(a_props_names, una_props_names);

  a_methods         = m.Methods(cellfun(@(x) x.Abstract, m.Methods));
  una_methods       = m.Methods(cellfun(@(x) ~x.Abstract, m.Methods));
  a_methods_names   = cellfun(@(x) x.Name, a_methods, 'UniformOutput', false);
  una_methods_names = cellfun(@(x) x.Name, una_methods, 'UniformOutput', false);
  a_methods_names = setdiff(a_methods_names, una_methods_names);

  if ~isempty(a_props)
    disp(['Unimplemented abstract properties in ', class_name, ' are:']);
    disp(a_props_names);
  end

  if ~isempty(a_methods)
    disp(['Unimplemented abstract methods in ', class_name, ' are:']);
    disp(a_methods_names);
  end
end
