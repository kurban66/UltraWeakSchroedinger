function varargout = tictoc_wrapper(funcptr, varargin)
tic;
[varargout{1:nargout-1}] = funcptr(varargin{:});
varargout{nargout} = toc;
end
