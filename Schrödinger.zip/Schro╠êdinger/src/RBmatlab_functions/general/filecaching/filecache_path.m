function cachedir = filecache_path
%function cachedir = filecache_path
% 
% function returning the directory used for storing function-cache
% calls

% Bernard Haasdonk 22.5.2007

cachedir = fullfile(rbmatlabtemp,'cache');