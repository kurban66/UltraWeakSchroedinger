function [varargout] = cache_function(func_ptr, varargin)
%function [varargout] = cache_function(func_ptr, varargin)
% simple caching of function call
% inputs are cached too!

if isfield(varargin{end}, 'disable_caching') && varargin{end}.disable_caching
    [varargout{1:nargout}] = func_ptr(varargin{:});
    return
end

func_str = func2str(func_ptr);

cached_index = [];

if cache('exist', func_str)
    loaded = cache('load', func_str);
    for i = 1:loaded.ncached
        if isequal(loaded.inputs{i}, varargin)
            cached_index = i;
        end        
    end
end

if ~isempty(cached_index)
    varargout = loaded.outputs{cached_index};
else
    
    [varargout{1:nargout}] = func_ptr(varargin{:});
    
    if ~exist('loaded', 'var')
        loaded = struct('ncached', 0, 'inputs', [], 'outputs', []);
    end
    
    loaded.ncached = loaded.ncached + 1;
    loaded.inputs{loaded.ncached} = varargin;
    loaded.outputs{loaded.ncached} = varargout;
    cache('save', func_str, loaded);
end

end

