classdef XPartMap < handle
  % a geometric tree where every nodes has geometry information attached.
  %
  % The geometry relations are as follows:
  %  - Child node''s geometries lie in their parents geometries.
  %  - Sibling''s geometries have zero intersection.
  %  - The union of all child node''s geometries equals a parent''s geometry.
  %  - The geometries are of arbitrary dimension and can be defined by an
  %    arbitrary number of coordinates.
  %
  % The main features of this class are:
  %  - Routines to split the geometries and to create new childs are provided.
  %  - The leaf nodes can be accessed over a sorted or an unsorted index.
  %  - We can check in `{\cal O}(\log)`-time in which node''s geometry a certain
  %    coordinate lies.
  %
  % @section Implementation details
  %   The nodes store the following information: 
  %    -# a number with the ID of the first child of this node or '0'
  %       indicating a leaf node
  %    -# the 'ncoords' coordinates describing the node''s geometry.
  %
  %   So every node has a size of '1 + ncoords * dimension'.
  %
  %   We distinguish between three enumerations of nodes: 
  %    -# a "node ID" is given to every node in the tree and does not change
  %       during a refinement for nodes that are unchanged.
  %    -# a "leaf element index" is a consecutive enumeration of leaf
  %       indices which does not change for unchanged leaf nodes during a
  %       refinement
  %    -# a "sorted leaf element index" is a consecutive enumeration of leaf
  %       indices enumerating the leaf elements from left-to-right.
  %

  properties(Access=public)

    dimension       = 1;        % dimension of geometries

    ncoords         = 2;        % number of coordinates defining a geometry

    % actual tree with attached geometries
    %
    % This stores a list of pairs '(c, coords)' of the index of the first child
    % 'c' and the geometry coordinates 'coords'. If 'c' is equal to 0, the node
    % is a leaf node. The first pair is the root node of the tree.
    intervals       = [0 0 1];

    % integer specifying how many children are created at refinement step
    split_size      = 2;

    % an 'unsorted' enumeration of the leaf indices
    %
    % If a leaf has not been refined, it keeps its position in this set.
    leaf_ids        = 0;

    % a 'sorted' enumeration of the leaf indices.
    %
    % This set is constructed by a deep traversal of the tree, with
    % left-to-right enumeration of leafs.
    leaf_enum       = 0;

    % A vector which stores the refinement level for every node.
    refine_levels   = 0;

  end

  properties(Dependent)
    % the number of the leaf nodes
    siz;

    % storage size of a single tree node pair '(c, coords)'
    skip;

    % the maximum refinement level of the tree
    max_level;

    noof_ids;  % the number of node IDs in the tree
  end

  methods

    function skip = get.skip(this)
      skip = this.dimension*this.ncoords+1;
    end

    function siz = get.siz(this)
      siz = length(this.leaf_ids);
    end

    function nids = get.noof_ids(this)
      nids = length(this.intervals)/this.skip;
    end

    function mlevel =get.max_level(this)
      mlevel = max(this.refine_levels);
    end

    function copy = copy(this)
      % function copy = copy(this)
      % deep copy for an XPartMap instance
      %
      % Return values:
      %   copy: the copied object of type XPartMap

      copy = XPartMap(this.dimension);

      fns = setdiff(properties(this), {'siz', 'skip', 'max_level', 'noof_ids'});

      for i = 1:length(fns)
        copy.(fns{i}) = this.(fns{i});
      end
    end

    function tpm = XPartMap(dimension, ncoords, init_coords, level1_splits)
      % function tpm = XPartMap(dimension, ncoords, init_coords)
      % constructor creating an XPartMap with one single root node.
      %
      % Parameters:
      %   dimension:  @copybrief #dimension
      %   ncoords:  @copybrief #ncoords
      %   init_coords: initial coordinates for the root node''s geometry.
      if nargin >=1
        tpm.dimension  = dimension;
        tpm.split_size = 2^dimension;
      end
      if nargin >=2
        tpm.ncoords = ncoords;
        if tpm.ncoords > 2 && nargin == 2
          error('if ncoords > 2, init_coords need to be specified');
        end
      end
      if nargin >=3
        tpm.intervals = [0, init_coords];
      else
        icoords = zeros(1, tpm.ncoords * tpm.dimension);
        icoords(tpm.dimension+1:tpm.dimension*2) = 1;
        tpm.intervals = [0 icoords];
      end
      if nargin >=4
        if tpm.ncoords ~= 2
          error('level1 splits are only supported for ncoords == 2');
        end
        assert(size(level1_splits, 2) == tpm.dimension);
        num_splits = size(level1_splits, 1) - 1;
        tpm.intervals = [tpm.intervals, zeros(1, tpm.skip * num_splits)];
        tpm.refine_levels = [tpm.refine_levels, ones(1, num_splits)];
        tpm.leaf_enum = 1:num_splits;
        tpm.leaf_ids = 1:num_splits;
        tpm.intervals(1) = 1;
        left = level1_splits(1, :);

        for i=2:(num_splits+1)
          right = level1_splits(i, :);
          tpm.intervals((i-1) * tpm.skip + 2:i*tpm.skip) = [left, right];
          left = right;
        end

      end
    end

    function elems = coords2elem(this, tcoords)
      % function elems = coords2elem(this, tcoords)
      % returns element IDs of leaf nodes whose geometries host the given
      % coordinates.
      %
      % Parameters:
      %   tcoords: 'n x dimension' matrix of 'n' coordinate (row) vectors for
      %            which the enclosing entity ID shall be determined.
      %
      % Return values:
      %   elems: a 'n' vector holding the element IDs.

      elems = -1 * ones(1, size(tcoords,1));
      if this.dimension > 1 || size(tcoords,1) * this.max_level < this.siz

        for i = 1:size(tcoords,1)
          tc = tcoords(i,:);
          j=0;
          while true
            if this.is_inside(tc, j)
              if this.intervals(j*this.skip+1) == 0
                break
              else
                j = this.intervals(j*this.skip+1);
              end
            else
              j = j + 1;
              if j >= this.noof_ids
                j = -1;
                break;
              end
            end
          end
          elems(i) = j;
        end

      else
        [stcoords, map] = sort(tcoords);
        i = 1;
        tc = stcoords(i);
        for j = this.leaf_enum
          while this.is_inside(tc, j)
            elems(map(i)) = j;
            i = i + 1;
            if i > length(stcoords)
              return
            end
            tc = stcoords(i);
          end
        end
      end
    end

    function new_vec = split(this, iind, split_point)
      % function new_vec = split(this, iind, split_point)
      % default implementation for the splitting of one node''s geometry
      %
      % This split works as follows:
      %   - If 'split_size' is equal to '2^(dimension)', the geometry is split
      %     in each of the 'dimension' directions.
      %   - If 'split_size' is equal to '2', the geometry is split in the
      %     direction where the geometry has its widest extent.
      %
      % Parameters:
      %   iind:         the node''s ID
      %   split_point:  an optional matrix with coordinate vectors specifying
      %                 where the geometry shall be split. (default=barycenter)
      %
      % Return values:
      %   new_vec:  vector with coordinates of new geometries.

      new_vec = zeros(this.dimension, this.split_size * this.ncoords);
      coords = this.intervals(iind*this.skip+2:(iind+1)*this.skip);
      coords = reshape(coords, this.dimension, this.ncoords)';
      assert(this.ncoords == 2);
      dim = this.dimension;
      if(this.split_size == 2^this.dimension)
        for i = 1:dim
          c1 = repmat([coords(1,i),split_point(i)], 1, 2^(i-1));
          c2 = repmat([split_point(i),coords(2,i)], 1, 2^(i-1));
          new_vec(i,:) = repmat([c1, c2], 1, this.split_size/2^(i));
        end
      elseif this.split_size == 2
        direction = find(split_point < 0, 1);
        if isempty(direction)
          [m, direction]=max(coords(2,:)-coords(1,:));
          spc = split_point(direction);
        else
          spc = -split_point(direction);
        end
        c1 = coords(1,:)';
        c2 = c1;
        c2(direction) = spc;
        c4 = coords(2,:)';
        c3 = c4;
        c3(direction) = spc;
        new_vec = [c1, c2, c3, c4];
      else
        error('unsupport split_size');
      end
      new_vec = [zeros(1,this.split_size);...
                 reshape(new_vec, 2*dim, this.split_size)];
      new_vec = reshape(new_vec, 1, this.skip*this.split_size);
    end

    function [changed_ids, new_ids] = refine(this, iinds, split_points)
      % function [changed_ids, new_ids] = refine(this, iinds, split_points)
      % refines nodes given by indices at given points
      %
      % Parameters:
      %   iinds:        a vector of node IDs for elements that shall be refined.
      %   split_points: a matrix with row vectors of points are given to the
      %                 split() method as second argument. This argument is
      %                 optional.  (default = barycenter)
      %
      % Return values:
      %   changed_ids:  vector of the IDs of the nodes that were changed during
      %                 the refinement.
      %   new_ids:      vector of the IDs of the nodes that were newly created
      %                 during the refinement.
      %
      assert(nargin == 2 || length(iinds) == size(split_points,1));

      sskip = this.skip * this.split_size;

      new_vector  = zeros(1, sskip * length(iinds));
      changed_ids = zeros(1, length(iinds));
      new_ids     = zeros(1, length(iinds) * this.split_size);

      new_levels  = zeros(1, length(iinds) * this.split_size);
      new_l_ids   = zeros(1, length(iinds) * (this.split_size-1));


      offset = length(this.intervals)/this.skip-1; % node ID of first new node
      for i = 1:length(iinds)

        j=iinds(i);                            % node ID of refined element
        this.intervals(j*this.skip+1) = offset + (i-1)*this.split_size+1;

        if nargin >= 3
          split_point = split_points(i,:);
        else
          split_point = this.barycenter(j);
        end
        new_vector((i-1)*sskip+1:i*sskip) = this.split(j, split_point);

        changed_ids(i) = j;

        sprange = ((i-1)*this.split_size+1:i*this.split_size);
        new_ids(sprange) = offset + sprange;
        new_levels(sprange) = this.refine_levels(j+1) + 1;

        % update leaf_ids... do i really need it?
        this.leaf_ids(find(this.leaf_ids==j, 1)) = offset + sprange(1);
        new_l_ids((i-1)*(this.split_size-1)+1:i*(this.split_size-1)) = offset + sprange(2:end);
      end

      this.intervals     = [this.intervals, new_vector];
      this.leaf_ids      = [this.leaf_ids, new_l_ids];
      this.refine_levels = [this.refine_levels, new_levels];

      % update sorted leafindexset
      this.leaf_enum = zeros(1, length(this.leaf_ids));
      j = -1;
      for i = 1:length(this.leaf_enum)
        % traverse to next element
        while length(j) > 1 ...
                && (j(end)+1 == length(this.intervals)/this.skip ...
                    || (~this.is_inside(this.barycenter(j(end)+1), j(end-1))))
          j = j(1:end-1);
        end
        j(end) = j(end) + 1;

        fchild = this.intervals(j(end)*this.skip+1);
        while(fchild > 0)
          j = [j, fchild];
          fchild = this.intervals(j(end)*this.skip+1);
        end

        this.leaf_enum(i) = j(end);
      end
    end

    function bary = barycenter(this, iind)
      % function bary = barycenter(this, iind)
      % computes the barycenter of a node''s geometry
      %
      % Parameters:
      %   iind:    node ID of the node whose gemoetry''s barycenter shall be
      %            computed
      %
      % Return values:
      %   bary:    coordinate vector of the barycenter.
      coords = this.intervals(iind*this.skip+2:(iind+1)*this.skip);
      bary = 1/this.ncoords * sum(reshape(coords, this.dimension, this.ncoords));
      bary = bary';
    end

    function yes = intersect(this, coords, iind)
      % function yes = intersect(this, coords, iind)
      % checks whether a geometric entity intersects with another one given by
      % a node''s ID
      %
      % Parameters:
      %   coords: '2 x dimension' matrix describing the geometric entity
      %   iind: ID of other node entity
      %
      % Return values:
      %   yes: boolean flag indicating whether the intersection exists
      %

      if this.ncoords ~= 2
        error('XPartMap.intersect() is only defined for ncoords = 2');
      end

      extreme_coord = this.intervals(this.skip-this.dimension+1:this.skip);

      yes = false;
      % check whether one coordinate is inside the node''s geometry
      for i=1:size(coords,1)
        if is_inside(this, coords(1,:), iind)
          yes = true;
          break;
        end
      end
      % ... if not, they either do not intersect, or all node''s coordinate
      % lie inside the geometry defined by 'coords', so we only check for
      % the first one.
      if ~yes
        node_coords = get_coords(this, iind);
        coord = node_coords(1, :);
        if coords(2,:) == extreme_coord
          if all(coord >= coords(1,:) & coord <= coords(2,:));
            yes = true;
          end
        else
          if all(coord >= coords(1,:) & coord < coords(2,:));
            yes = true;
          end
        end
      end
    end

    function ok = is_inside(this, coord, iind)
      % function ok = is_inside(this, coord, iind)
      % checks whether a given coord lies in a node''s geometry
      %
      % Parameters:
      %   coord: the coordinate vector of length 'dimension'.
      %   iind: ID of node entity to check with
      %
      % Return values:
      %   ok: boolean flag

      if this.ncoords ~= 2
        error('XPartMap.is_inside() is only defined for ncoords = 2');
      end

      extreme_coord = this.intervals(this.skip-this.dimension+1:this.skip);
      coords = get_coords(this, iind);
      if coords(2, :) == extreme_coord
        ok = all(coord >= coords(1,:) & coord <= coords(2,:));
      else
        ok = all(coord >= coords(1,:) & coord < coords(2,:));
      end
    end

    function [sxm, old_leaf_enum] = sub_xpart_map(this, coords)
      % function sxm = sub_xpart_map(this, coords)
      % creates new object holding a subset of the current XPartMap lying in
      % the region specified by 'coords'
      %
      % Parameters:
      %   coords: a '2xdimension' matrix describing the region in which all the
      %           nodes of the resulting XPartMap shall lie.
      %
      % Return values:
      %   sxm: an object of type XPartMap holding a subset of the current map.

      root = get_coords(this, 0);
      sxm  = XPartMap(this.dimension, this.ncoords, root(:)');
      sxm.intervals = this.intervals;

      new_ids     = zeros(1:this.noof_ids);
      skipped_ids = zeros(1:this.noof_ids);
      skip      = 0;
      leaf_skip = 0;

      for i = 0:this.noof_ids-1
        if intersect(this, coords, i)
          ce = XPartMap.crop_entity(coords, get_coords(this, i));
          sxm.intervals(i*this.skip+2:(i+1)*this.skip) = ce(:);
          new_ids(i+1) = i - skip;
        else
          if sxm.intervals(i*this.skip+1) == 0
            leaf_skip = leaf_skip + 1;
          end
          sxm.intervals(i*this.skip+1) = -1;
          new_ids(i+1) = i - skip;
          skipped_ids(i+1) = 1;
          skip = skip + 1;
        end
      end

      new_intervals     = zeros(1, this.skip * (this.noof_ids - skip));
      new_refine_levels = zeros(1, this.noof_ids - skip);

      for i = 0:this.noof_ids-1
        if sxm.intervals(i*this.skip+1) >= 0
          ni       = new_ids(i+1);
          child_id = sxm.intervals(i*this.skip+1);
          new_intervals(ni*this.skip+1) = new_ids(child_id+1);
          new_intervals(ni*this.skip+2:(ni+1)*this.skip) ...
              = sxm.intervals(i*this.skip+2:(i+1)*this.skip);
          new_refine_levels(ni+1) = this.refine_levels(i+1);
        end
      end

      sxm.intervals     = new_intervals;
      sxm.refine_levels = new_refine_levels;
      sxm.leaf_ids      = new_ids(this.leaf_ids (~skipped_ids(this.leaf_ids+1))+1);
      sxm.leaf_enum     = new_ids(this.leaf_enum(~skipped_ids(this.leaf_enum+1))+1);

      % new_ids is monotone increasing, so...
      old_leaf_enum     = 1:length(this.leaf_enum);
      old_leaf_enum     = old_leaf_enum(~skipped_ids(this.leaf_enum+1));
    end

    function coords = get_coords(this, iind)
    % function coords = get_coords(this, iind)
    % helper function rearranging the vector of node coordinates into a matrix
    % with row vectors as coordinates.
    %
    % Parameters:
    %   iind: the node''s ID
    %
    % Return values:
    %   coords: the rearranged coordinates. ('ncoords x dimension' matrix)
      coords = this.intervals(iind*this.skip+2:(iind+1)*this.skip);
      coords = reshape(coords, this.dimension, this.ncoords)';
    end
  end

  methods (Static=true)

    function ce = crop_entity(coords1, coords2)
      % function ce = crop_entity(coords1, coords2)
      % helper function computing the actual intersection of two geometries
      % given by their coordinates.
      %
      % Parameters:
      %   coords1: first '2 x dimension' matrix of cube extreme point
      %            coordinates.
      %   coords2: second '2 x dimension' matrix of cube extreme point
      %            coordinates.
      %
      % Return values:
      %   ce: intersection of the two geometries given by the two arguments.

      assert(all(size(coords1) == size(coords2)));
      if size(coords1, 1) ~= 2
        error('XPartMap.crop_entity() is only defined for ncoords = 2');
      end
      ce = zeros(size(coords1));
      ce(1,:) = max(coords1(1,:), coords2(1,:));
      ce(2,:) = min(coords1(2,:), coords2(2,:));

      if any(ce(1,:) >= ce(2,:))
        ce = [];
      end
    end

  end
end
