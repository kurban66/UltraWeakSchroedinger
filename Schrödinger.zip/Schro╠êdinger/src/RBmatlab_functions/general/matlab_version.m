function res = matlab_version
%function res = matlab_version
%
% return numerical value of MATLAB version. Currently used to
% switch between ichol and cholinc. 

% B. Haasdonk 11.2.2014

v = ver('MATLAB');
res = str2num(v.Version);