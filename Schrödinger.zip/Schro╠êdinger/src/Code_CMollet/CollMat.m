% By C. Mollet
%
% Function to assemble a collocation matrix at collocation points x
% wrt B-splines given by extended knot sequence T, boundardy offset and
% order k
%
% Input:
% ------
% 'T'      : Extended knot sequence
% 'k'      : B-spline order
% 'offset' : Boundary offset
% 'x'      : Collocation points
% 'diff'   : Order of differentiation
%
% Output:
% -------
% 'A'      : Collocation matrix


function [A] = CollMat(T,k,offset,x,diff)

% Determine number of (full) B-splines/Dimension
m = length(T)-k;
n = length(x);

% Still a workaround at the very right point due to the definition
% of B-splines of half-open intervals
if x(n)==T(length(T));
    x(n)=T(length(T))-eps;
end

% Assemble matrix
A = sparse(n,m-offset(1)-offset(2));
for i=1+offset(1):m-offset(2)
    for l=1:n
        A(l,i-offset(1)) = Ndiff(T,k,diff,i,x(l));
    end
end

end