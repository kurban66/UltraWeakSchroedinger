function [real_term, imag_term] = compute_real_imag_term_spacetime(u, model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                high-fidelity solution u, struct model and struct 
%                       model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               real part and imaginary part of int_I <u_t,u> dt 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the real part and the imaginary part of
% the quantity
%       int_I <u_t(t),u(t)>_V'xV dt 
% in order to perform some experiments about the well-posedness of the 
% space-time variational formulation for the Schroedinger equation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u_temp1 = u(:,1:end-1);
u_temp2 = u(:,2:end);

adv_time = sem_compute_advection_matrix_time(model, model_data.time);

temp = 0.5*(u_temp1(:)' * kron(cell2mat(adv_time), model_data.space.inner_product_matrices.L2_mixed) * u(:) + ...
    u_temp2(:)' * kron(cell2mat(adv_time), model_data.space.inner_product_matrices.L2_mixed) * u(:));

real_term = real(temp);
imag_term = imag(temp);

end