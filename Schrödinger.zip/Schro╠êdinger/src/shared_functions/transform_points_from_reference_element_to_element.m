function [nodes] = transform_points_from_reference_element_to_element(X,h,nodesref,NEL)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Mladjan Radic, Stefan Hain
% LAST MODIFICATION:    11.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function transforms points from reference element [-1,1] to 
% an arbitrary element.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of LGL nodes
NLGL = size(nodesref,2);

% Initialize relevant quantities
nodes = zeros(NEL,NLGL); % define matrix; every row contains nodes
                         % of the m-th element


% Transform nodes of reference element on m-th element
for i = 1:NEL
    nodes(i,:) = (h/2)*nodesref + (X(i,1)+X(i,2))/2;
end

%nodes(1:NEL,:) = (h/2)*nodesref + (X(1:NEL,1)+X(1:NEL,2))/2;