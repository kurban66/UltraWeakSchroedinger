function [weightsref] = compute_lgl_weights_on_reference_element(r,P)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REFERENCE: "Applications to Fluid Dynamics" von C. Canuto, M.Y. Hussaini,
% A. Quarteroni, T.A. Zang, p. 457
%    
% Slightly changed to the original due to normalization of the
% Legendre Polynomials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if P == 0
    
    weightsref = 2;
    
else
    
    L = eval_jacobi(r,0,0,P); %* sqrt(2/(2*P+1));
    
    %-----------------------------------------------------------
    %COMPUTATION OF THE WEIGHTS ON THE REFERENCE ELEMENT
    %-----------------------------------------------------------
    % See "Spectral Methods - Evolution to Complex Geometries and
    % Applications to Fluid Dynamics" von C. Canuto, M.Y. Hussaini,
    % A. Quarteroni, T.A. Zang, p. 457
    
    % Slightly changed to the original due to normalization of the
    % Legendre Polynomials
    
    weightsref = (2*P+1)./(P*(P+1)*L.^2);
    
end