function [clpref] = eval_lagrange_on_reference_element(x_values, LGLnodes, p)

%-----------------------
%% STEP 1: INITIALIZATION
%------------------------

NLGR = size(LGLnodes,2);

num  = size(x_values,2);

if p == 0
    clpref = ones(num, 1); 
else
    
    %-----------------------------------------------------------------------
    %STEP 2: COMPUTATION OF THE CHARACTERISTIC-LAGRANGE-POLYNOMIAL OF DEGREE
    %NLGR-1
    %-----------------------------------------------------------------------
    %(see "Spectral Methods - Evolution to Complex Geometries and
    %Applications to Fluid Dynamics" von C. Canuto, M.Y. Hussaini,
    %A. Quarteroni, T.A. Zang, Seite 450)
    
    
    %--------------------------------------
    %% STEP 2.1: COMPUTATION OF THE LAMBDAS
    %--------------------------------------
    
    lambda = zeros(1,NLGR);
    
    for l = 1:NLGR
        
        dot = 1;
        
        for k = 1:NLGR
            
            if k~=l
                dot = dot*(LGLnodes(l)-LGLnodes(k));
            end
            
        end
        
        lambda(l) = 1/dot;
        
    end
    
    
    
    %---------------------------------------
    %% STEP 2.2: COMPUTATION OF THE SUMMANDS
    %---------------------------------------
    
    A = zeros(NLGR,num);
    
    for k = 1:NLGR
        
        for i = 1:num
            
            if LGLnodes(k) ~= x_values(i)
                A(k,i) = lambda(k)/(x_values(i)-LGLnodes(k)); %Computation of the summands
            end
            
        end
        
    end
    
    
    
    %----------------------------------
    %% STEP 2.3: COMPUTATION OF THE SUM
    %----------------------------------
    
    S = sum(A); %Formation of the sum
    
    
    
    %---------------------------------
    %% STEP 2.4: PUT UP THE clp-MATRIX
    %---------------------------------
    
    clpref = ones(num, NLGR);
    
    for l = 1:NLGR
        
        for i = 1:num
            
            if LGLnodes(l) ~= x_values(i)
                clpref(i,l) = (lambda(l)/(x_values(i)-LGLnodes(l)))/S(i); %Formation of the Quotient
            end
            
        end
        
    end
    
    
    for l = 1:NLGR
        
        for j = 1:NLGR
            
            for i = 1:num
                
                if (LGLnodes(j) == x_values(i) && j ~= l) %Condition psi_l(x_k) = 0 for k~=l
                    clpref(i,l) = 0;
                end
                
            end
            
        end
        
    end
    
end

%clpref = flipud(clpref);
%clpref = clpref';