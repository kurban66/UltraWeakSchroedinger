function GL = compute_nodes_on_reference_element(alpha, beta, N)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Mladjan Radic, Stefan Hain
% LAST MODIFICATION:    11.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                alpha, beta, which define Jacobi polynomials of 
%                       type (alpha, beta) and order N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Gauss-Lobatto quadrature points on reference
%                       interval [-1,1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the Gauss-Lobatto quadrature points on the
% reference element [-1,1], see also  the MATLAB function
% compute_jacobi_gauss_quadrature_points_and_weights.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if N == 0
    
    GL = [-1];

elseif N == 1 
    
    GL = [ -1 ; 1 ]; 
    
else
    
    GQ = compute_jacobi_gauss_quadrature_points_and_weights(alpha+1, beta+1 ,N-2);
    GL = [-1, GQ', 1]';
    
end