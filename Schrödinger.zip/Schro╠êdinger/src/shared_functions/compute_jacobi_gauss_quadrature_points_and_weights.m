function [GQ , weights] = compute_jacobi_gauss_quadrature_points_and_weights(alpha,beta,N)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% REFERENCE: "Calculation of Gauss Quadrature Rules" by Gene H. Golub and 
% John H. Welsch, Mathematics of Computation, Volume: 23, Number: 106, 
% Pages: 221-230+s1-s10, (1969). Note, that we have used the Jacobi 
% Polynomials!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tol = 10*eps;

if N==0 
    GQ(1)= -(alpha-beta)/(alpha+beta+2); 
    weights(1) = 2;  
else
    d = 2*(0:N)+alpha+beta;
    %d1 = 2./(d(1:N)+2).*sqrt((1:N).*((1:N)+alpha+beta).*...
    %    ((1:N)+alpha).*((1:N)+beta)./((d(1:N)+1).*(d(1:N)+3)));
    
    %Buid the matrix J as in "Calculation of Gauss Quadrature Rules"
    %J = diag( -(alpha^2-beta^2)./( (d+2).*d) ) + ...
        %diag (d1,1) + diag(d1,-1);
        
     J = diag(-1/2*(alpha^2-beta^2)./(d+2)./d) + ...
         diag(2./(d(1:N)+2).*sqrt((1:N).*((1:N)+alpha+beta).*...
         ((1:N)+alpha).*((1:N)+beta)./(d(1:N)+1)./(d(1:N)+3)),1);
    
    % Here, we have to pay attention, if alpha=beta=0,
    % with respect to the division above!
    if alpha+beta < tol
        J(1,1)=0.0;
    end
    
    J = J + J';

    [V , GQ] = eig(J);
    GQ = diag(GQ); %Extract the Eigenvalues.
    % For the sake of completeness we compute the weights:
    weights = (V(1,:)').^2*2^(alpha+beta+1)/(alpha+beta+1)*...
        gamma(alpha+1)*gamma(beta+1)/gamma(alpha+beta+1);
end