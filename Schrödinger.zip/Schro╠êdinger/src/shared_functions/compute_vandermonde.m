function V = compute_vandermonde(N,r)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REFERENCE: "Nodal Discontinuous Galerkin Methods - Algorithms, Analysis,
% and Applications", Jan S. Hesthaven and Tim Warburton, see Algorithm
% Vandermonde1D.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

V = zeros(length(r),N+1);

if N ~= 0
    for xi = 1:N+1
        V(:,xi) = eval_jacobi(r, 0, 0, xi-1);
    end
else
    V = 1;
end