function Jx = eval_jacobi(x,alpha,beta,N)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REFERENCE: "Nodal Discontinuous Galerkin Methods - Algorithms, Analysis,
% and Applications", Jan S. Hesthaven and Tim Warburton 
% 
% "Numerical Mathematics", A. Quarteroni, R. Sacco, F. Saleri
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (size(x,2)==1)
    x = x';
end

% Initial values:
gamma0 = 2^(alpha+beta+1)*gamma(alpha+1) * ...
    gamma(beta+1)/gamma(alpha+beta+1)/(alpha+beta+1);
J_0 = 1 / sqrt(gamma0);

if (N==0)
    Jx=J_0';
else
    gamma1 = (alpha+1)*(beta+1)/(alpha+beta+3)*gamma0;
    J_1 = ((alpha+beta+2)*x/2 + (alpha-beta)/2)/sqrt(gamma1);

    if (N==1)
        Jx=J_1;
        return
    else
        a_tmp = 2/(2+alpha+beta)*sqrt((alpha+1)*(beta+1)/(alpha+beta+3));
        for n=1:N-1
            h1 = 2*n+alpha+beta;
            a = 2/(h1+2)*sqrt( (n+1)*(n+1+alpha+beta)*(n+1+alpha)*...
                (n+1+beta)/((h1+1)*(h1+3)));
            b = - (alpha^2-beta^2)/(h1*(h1+2));
            Jx = 1/a*( - a_tmp * J_0 + (x-b).*J_1);
            a_tmp = a;
            J_0 = J_1;
            J_1 = Jx;
        end
    end
end