function Dr = compute_derivate_lagrange(N,r,V)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REFERENCE: "Nodal Discontinuous Galerkin Methods - Algorithms, Analysis,
% and Applications", Jan S. Hesthaven and Tim Warburton, see Algorithm
% Dmatrix1D.m in combination with GradVandermonde1D.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Vr = zeros(length(r),(N+1));

for n = 0:N
    Vr(:,n+1) = eval_derivative_jacobi(r(:),0,0,n);
end

Dr = Vr/V;

return
