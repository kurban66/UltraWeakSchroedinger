function [nodes] = transform_points_from_element_to_reference_element(X,element)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Mladjan Radic, Stefan Hain
% LAST MODIFICATION:    11.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function transforms points from an element to the reference
% element [-1,1].
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute step-size
h = element(2) - element(1);

% Compute transformed points
nodes = (2*X - (element(1)+element(2)))/h;