function dPr = eval_derivative_jacobi(r, alpha, beta, N)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REFRENCE: "Nodal Discontinuous Galerkin Methods - Algorithms, Analysis,
% and Applications", Jan S. Hesthaven and Tim Warburton, see Algorithm
% Dmatrix1D.m in combination with GradJacobiP.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dPr = zeros(length(r), 1);
if(N > 0)
  dPr = sqrt(N*(N+alpha+beta+1))*eval_jacobi(r(:),alpha+1,beta+1, N-1);
end
