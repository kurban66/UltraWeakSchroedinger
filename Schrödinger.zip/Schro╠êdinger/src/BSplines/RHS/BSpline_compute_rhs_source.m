function r_source = BSpline_compute_rhs_source(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               source of RHS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the source of the RHS.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Choose Grid Space
if model.use_exact_integration
    
    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
        
        X_space = model_data.space.grid.X_test_with_LGL_exact_integration(:);
        
    else
        
        X_space = model_data.space.grid.X_trial_with_LGL_exact_integration(:);
        
    end
    
elseif model_data.space.df_info.nnodes_trial >= model_data.space.df_info.nnodes_test
    
    X_space = model_data.space.grid.X_trial_with_LGL(:);
    
elseif model_data.space.df_info.nnodes_trial < model_data.space.df_info.nnodes_test
    
    X_space = model_data.space.grid.X_test_with_LGL(:);
    
end

%% Choose Grid Time
if model.instationary
    
    if model.use_exact_integration
        
        if model_data.time.grid.nelements_trial <= model_data.time.grid.nelements_test
            
            X_time = model_data.time.grid.X_test_with_LGL_exact_integration(:);
            
        else
            
            X_time = model_data.time.grid.X_trial_with_LGL_exact_integration(:);
            
        end
        
    elseif model_data.time.df_info.nnodes_trial >= model_data.time.df_info.nnodes_test
        
        X_time = model_data.time.grid.X_trial_with_LGL(:);
        
    elseif model_data.time.df_info.nnodes_trial < model_data.time.df_info.nnodes_test
        
        X_time = model_data.time.grid.X_test_with_LGL(:);
        
    end
    
end


%% Choose Grid
if model.instationary
    X = cell(1,2);
    
    X{1} = X_time;
    X{2} = X_space;
else
    X = cell(1,1);
    
    X{1} = X_space;
end


%% Compute Source
if model.has_source
    
    p_space = model.pdeg_space_test;
    p_time  = model.pdeg_time_test;
    
    coeff = model.source(X(:), model);
    
    if model.decomp_mode == 0
        coeff = {coeff};
    end
    
    Q_b_source = size(coeff,2);
    r_source   = cell(Q_b_source,1);
    
    for q = 1:Q_b_source
        
        if model.instationary == 1
            r_source{q} = zeros(model_data.space.df_info.nnodes_test,model_data.time.df_info.nnodes_test);
        else
            r_source{q} = zeros(model_data.space.df_info.nnodes_test,1);
        end
        
        for el_time = 1:model_data.time.grid.nelements_test
            
            for el_space = 1:model_data.space.grid.nelements_test
                
                if p_space ~= 0
                    ind_space = model_data.space.df_info.elements_glob_test{el_space};
                else
                    ind_space = el_space;
                end
                
                if p_time ~= 0
                    ind_time = model_data.time.df_info.elements_glob_test{el_time};
                else
                    ind_time = el_time;
                end
                
                h_el_space = model_data.space.grid.stepsize_per_element_test;
                h_el_time  = model_data.time.grid.stepsize_per_element_test;
                
                f = coeff{q};
                
                % Aufstellen Source-Vektor (Schroedinger-Gleichung ist homogen. Daher keine Unterscheidung, ob Quadratur-Formel bzw. Trial oder Test genauer ist)
                if model.use_exact_integration
                    
                    f     = f(model_data.time.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_time}, model_data.space.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_space});
                    [n,m] = size(f);
                    
                    temp1 = model_data.time.df_info.LGL_weights_on_reference_element' * ones(1, m);
                    temp2 = model_data.space.df_info.LGL_weights_on_reference_element' * ones(1, n);
                    
                    temp3 = (temp1.* f) .* temp2';
                    
                    if p_space ~= 0 && p_time ~= 0
                        
                        lagrange_values_time  = eval_lagrange_on_reference_element(model_data.time.df_info.LGL_nodes_on_reference_element_exact_integration, model_data.time.df_info.LGL_nodes_on_reference_element_test, p_time);                        
                        lagrange_values_space = eval_lagrange_on_reference_element(model_data.space.df_info.LGL_nodes_on_reference_element_exact_integration, model_data.space.df_info.LGL_nodes_on_reference_element_test, p_space);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (lagrange_values_time' * temp3 * lagrange_values_space)';
                        
                    elseif p_space ~= 0 && p_time == 0
                        
                        lagrange_values_space = eval_lagrange_on_reference_element(model_data.space.df_info.LGL_nodes_on_reference_element_exact_integration, model_data.space.df_info.LGL_nodes_on_reference_element_test, p_space);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (ones(1,length(model_data.time.df_info.LGL_weights_on_reference_element)) * temp3 * lagrange_values_space)';
                        
                    elseif p_space == 0 && p_time ~= 0
                        
                        lagrange_values_time = eval_lagrange_on_reference_element(model_data.time.df_info.LGL_nodes_on_reference_element_test_exact_integration, model_data.time.df_info.LGL_nodes_on_reference_element_test, p_time);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (lagrange_values_time' * temp3 * ones(length(model_data.space.df_info.LGL_weights_on_reference_element),1))';
                        
                    else
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (ones(1,length(model_data.time.df_info.LGL_weights_on_reference_element)) * temp3 * ...
                            ones(length(model_data.space.df_info.LGL_weights_on_reference_element),1))';
                        
                    end
                    
                else
                    
                    f     = f(model_data.time.df_info.ind_of_LGL_nodes_on_element_test{el_time}, model_data.space.df_info.ind_of_LGL_nodes_on_element_test{el_space});
                    [n,m] = size(f);
                    
                    temp1 = model_data.time.df_info.LGL_weights_on_reference_element' * ones(1, m);
                    temp2 = model_data.space.df_info.LGL_weights_on_reference_element' * ones(1, n);
                    
                    temp3 = (temp1.* f) .* temp2';
                    
                    if p_space ~= 0 && p_time ~= 0
                        
                        lagrange_values_time  = eval_lagrange_on_reference_element(model_data.time.df_info.LGL_nodes_on_reference_element_test, model_data.time.df_info.LGL_nodes_on_reference_element_test, p_time);
                        lagrange_values_space = eval_lagrange_on_reference_element(model_data.space.df_info.LGL_nodes_on_reference_element_test, model_data.space.df_info.LGL_nodes_on_reference_element_test, p_space);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (lagrange_values_time' * temp3 * lagrange_values_space)';
                        
                    elseif p_space ~= 0 && p_time == 0
                        
                        lagrange_values_space = eval_lagrange_on_reference_element(model_data.space.df_info.LGL_nodes_on_reference_element_test, model_data.space.df_info.LGL_nodes_on_reference_element_test, p_space);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (ones(1,length(model_data.time.df_info.LGL_weights_on_reference_element)) * temp3 * lagrange_values_space)';
                        
                    elseif p_space == 0 && p_time ~= 0
                        
                        lagrange_values_time = eval_lagrange_on_reference_element(model_data.time.df_info.LGL_nodes_on_reference_element_test, model_data.time.df_info.LGL_nodes_on_reference_element_test, p_time);
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (lagrange_values_time' * temp3 * ones(length(model_data.space.df_info.LGL_weights_on_reference_element),1))';
                        
                    else
                        
                        r_source{q}(ind_space,ind_time) = r_source{q}(ind_space, ind_time) + ((h_el_space*h_el_time)/4) * ...
                            (ones(1,length(model_data.time.df_info.LGL_weights_on_reference_element)) * temp3 * ...
                            ones(length(model_data.space.df_info.LGL_weights_on_reference_element),1))';
                        
                    end
                    
                end
                
            end
            
        end
        
        
        if model.has_dirichlet_values_space && ~isempty(model_data.space.df_info.dirichlet_ind_test)
            dir_info_test = model_data.space.df_info.dirichlet_ind_test;
            r_source{q}(dir_info_test(:,1),:) = [];
        end
        
        if model.instationary
            
            if model.has_dirichlet_values_time && ~isempty(model_data.time.df_info.dirichlet_ind_test)
                dir_info_test = model_data.time.df_info.dirichlet_ind_test;
                r_source{q}(:,dir_info_test(:,1)) = [];
            end
            
        end
        
    end
    
end