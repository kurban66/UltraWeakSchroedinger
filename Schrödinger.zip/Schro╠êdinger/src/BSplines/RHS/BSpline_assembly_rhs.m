function [r] = BSpline_assembly_rhs(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               RHS of high-fidelity formulation  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function generates the RHS of the high-fidelity formulation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialization
r_source   = [];
r_dir_time = []; 


%% Assemble Source
if model.has_source
    
    if model.use_SEM
    
        r_source = sem_compute_rhs_source(model, model_data);
        
    elseif model.use_BSplines
        
        r_source = BSpline_compute_rhs_source(model, model_data);
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end


%% Assemble Dirichlet for Time
if model.instationary
    
    if model.use_SEM
        
        if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))

            r_dir_homogenization_time = sparse(0);

            rr_dir_homogenization_time = sem_compute_rhs_dir_homogenization_time(model, model_data);
            
            for i = 1:size(rr_dir_homogenization_time,2)
                r_dir_homogenization_time = r_dir_homogenization_time + rr_dir_homogenization_time{i};
            end
            
            r_source = cell2mat(r_source) - r_dir_homogenization_time;
            
        else
    
            r_dir_time = sem_compute_rhs_dir_time(model, model_data.space);
            
        end
        
    elseif model.use_BSplines
        
        if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))

            r_dir_homogenization_time = sparse(0);

            rr_dir_homogenization_time = BSpline_compute_rhs_dir_homogenization_time(model, model_data);
            
            for i = 1:size(rr_dir_homogenization_time,2)
                r_dir_homogenization_time = r_dir_homogenization_time + rr_dir_homogenization_time{i};
            end
            
            r_source = cell2mat(r_source) - r_dir_homogenization_time;
            
        else
    
            r_dir_time = BSpline_compute_rhs_dir_time(model, model_data.space);
            
        end
        
    elseif model.use_dgSEM
        
        error('Not implemented yet!')
        
    end
    
end
    

%%
if ~model.compute_adjoint_problem
    r = [r_source; r_dir_time];
else
    r = [r_dir_time; r_source];
end

