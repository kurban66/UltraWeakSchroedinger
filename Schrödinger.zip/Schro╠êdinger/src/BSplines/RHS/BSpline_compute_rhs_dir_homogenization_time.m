function r_dir_time = BSpline_compute_rhs_dir_homogenization_time(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               RHS of high-fidelity formulation for homogenized
%                       Dirichlet boundary conditions in time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function generates the RHS of the high-fidelity formulation 
% for homogenized Dirichlet boundary conditions in time.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialization
Q_a_diff  = 0;
Q_a_adv   = 0;
Q_a_reac  = 0;
Q_a_robin = 0;


%% Choose Grid
if model.use_exact_integration
    
    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
        X_space = model_data.space.grid.X_test_with_LGL_exact_integration(:);
    else
        X_space = model_data.space.grid.X_trial_with_LGL_exact_integration(:);
    end
    
    if model_data.time.grid.nelements_trial <= model_data.time.grid.nelements_test
        X_time = model_data.time.grid.X_test_with_LGL_exact_integration(:);
    else
        X_time = model_data.time.grid.X_trial_with_LGL_exact_integration(:);
    end
    
elseif model_data.space.df_info.nnodes_trial >= model_data.space.df_info.nnodes_test
    
    X_space = model_data.space.grid.X_trial_with_LGL(:);
    
    X_time = model_data.time.grid.X_trial_with_LGL(:);
    
elseif model_data.space.df_info.nnodes_trial < model_data.space.df_info.nnodes_test
    
    X_space = model_data.space.grid.X_test_with_LGL(:);
    
    X_time = model_data.time.grid.X_test_with_LGL(:);
    
end

X = {X_time, X_space};


%% Compute Initial-Value-Time
r_dir_diff = {};
r_dir_adv  = {};
r_dir_reac = {};

p_trial_space = model.pdeg_space_trial;
p_test_space  = model.pdeg_space_test;

if model.decomp_mode == 1
    Q_b_dir = size(model.dirichlet_time([],model),2);
else
    Q_b_dir = 1;
end

if model.has_diffusivity_space
    if model.decomp_mode == 1
        Q_a_diff = size(model.diffusivity_space([],model),2);
    else
        Q_a_diff = 1;
    end
end

if model.has_advection_space
    if model.decomp_mode == 1
        Q_a_adv = size(model.advection_space([],model),2);
    else
        Q_a_adv = 1;
    end
end

if model.has_reaction_space
    if model.decomp_mode == 1
        Q_a_reac = size(model.reaction_space([],model),2);
    else
        Q_a_reac = 1;
    end
end

if model.has_robin_values_space
    if model.decomp_mode == 1
        Q_a_robin = size(model.robin_beta_space([],model),2);
    else
        Q_a_robin = 1;
    end
end

Q_a = Q_a_diff + Q_a_adv + Q_a_reac + Q_a_robin;


%------------------------------------------------------------------
% Diffusion
%------------------------------------------------------------------
if model.has_diffusivity_space
    
    r_dir_diff = cell(Q_a_diff, Q_b_dir);
    
    Adiff      = cell(Q_a_diff,1);
    
    acoeff     = model.diffusivity_space(X{2}(:),model);
    
    for qmuh = 1:Q_b_dir
        
        for q = 1:Q_a_diff
            
            r_dir_diff{q,qmuh} = zeros(model_data.space.df_info.nnodes_test, model_data.time.df_info.nnodes_test);
            
            Adiff{q} = sparse(model_data.space.df_info.nnodes_test, 1);
            
            uD       = model.dirichlet_time(X{2}(:), model);
            
            if model.decomp_mode == 1
                uD     = uD{qmuh};
                acoeff = acoeff{q};
            end
            
            for el_coarse = 1:model_data.space.grid.elements_coarse
                
                for el_fine = ((el_coarse - 1)*model_data.space.grid.ratio + 1):(el_coarse*model_data.space.grid.ratio)
                    
                    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test      = model_data.space.df_info.elements_glob_test{el_fine};
                        
                        h_el          = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test      = model_data.space.df_info.elements_glob_test{el_fine};
                        
                        h_el          = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test      = el_fine;
                        
                        h_el          = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test      = el_fine;
                        
                        h_el          = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test      = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                        h_el          = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test      = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                        h_el          = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test      = el_coarse;
                        
                        h_el          = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test      = el_coarse;
                        
                        h_el          = model_data.space.grid.stepsize_per_element_trial;
                        
                    end
                    
                    
                    if model.use_exact_integration
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_fine};
                        end
                    else
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test{el_fine};
                        end
                    end
                    
                    
                    % Matrixblock in Diffusionsmatrix, �berschneidungen werden addiert
                    if model.ultraweak_formulation
                        
                        if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
                            
                            if size(model_data.space.df_info.LGL_DiffMatrix_test,2) == 1
                                
                                if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_LeftBound_test{el_coarse, 1};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                                else
                                    Matrix_test = cell2mat(model_data.space.df_info.LGL_HessianMatrix_test);
                                end
                                
                            else
                                
                                if p_trial_space >= 2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_LeftBound_test{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_test{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                            end
                            
                        else
                            
                            if size(model_data.space.df_info.LGL_DiffMatrix_trial,2) == 1
                                
                                if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse,1};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse,1};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1,1};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1,1};
                                else
                                    Matrix_trial = cell2mat(model_data.space.df_infolagrange_values_on_reference_element_trial);
                                    BSpline_values = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_trial);
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_test{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                            else
                                
                                if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_test = model_data.space.df_info.LGL_HessianMatrix_test{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                            end
                            
                        end
                        
                        Adiff{q}(ind_test, 1) = Adiff{q}(ind_test, 1) + (2/h_el) * ...
                            ((diag(conj(acoeff(ind_of_LGL_nodes)) .* model_data.space.df_info.LGL_weights_on_reference_element') * ...
                            Matrix_trial)' * Matrix_test)' * (BSpline_values \ uD(ind_of_LGL_nodes));
                        
                    else
                        
                        if p_trial_space ~= 0 && p_test_space ~= 0
                            
                            if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
                                
                                if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, 1};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_DiffMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                                else
                                    Matrix_test = cell2mat(model_data.space.df_info.LGL_DiffMatrix_test);
                                end
                                
                            else
                                
                                if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                    Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_LeftBound_trial{el_coarse,1};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse,1};
                                elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                    Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1,1};
                                    BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1,1};
                                else
                                    Matrix_trial = cell2mat(model_data.space.df_info.LGL_DiffMatrix_trial);
                                    BSpline_values = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_trial);
                                end
                                
                                if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                    Matrix_test = model_data.space.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                    Matrix_test = model_data.space.df_info.LGL_DiffMatrix_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                else
                                    Matrix_test = model_data.space.df_info.LGL_DiffMatrix_test{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                end
                                
                            end
                            
                        end
                        
                        Adiff{q}(ind_test, 1) = Adiff{q}(ind_test, 1) + (2/h_el) * ...
                            ((diag(acoeff(ind_of_LGL_nodes) .* model_data.space.df_info.LGL_weights_on_reference_element') * ...
                            Matrix_trial)' * Matrix_test)' * (BSpline_values \ uD(ind_of_LGL_nodes));
                        
                    end
                    
                end
                
            end
            
            if model.has_dirichlet_values_space && ~isempty(model_data.space.df_info.dirichlet_ind_trial)
                dir_info_trial = model_data.space.df_info.dirichlet_ind_trial;
                Adiff{q}(dir_info_trial(:,1)) = [];
            end
            
            if model.has_reaction_time == 0
                r_dir_diff{q,qmuh} = Adiff{q} * ones(1,model_data.time.df_info.nnodes_trial) * model_data.time.inner_product_matrices.L2_mixed_with_Dirichlet';
            else
                L2_reaction_time   = BSpline_compute_reaction_matrix_time(model, model_data.time);
                r_dir_diff{q,qmuh} = Adiff{q} * ones(1,model_data.time.df_info.nnodes_trial) * L2_reaction_time{1}';
            end
            
            if model.has_dirichlet_values_time && ~isempty(model_data.time.df_info.dirichlet_ind_test)
                dir_info_test = model_data.time.df_info.dirichlet_ind_test;
                r_dir_diff{q,qmuh}(:,dir_info_test(:,1)) = [];
            end
            
        end
        
    end
    
    r_dir_diff = {r_dir_diff{:}};
    
end


%------------------------------------------------------------------
% Advection
%------------------------------------------------------------------
if model.has_advection_space
    
    r_dir_adv = cell(Q_a_adv, Q_b_dir);
    
    Aadv      = cell(Q_a_adv,1);
    
    bcoeff    = model.advection_space(X{2}(:),model);
    
    for qmuh = 1:Q_b_dir
        
        for q = 1:Q_a_adv
            
            r_dir_adv{q,qmuh} = zeros(model_data.space.df_info.nnodes_test, model_data.time.df_info.nnodes_test);
            
            Aadv{q} = sparse(model_data.space.df_info.nnodes_test, 1);
            
            uD      = model.dirichlet_time(X{2}(:), model);
            
            if model.decomp_mode == 1
                uD     = uD{qmuh};
                bcoeff = bcoeff{q};
            end
            
            for el_coarse = 1:model_data.space.grid.elements_coarse
                
                for el_fine = ((el_coarse - 1)*model_data.space.grid.ratio + 1):(el_coarse*model_data.space.grid.ratio)
                    
                    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_fine};
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_fine};
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test  = el_fine;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test  = el_fine;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test  = el_coarse;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test  = el_coarse;
                        
                    end
                    
                    if model.use_exact_integration
                        
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_fine};
                        end
                        
                    else
                        
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test{el_fine};
                        end
                        
                    end
                    
                    if p_trial_space ~= 0
                        
                        if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
                            
                            if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            else
                                Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                                BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            end
                            
                            if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_test{el_coarse, 1};
                            elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                            else
                                Matrix_test = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_test);
                            end
                            
                        else
                            
                            if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                                Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_LeftBound_trial{el_coarse, 1};
                                BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, 1};
                            elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                                Matrix_trial = model_data.space.df_info.LGL_DiffMatrix_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                                BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                            else
                                Matrix_trial = cell2mat(model_data.space.df_info.LGL_DiffMatrix_trial);
                                BSpline_values = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_trial);
                            end
                            
                            if p_test_space >= 2 && el_coarse <= p_test_space - 1
                                Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                                Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            else
                                Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_test{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            end
                            
                        end
                        
                    end
                    
                    Aadv{q}(ind_test, 1) = Aadv{q}(ind_test, 1) + ...
                        (1/model_data.space.grid.ratio) * ((diag(bcoeff(ind_of_LGL_nodes) .* model_data.space.df_info.LGL_weights_on_reference_element') * ...
                        Matrix_trial)' * Matrix_test)' * (BSpline_values \ uD(ind_of_LGL_nodes));
                    
                end
                
            end
            
            if model.has_dirichlet_values_space && ~isempty(model_data.space.df_info.dirichlet_ind_trial)
                dir_info_trial = model_data.space.df_info.dirichlet_ind_trial;
                Aadv{q}(dir_info_trial(:,1)) = [];
            end
            
            if model.has_reaction_time == 0
                r_dir_adv{q,qmuh} = Aadv{q} * ones(1,model_data.time.df_info.nnodes_trial) * model_data.time.inner_product_matrices.L2_mixed_with_Dirichlet';
            else
                L2_reaction_time   = BSpline_compute_reaction_matrix_time(model, model_data.time);
                r_dir_adv{q,qmuh} = Adiff{q} * ones(1,model_data.time.df_info.nnodes_trial) * L2_reaction_time{1}';
            end
            
            if model.has_dirichlet_values_time && ~isempty(model_data.time.df_info.dirichlet_ind_test)
                dir_info_test = model_data.time.df_info.dirichlet_ind_test;
                r_dir_adv{q,qmuh}(:,dir_info_test(:,1)) = [];
            end
            
        end
        
    end
    
    r_dir_adv = {r_dir_adv{:}};
    
end


%------------------------------------------------------------------
% Reaction
%------------------------------------------------------------------
if model.has_reaction_space
    
    r_dir_reac = cell(Q_a_reac, Q_b_dir);
    
    Areac      = cell(Q_a_reac,1);
    
    ccoeff     = model.reaction_space(X{2}(:), model);
    
    for qmuh = 1:Q_b_dir
        
        for q = q:Q_a_reac
            
            r_dir_reac{q,qmuh} = zeros(model_data.space.df_info.nnodes_test, model_data.time.df_info.nnodes_test);
            
            Areac{q} = sparse(model_data.space.df_info.nnodes_test, 1);
            
            uD       = model.dirichlet_time(X{2}(:), model);
            
            if model.decomp_mode == 1
                uD     = uD{qmuh};
                ccoeff = {ccoeff};
            end
            
            for el_coarse = 1:model_data.space.grid.elements_coarse
                
                for el_fine = ((el_coarse - 1)*model_data.space.grid.ratio + 1):(el_coarse*model_data.space.grid.ratio)
                    
                    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_fine};
                        
                        h_el      = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_fine};
                        
                        h_el      = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test  = el_fine;
                        
                        h_el      = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test  = el_fine;
                        
                        h_el      = model_data.space.grid.stepsize_per_element_test;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                        h_el      = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space ~= 0
                        
                        ind_test  = model_data.space.df_info.elements_glob_test{el_coarse};
                        
                        h_el      = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space ~= 0 && p_test_space == 0
                        
                        ind_test  = el_coarse;
                        
                        h_el      = model_data.space.grid.stepsize_per_element_trial;
                        
                    elseif model_data.space.grid.nelements_trial > model_data.space.grid.nelements_test && p_trial_space == 0 && p_test_space == 0
                        
                        ind_test  = el_coarse;
                        
                        h_el      = model_data.space.grid.stepsize_per_element_trial;
                        
                    end
                    
                    if model.use_exact_integration
                        
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_fine};
                        end
                        
                    else
                        
                        if model_data.space.grid.nelements_trial >= model_data.space.grid.nelements_test
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_trial{el_fine};
                        else
                            ind_of_LGL_nodes = model_data.space.df_info.ind_of_LGL_nodes_on_element_test{el_fine};
                        end
                        
                    end
                    
                    
                    if model_data.space.grid.nelements_trial <= model_data.space.grid.nelements_test
                        
                        if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                            Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            
                        elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                            Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                        else
                            Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                            BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                        end
                        
                        if p_test_space >= 2 && el_coarse <= p_test_space - 1
                            Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_test{el_coarse, 1};
                        elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                            Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                        else
                            Matrix_test = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_test);
                        end
                        
                    else
                        
                        if p_trial_space >=2 && el_coarse <= p_trial_space - 1
                            Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, 1};
                            BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, 1};
                        elseif p_trial_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_trial_space + 2
                            Matrix_trial = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                            BSpline_values = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.space.grid.elements_coarse - el_coarse + 1, 1};
                        else
                            Matrix_trial = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_trial);
                            BSpline_values = cell2mat(model_data.space.df_info.lagrange_values_on_reference_element_trial);
                        end
                        
                        if p_test_space >= 2 && el_coarse <= p_test_space - 1
                            Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                        elseif p_test_space >= 2 && el_coarse >= model_data.space.grid.elements_coarse - p_test_space + 2
                            Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_RightBound_test{model_data.space.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                        else
                            Matrix_test = model_data.space.df_info.lagrange_values_on_reference_element_test{mod(mod(el_fine,model_data.space.grid.ratio+1)+el_coarse-1,model_data.space.grid.ratio+1)};
                        end
                        
                    end
                    
                    Areac{q}(ind_test,1) = Areac{q}(ind_test,1) + (h_el/2) * ...
                        ((diag(ccoeff(ind_of_LGL_nodes).* model_data.space.df_info.LGL_weights_on_reference_element') * ...
                        Matrix_trial)' * Matrix_test)' * (BSpline_values \ uD(ind_of_LGL_nodes));
                    
                end
                
            end
            
            if model.has_dirichlet_values_space && ~isempty(model_data.space.df_info.dirichlet_ind_trial)
                dir_info_trial = model_data.space.df_info.dirichlet_ind_trial;
                Areac{q}(dir_info_trial(:,1)) = [];
            end
            
            if model.has_reaction_time == 0
                r_dir_reac{q,qmuh} = Areac{q} * ones(1,model_data.time.df_info.nnodes_trial) * model_data.time.inner_product_matrices.L2_mixed_with_Dirichlet';
            else
                L2_reaction_time   = BSpline_compute_reaction_matrix_time(model, model_data.time);
                r_dir_reac{q,qmuh} = Adiff{q} * ones(1,model_data.time.df_info.nnodes_trial) * L2_reaction_time{1}';
            end
            
            if model.has_dirichlet_values_time && ~isempty(model_data.time.df_info.dirichlet_ind_test)
                dir_info_test = model_data.time.df_info.dirichlet_ind_test;
                r_dir_reac{q,qmuh}(:,dir_info_test(:,1)) = [];
            end
            
        end
        
    end
    
    r_dir_reac = {r_dir_reac{:}};
    
end

%------------------------------------------------------------------

r_dir_time = [r_dir_diff , r_dir_adv , r_dir_reac];

%------------------------------------------------------------------