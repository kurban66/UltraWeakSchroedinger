function model_data = BSpline_gen_model_data(model) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               struct model_data 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB functions generates the struct model_data, which contains
% informations about the 1D BSpline grid and informations about the BSpline
% discretization as well as inner-product matrices. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

model_data = [];

model_data.space = [];

if model.instationary 
    model_data.time = [];
end

%% Construct 1D-Grid for Space and if necessary Time
[model_data.space.grid, model_data.time.grid] = BSpline_construct_grid(model);

%% Generate Discrete Function Info 
[model_data.space.df_info, model_data.time.df_info] = construct_BSplineinfo(model, model_data);

%% Compute L2-Inner-Prduct-Matrix for Space and if necessary Time
model_data.space.inner_product_matrices.L2_trial = BSpline_compute_inner_product_matrix_L2_space_trial(model, model_data.space);
model_data.space.inner_product_matrices.L2_test  = BSpline_compute_inner_product_matrix_L2_space_test(model, model_data.space);

[model_data.space.inner_product_matrices.L2_mixed, model_data.space.inner_product_matrices.L2_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_L2_space_mixed(model, model_data.space);

if model.instationary
    model_data.time.inner_product_matrices.L2_trial = BSpline_compute_inner_product_matrix_L2_time_trial(model, model_data.time);
    model_data.time.inner_product_matrices.L2_test  = BSpline_compute_inner_product_matrix_L2_time_test(model, model_data.time);
    
    [model_data.time.inner_product_matrices.L2_mixed, model_data.time.inner_product_matrices.L2_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_L2_time_mixed(model, model_data.time);
end

%% Compute H1-Semi-Inner-Product-Matrix for Space and if necessary Time
model_data.space.inner_product_matrices.H1semi_trial  = BSpline_compute_inner_product_matrix_H1semi_space_trial(model, model_data.space);
model_data.space.inner_product_matrices.H1semi_test   = BSpline_compute_inner_product_matrix_H1semi_space_test(model, model_data.space);

[model_data.space.inner_product_matrices.H1semi_mixed, model_data.space.inner_product_matrices.H1semi_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1semi_space_mixed(model, model_data.space);

if model.instationary
    model_data.time.inner_product_matrices.H1semi_trial = BSpline_compute_inner_product_matrix_H1semi_time_trial(model, model_data.time);
    model_data.time.inner_product_matrices.H1semi_test  = BSpline_compute_inner_product_matrix_H1semi_time_test(model, model_data.time);
    
    [model_data.time.inner_product_matrices.H1semi_mixed, model_data.time.inner_product_matrices.H1semi_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1semi_time_mixed(model, model_data.time);
end


%% Compute H2-Semi-Inner-Product-Matrix for Space and if necessary Time
model_data.space.inner_product_matrices.H2semi_trial  = BSpline_compute_inner_product_matrix_H2semi_space_trial(model, model_data.space);
model_data.space.inner_product_matrices.H2semi_test   = BSpline_compute_inner_product_matrix_H2semi_space_test(model, model_data.space);

[model_data.space.inner_product_matrices.H2semi_mixed, model_data.space.inner_product_matrices.H2semi_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H2semi_space_mixed(model, model_data.space);

if model.instationary
    model_data.time.inner_product_matrices.H2semi_trial = BSpline_compute_inner_product_matrix_H2semi_time_trial(model, model_data.time);
    model_data.time.inner_product_matrices.H2semi_test  = BSpline_compute_inner_product_matrix_H2semi_time_test(model, model_data.time);
    
    [model_data.time.inner_product_matrices.H2semi_mixed, model_data.time.inner_product_matrices.H2semi_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H2semi_time_mixed(model, model_data.time);
end


%% Compute H1-Inner-Product-Matrix for Space and if necessary Time
model_data.space.inner_product_matrices.H1_trial = BSpline_compute_inner_product_matrix_H1_space_trial(model, model_data.space);
model_data.space.inner_product_matrices.H1_test  = BSpline_compute_inner_product_matrix_H1_space_test(model, model_data.space);

[model_data.space.inner_product_matrices.H1_mixed, model_data.space.inner_product_matrices.H1_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1_space_mixed(model, model_data.space);

if model.instationary
    model_data.time.inner_product_matrices.H1_trial = BSpline_compute_inner_product_matrix_H1_time_trial(model, model_data.time);
    model_data.time.inner_product_matrices.H1_test  = BSpline_compute_inner_product_matrix_H1_time_test(model, model_data.time);
    
    [model_data.time.inner_product_matrices.H1_mixed, model_data.time.inner_product_matrices.H1_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1_time_mixed(model, model_data.time);
end


%% Compute H2-Inner-Product-Matrix for Space and if necessary Time
model_data.space.inner_product_matrices.H2_trial = BSpline_compute_inner_product_matrix_H2_space_trial(model, model_data.space);
model_data.space.inner_product_matrices.H2_test  = BSpline_compute_inner_product_matrix_H2_space_test(model, model_data.space);

[model_data.space.inner_product_matrices.H2_mixed, model_data.space.inner_product_matrices.H2_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H2_space_mixed(model, model_data.space);

if model.instationary
    model_data.time.inner_product_matrices.H2_trial = BSpline_compute_inner_product_matrix_H2_time_trial(model, model_data.time);
    model_data.time.inner_product_matrices.H2_test  = BSpline_compute_inner_product_matrix_H2_time_test(model, model_data.time);
    
    [model_data.time.inner_product_matrices.H2_mixed, model_data.time.inner_product_matrices.H1_mixed_with_Dirichlet] = BSpline_compute_inner_product_matrix_H2_time_mixed(model, model_data.time);
end


%% Compute Inner-Product-Matrix for Trial- and Test-Space
model_data.inner_product_matrices.W_trial = BSpline_compute_inner_product_matrix_trial(model, model_data);
model_data.inner_product_matrices.W_test  = BSpline_compute_inner_product_matrix_test(model, model_data);