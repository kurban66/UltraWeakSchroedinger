% By S. Hain
%
% Function to plot a tensor product Spline on a uniform
% grid (but possibly different refinement levels)
%
% Input:
% ------
% 'coeff' : n-D cektorized expansion coefficients
% 'T'     : Set of knots of B-Splines given as a cell element {T1,T2,...,Tn}
% 'order' : Order of B-Splines in each direction
% 'level' : level of (uniform) refinement, e.g., lev = [4,5] results in a grid
%           with equidistant spacing 2^(-4) in x and 2^(-5) in y
%
% Output:
% -------
% 'Val'   : Vector/Matrix/Movieframes of Data points to plot

function Values = Evaluate_Spline(coeff, model)

[T_time, T_space] = compute_extended_knots_on_interval(model);

grid_space = T_space(model.pdeg_space_trial + 1 : end - model.pdeg_space_trial);

grid_time  = T_time(model.pdeg_time_trial + 1 : end - model.pdeg_time_trial);

order_space = model.pdeg_space_trial + 1;

if model.instationary
    
    order_time = model.pdeg_time_trial + 1;
    
end


%% Computation of Values
if model.instationary
    
    %Values = zeros(length(T_space:h_space:T_space(length(T_space))-h_space),length(T_time:h_time:T_time(length(T_time))-h_time));
    Values = zeros(length(grid_space) , length(grid_time));
    
    for i = 1:length(grid_time)
        
        t = grid_time(i);
        
        parfor j = 1:length(grid_space)
            
            x = grid_space(j);
            
            Values(j,i) = Nev(coeff, {T_time, T_space}, [order_time, order_space], [t,x]);
            
        end
        
    end
    
else
    
    Values = zeros(length(grid_space) , 1);
        
    for j = 1:length(grid_space)
        
        x = grid_space(j);
        
        Values(j+1) = Nev(coeff, {T_space}, order_space, x);
        
    end
    
end

