classdef BSplineinfo_time < handle 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data.grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               struct seminfo with informations about temporal 
%                       discrete space spanned by BSplines
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB structure represents the temporal discrete space spanned by 
% BSplines, shared by all BSpline functions. The code follows the lines of 
% the MATLAB function feminfo.m, originally created by B. Haasdonk 
% (13.01.2011).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
    properties
        
        dimrange;
        
        global_dof_index_trial;
        global_dof_index_test;
        
        ndofs_trial;
        ndofs_test;
        
        nnodes_trial;
        nnodes_test;
        
        ndofs_per_element_trial;
        ndofs_per_element_test;
        
        grid_trial;
        grid_test;
        grid_trial_with_LGL;
        grid_test_with_LGL;
        
        nBSpline_nodes_per_element_trial;
        nBSpline_nodes_per_element_test;
        
        LGL_nodes_on_reference_element_exact_integration;
        LGL_nodes_on_reference_element_trial;
        LGL_nodes_on_reference_element_test;
        
        BSpline_nodes_on_reference_element_trial;
        BSpline_nodes_on_reference_element_LeftBound_trial;
        BSpline_nodes_on_reference_element_RightBound_trial;
        
        BSpline_nodes_on_reference_element_test;
        BSpline_nodes_on_reference_element_LeftBound_test;
        BSpline_nodes_on_reference_element_RightBound_test;
        
        ind_of_LGL_nodes_on_element_trial;
        ind_of_LGL_nodes_on_element_test;
        ind_of_LGL_nodes_on_element_trial_exact_integration;
        ind_of_LGL_nodes_on_element_test_exact_integration;
        
        elements_glob_trial;
        elements_glob_test;
        
        detDF_trial;
        detDF_test;
        
        dirichlet_ind_trial;
        dirichlet_ind_test;
        
        neumann_ind_trial;
        neumann_ind_test;
        
        robin_ind_trial;
        robin_ind_test;
        
        l2_inner_product_matrix;
        
        h10_inner_product_matrix;
        
        regularized_h10_inner_product_matrix;
        
        LGL_DiffMatrix_trial;
        LGL_DiffMatrix_LeftBound_trial;
        LGL_DiffMatrix_RightBound_trial;
        
        LGL_DiffMatrix_test;
        LGL_DiffMatrix_LeftBound_test;
        LGL_DiffMatrix_RightBound_test;
        
        LGL_HessianMatrix_trial;
        LGL_HessianMatrix_LeftBound_trial;
        LGL_HessianMatrix_RightBound_trial;
        
        LGL_HessianMatrix_test;
        LGL_HessianMatrix_LeftBound_test;
        LGL_HessianMatrix_RightBound_test;
        
        lagrange_values_on_reference_element_trial;
        lagrange_values_on_reference_element_LeftBound_trial;
        lagrange_values_on_reference_element_RightBound_trial;
        
        lagrange_values_on_reference_element_test;
        lagrange_values_on_reference_element_LeftBound_test;
        lagrange_values_on_reference_element_RightBound_test;
        
        LGL_weights_on_reference_element;
        
        dofs_trial; %"Real dofs", excluding dirichlet nodes!
        dofs_test; %"Real dofs", excluding dirichlet nodes!
        
    end
    
    methods
        
        function df_info = BSplineinfo_time (model, grid)
            %--------------------------------------------------------------
            % function feminfo(model,grid)
            % required fields of model:
            %       pdeg: polynomial degree
            %--------------------------------------------------------------
            
            if grid.nelements_trial <= grid.nelements_test
                df_info.LGL_DiffMatrix_trial            = cell(1,grid.ratio);
                df_info.LGL_DiffMatrix_LeftBound_trial  = cell(model.pdeg_time_trial-1,grid.ratio);
                df_info.LGL_DiffMatrix_RightBound_trial = cell(model.pdeg_time_trial-1,grid.ratio);
                
                df_info.LGL_DiffMatrix_test            = cell(1,1);
                df_info.LGL_DiffMatrix_LeftBound_test  = cell(model.pdeg_time_test-1,1);
                df_info.LGL_DiffMatrix_RightBound_test = cell(model.pdeg_time_test-1,1);
                
                df_info.LGL_HessianMatrix_trial            = cell(1,grid.ratio);
                df_info.LGL_HessianMatrix_LeftBound_trial  = cell(model.pdeg_time_trial-1,grid.ratio);
                df_info.LGL_HessianMatrix_RightBound_trial = cell(model.pdeg_time_trial-1,grid.ratio);
                
                df_info.LGL_HessianMatrix_test            = cell(1,1);
                df_info.LGL_HessianMatrix_LeftBound_test  = cell(model.pdeg_time_test-1,1);
                df_info.LGL_HessianMatrix_RightBound_test = cell(model.pdeg_time_test-1,1);
                
                df_info.lagrange_values_on_reference_element_trial            = cell(1,grid.ratio);
                df_info.lagrange_values_on_reference_element_LeftBound_trial  = cell(model.pdeg_time_trial-1,grid.ratio);
                df_info.lagrange_values_on_reference_element_RightBound_trial = cell(model.pdeg_time_trial-1,grid.ratio);
                
                df_info.lagrange_values_on_reference_element_test            = cell(1,1);
                df_info.lagrange_values_on_reference_element_LeftBound_test  = cell(model.pdeg_time_test,1);
                df_info.lagrange_values_on_reference_element_RightBound_test = cell(model.pdeg_time_test,1);
            else
                df_info.LGL_DiffMatrix_trial            = cell(1,1);
                df_info.LGL_DiffMatrix_LeftBound_trial  = cell(model.pdeg_time_trial,1);
                df_info.LGL_DiffMatrix_RightBound_trial = cell(model.pdeg_time_trial,1);
                
                df_info.LGL_DiffMatrix_test            = cell(1,grid.ratio);
                df_info.LGL_DiffMatrix_LeftBound_test  = cell(model.pdeg_time_test,grid.ratio);
                df_info.LGL_DiffMatrix_RightBound_test = cell(model.pdeg_time_test,grid.ratio);
                
                df_info.LGL_HessianMatrix_trial            = cell(1,1);
                df_info.LGL_HessianMatrix_LeftBound_trial  = cell(model.pdeg_time_trial,1);
                df_info.LGL_HessianMatrix_RightBound_trial = cell(model.pdeg_time_trial,1);
                
                df_info.LGL_HessianMatrix_test            = cell(1,grid.ratio);
                df_info.LGL_HessianMatrix_LeftBound_test  = cell(model.pdeg_time_test,grid.ratio);
                df_info.LGL_HessianMatrix_RightBound_test = cell(model.pdeg_time_test,grid.ratio);
                
                df_info.lagrange_values_on_reference_element_trial            = cell(1,1);
                df_info.lagrange_values_on_reference_element_LeftBound_trial  = cell(model.pdeg_time_trial,1);
                df_info.lagrange_values_on_reference_element_RightBound_trial = cell(model.pdeg_time_trial,1);
                
                df_info.lagrange_values_on_reference_element_test            = cell(1,grid.ratio);
                df_info.lagrange_values_on_reference_element_LeftBound_test  = cell(model.pdeg_time_test,grid.ratio);
                df_info.lagrange_values_on_reference_element_RightBound_test = cell(model.pdeg_time_test,grid.ratio);
            end
            
            %--------------------------------------------------------------
            
            df_info.ind_of_LGL_nodes_on_element_trial = {};
            df_info.ind_of_LGL_nodes_on_element_test  = {};
            
            %--------------------------------------------------------------
            
            df_info.elements_glob_trial = {};
            df_info.elements_glob_test  = {};
            
            
            %--------------------------------------------------------------
            %% time
            %--------------------------------------------------------------
            ind_start_trial = 1;
            ind_start_test  = 1;
            
            p_trial = model.pdeg_time_trial;
            p_test  = model.pdeg_time_test;
            
            
            %--------------------------------------------------------------
            % Computation Extended Knots on Reference Element
            %--------------------------------------------------------------
            [df_info.BSpline_nodes_on_reference_element_trial, df_info.BSpline_nodes_on_reference_element_test] = ...
                        compute_extended_knots_on_reference_element_time(model);
                    
            [df_info.BSpline_nodes_on_reference_element_LeftBound_trial, df_info.BSpline_nodes_on_reference_element_LeftBound_test] = ...
                        compute_extended_knots_on_reference_element_LeftBound_time(model);
                    
            [df_info.BSpline_nodes_on_reference_element_RightBound_trial, df_info.BSpline_nodes_on_reference_element_RightBound_test] = ...
                        compute_extended_knots_on_reference_element_RightBound_time(model);
                    
            
            %--------------------------------------------------------------
            % Computation LGL-Nodes and LGL-Weights on Reference-Element:
            % Trial- and Test-time
            %--------------------------------------------------------------
            if model.use_exact_integration
                
                if isempty(df_info.LGL_nodes_on_reference_element_exact_integration)
                    df_info.LGL_nodes_on_reference_element_exact_integration = ...
                        compute_nodes_on_reference_element(0,0,max(ceil((2*max(p_trial,p_test)+1)/2),2))';
                    
                    df_info.LGL_nodes_on_reference_element_trial   = ...
                        compute_nodes_on_reference_element(0,0,p_trial)';
                    
                    df_info.LGL_nodes_on_reference_element_test   = ...
                        compute_nodes_on_reference_element(0,0,p_test)';
                    
                    df_info.LGL_weights_on_reference_element = ...
                        compute_lgl_weights_on_reference_element(df_info.LGL_nodes_on_reference_element_exact_integration,max(ceil((2*max(p_trial,p_test)+1)/2),2));
                    
                end
                
            else
                
                if isempty(df_info.LGL_nodes_on_reference_element_trial) || isempty(df_info.BSpline_nodes_on_reference_element_trial)
                    
                    df_info.LGL_nodes_on_reference_element_trial   = ...
                        compute_nodes_on_reference_element(0,0,p_trial)';
                    
                end
                
                if isempty(df_info.LGL_nodes_on_reference_element_test)
                    
                    df_info.LGL_nodes_on_reference_element_test   = ...
                        compute_nodes_on_reference_element(0,0,p_test)';
                    
                end
                
                if isempty(df_info.LGL_weights_on_reference_element)
                    
                    if p_trial >= p_test
                        df_info.LGL_weights_on_reference_element = ...
                            compute_lgl_weights_on_reference_element(df_info.LGL_nodes_on_reference_element_trial,p_trial);
                    else
                        df_info.LGL_weights_on_reference_element = ...
                            compute_lgl_weights_on_reference_element(df_info.LGL_nodes_on_reference_element_test,p_test);
                    end
                    
                end
                
            end
            
            
            %--------------------------------------------------------------
            % Computation LGL-Diff-Matrix and Lagrange-Values of B-Splines
            %--------------------------------------------------------------
            if model.use_exact_integration
                
                if grid.nelements_trial <= grid.nelements_test
                    
                    elements_tmp = linspace(-1, 1, grid.ratio+1);
                    
                    if size(elements_tmp,2) == 2
                        nodes_tmp = elements_tmp;
                    else
                        nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                    end
                    
                    transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_exact_integration, grid.ratio);  
                    
                    for k = 1:grid.ratio
                        
                        if isempty(df_info.LGL_DiffMatrix_trial{k})
                            
                            if p_trial ~= 0
                                
                                DiffMatrix            = zeros(length(transformed_points_LGL(k,:)), p_trial + 1);
                                DiffMatrix_LeftBound  = zeros(size(DiffMatrix));
                                
                                HessianMatrix            = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound  = zeros(size(DiffMatrix));
                                
                                LagrangeValues            = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound  = zeros(size(DiffMatrix));
                                
                                if p_trial == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_trial, p_trial); 
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,l));
                                            
                                            if p_trial == 2
                                                HessianMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,l));                                                
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), transformed_points_LGL(k,l));
                                        end
                                    end
                                                                              
                                    for p = 1:p_trial-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                
                                                if p_trial == 2
                                                    HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_trial{p,k}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_trial{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_trial{p,k}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_trial{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_trial{p,k}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_trial{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
  
                                end
                                
                                df_info.LGL_DiffMatrix_trial{k}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_trial{k}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_trial{k} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_trial{k} = ones(length(transformed_points_LGL), 1);
                                
                            end
                            
                        end
                        
                    end
                    
                    %------------------------------------------------------
                    
                    if isempty(df_info.LGL_DiffMatrix_test{1})
                        
                        if p_test ~= 0
                            
                            DiffMatrix            = zeros(length(df_info.LGL_nodes_on_reference_element_exact_integration), p_test + 1);
                            DiffMatrix_LeftBound  = zeros(size(DiffMatrix));
                            
                            HessianMatrix            = zeros(size(DiffMatrix));
                            HessianMatrix_LeftBound  = zeros(size(DiffMatrix));
                            
                            LagrangeValues            = zeros(size(DiffMatrix));
                            LagrangeValues_LeftBound  = zeros(size(DiffMatrix));
                            
                            if p_test == 1
                                
                                for j = 1:size(DiffMatrix,2)
                                    DiffMatrix(:,j)    = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(DiffMatrix,1),1);
                                end
                                
                                LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_exact_integration, df_info.LGL_nodes_on_reference_element_test, p_test); 
                                
                            else
                                
                                for j = 1:size(DiffMatrix,2)
                                    for l = 1:size(DiffMatrix,1)
                                        DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                        
                                        if p_test == 2
                                            HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(HessianMatrix,1),1);
                                        else
                                            HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                        end
                                        
                                        LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                    end
                                end

                                for p = 1:p_test-1
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            
                                            DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            
                                            if p_test == 2
                                                HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            end
                                            
                                            LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            
                                        end
                                    end
                                    
                                    df_info.LGL_DiffMatrix_LeftBound_test{p,1}  = DiffMatrix_LeftBound;
                                    df_info.LGL_DiffMatrix_RightBound_test{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                    
                                    df_info.LGL_HessianMatrix_LeftBound_test{p,1} = HessianMatrix_LeftBound;
                                    df_info.LGL_HessianMatrix_RightBound_test{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                    
                                    df_info.lagrange_values_on_reference_element_LeftBound_test{p,1}  = LagrangeValues_LeftBound;
                                    df_info.lagrange_values_on_reference_element_RightBound_test{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                end
   
                            end
                                
                            df_info.LGL_DiffMatrix_test{1}                       = DiffMatrix;
                            df_info.LGL_HessianMatrix_test{1}                    = HessianMatrix;
                            df_info.lagrange_values_on_reference_element_test{1} = LagrangeValues;
                            
                        else
                            
                            df_info.lagrange_values_on_reference_element_test{1} = ones(length(df_info.LGL_nodes_on_reference_element_exact_integration), 1);
                            
                        end
                            
                    end
                    
                    %------------------------------------------------------

                else
                    
                    elements_tmp = linspace(-1, 1, grid.ratio+1);
                    
                    nodes_tmp    = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                    
                    transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_exact_integration, grid.ratio);
                    
                    for k = 1:grid.ratio
                        
                        if isempty(df_info.LGL_DiffMatrix_test{k})
                            
                            if p_test ~= 0
                                
                                DiffMatrix            = zeros(length(transformed_points_LGL(k,:)), p_test + 1);
                                DiffMatrix_LeftBound  = zeros(size(DiffMatrix));
                                
                                HessianMatrix            = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound  = zeros(size(DiffMatrix));
                                
                                LagrangeValues            = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound  = zeros(size(DiffMatrix));
                                
                                if p_test == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_test, p_test);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,l));
                                            
                                            if p_test == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), transformed_points_LGL(k,l));
                                        end
                                    end
                                    
                                    for p = 1:p_test-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                
                                                if p_test == 2
                                                    HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_test{p,k}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_test{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_test{p,k} = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_test{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_test{p,k}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_test{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_test{k}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_test{k}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_test{k} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_test{k} = ones(length(transformed_points_LGL), 1);
                                
                            end
                            
                        end
                        
                    end
                    
                    %------------------------------------------------------
                    
                    if isempty(df_info.LGL_DiffMatrix_trial{1})
                        
                        if p_trial ~= 0
                            
                            DiffMatrix            = zeros(length(df_info.LGL_nodes_on_reference_element_exact_integration), p_trial + 1);
                            DiffMatrix_LeftBound  = zeros(size(DiffMatrix));
                            
                            HessianMatrix            = zeros(size(DiffMatrix));
                            HessianMatrix_LeftBound  = zeros(size(DiffMatrix));
                            
                            LagrangeValues            = zeros(size(DiffMatrix));
                            LagrangeValues_LeftBound  = zeros(size(DiffMatrix));
                            
                            if p_trial == 1
                                
                                for j = 1:size(DiffMatrix,2)
                                    DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(DiffMatrix,1),1);
                                end
                                
                                LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_exact_integration, df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                
                            else
                                
                                for j = 1:size(DiffMatrix,2)
                                    for l = 1:size(DiffMatrix,1)
                                        DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                        
                                        if p_trial == 2
                                            HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(HessianMatrix,1),1);
                                        else
                                            HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                        end
                                        
                                        LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                    end
                                end
                                
                                for p = 1:p_trial-1
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            
                                            DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            
                                            if p_test == 2
                                                HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            end
                                            
                                            LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_exact_integration(l));
                                            
                                        end
                                    end
                                    
                                    df_info.LGL_DiffMatrix_LeftBound_trial{p,1}  = DiffMatrix_LeftBound;
                                    df_info.LGL_DiffMatrix_RightBound_trial{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                    
                                    df_info.LGL_HessianMatrix_LeftBound_trial{p,1}  = HessianMatrix_LeftBound;
                                    df_info.LGL_HessianMatrix_RightBound_trial{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                    
                                    df_info.lagrange_values_on_reference_element_LeftBound_trial{p,1}  = LagrangeValues_LeftBound;
                                    df_info.lagrange_values_on_reference_element_RightBound_trial{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                end
                                
                            end
                            
                            df_info.LGL_DiffMatrix_trial{1}                       = DiffMatrix;
                            df_info.LGL_HessianMatrix_trial{1}                    = HessianMatrix;
                            df_info.lagrange_values_on_reference_element_trial{1} = LagrangeValues;
                            
                        else
                            
                            df_info.lagrange_values_on_reference_element_trial{1} = ones(length(df_info.LGL_nodes_on_reference_element_exact_integration), 1);
                            
                        end
                        
                    end
                    
                end
                
            else % Now no exact integration
                
                if grid.nelements_trial <= grid.nelements_test
                    
                    if p_test == p_trial
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                            
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                    
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_trial, grid.ratio);
                    
                        for k = 1:grid.ratio
                    
                            if isempty(df_info.LGL_DiffMatrix_trial{k})
                                
                                if p_trial ~= 0
                                    
                                    DiffMatrix           = zeros(length(transformed_points_LGL(k,:)), p_trial + 1);
                                    DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    HessianMatrix           = zeros(size(DiffMatrix));
                                    HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    LagrangeValues           = zeros(size(DiffMatrix));
                                    LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                    
                                    if p_trial == 1
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                        end
                                        
                                        LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                        
                                    else
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,l));
                                                
                                                if p_trial == 2
                                                    HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), transformed_points_LGL(k,l));
                                            end
                                        end
                                        
                                        for p = 1:p_trial-1
                                            for j = 1:size(DiffMatrix,2)
                                                for l = 1:size(DiffMatrix,1)
                                                    
                                                    DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                    if p_test == 2
                                                        HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                    else
                                                        HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                    end
                                                    
                                                    LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                end
                                            end
                                            
                                            df_info.LGL_DiffMatrix_LeftBound_trial{p,k}  = DiffMatrix_LeftBound;
                                            df_info.LGL_DiffMatrix_RightBound_trial{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                            
                                            df_info.LGL_HessianMatrix_LeftBound_trial{p,k}  = HessianMatrix_LeftBound;
                                            df_info.LGL_HessianMatrix_RightBound_trial{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                            
                                            df_info.lagrange_values_on_reference_element_LeftBound_trial{p,k}  = LagrangeValues_LeftBound;
                                            df_info.lagrange_values_on_reference_element_RightBound_trial{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                        end
                                        
                                    end
                                    
                                    df_info.LGL_DiffMatrix_trial{k}                       = DiffMatrix;
                                    df_info.LGL_HessianMatrix_trial{k}                    = HessianMatrix;
                                    df_info.lagrange_values_on_reference_element_trial{k} = LagrangeValues;
                                    
                                else
                                    
                                    df_info.lagrange_values_on_reference_element_trial{k} = ones(length(transformed_points_LGL), 1);
                                    
                                end
                        
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_test{1})
                            
                            if p_test ~= 0
                                
                                DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_trial), p_test + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_test == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_trial, df_info.LGL_nodes_on_reference_element_test, p_test);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            
                                            if p_test == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                        end
                                    end
                                    
                                    for p = 1:p_test-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                                if p_test == 2
                                                    HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_test{p,1}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_test{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_test{p,1}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_test{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_test{p,1}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_test{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_test{1}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_test{1}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_test{1} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_test{1} = ones(length(df_info.LGL_nodes_on_reference_element_trial), 1);
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------

                    elseif p_trial > p_test
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                        
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                        
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_trial, grid.ratio);
                        
                        for k = 1:grid.ratio
                            
                            if isempty(df_info.LGL_DiffMatrix_trial{k})
                                
                                DiffMatrix           = zeros(length(transformed_points_LGL(k,:)), p_trial + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_trial == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,l));
                                            
                                            if p_trial == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), transformed_points_LGL(k,l));
                                        end
                                    end
                                    
                                    for p = 1:p_trial-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                
                                                if p_test == 2
                                                    HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_trial{p,k}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_trial{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_trial{p,k}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_trial{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_trial{p,k}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_trial{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_trial{k}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_trial{k}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_trial{k} = LagrangeValues;
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_test{1})
                            
                            if p_test ~= 0
                                
                                DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_trial), p_test + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_test == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_trial, df_info.LGL_nodes_on_reference_element_test, p_test);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            
                                            if p_test == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                        end
                                    end
                                    
                                    for p = 1:p_test-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                                if p_test == 2
                                                    HessianMatrix_LeftBound(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_test{p,1}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_test{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_test{p,1}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_test{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_test{p,1}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_test{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_test{1}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_test{1}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_test{1} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_test{1} = ones(length(df_info.LGL_nodes_on_reference_element_trial), 1);
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                    elseif p_trial < p_test
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                        
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                        
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_test, grid.ratio);
                        
                        for k = 1:grid.ratio
                            
                            if isempty(df_info.LGL_DiffMatrix_trial{k})
                                
                                if p_trial ~= 0
                                    
                                    DiffMatrix           = zeros(length(transformed_points_LGL), p_trial + 1);
                                    DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    HessianMatrix           = zeros(size(DiffMatrix));
                                    HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    LagrangeValues           = zeros(size(DiffMatrix));
                                    LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                    
                                    if p_trial == 1
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                        end
                                        
                                        LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                        
                                    else
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), transformed_points_LGL(k,l));
                                                
                                                if p_trial == 2
                                                    HessianMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), transformed_points_LGL(k,l));
                                            end
                                        end
                                        
                                        for p = 1:p_trial-1
                                            for j = 1:size(DiffMatrix,2)
                                                for l = 1:size(DiffMatrix,1)
                                                    
                                                    DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                    if p_test == 2
                                                        HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                    else
                                                        HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                    end
                                                    
                                                    LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                end
                                            end
                                            
                                            df_info.LGL_DiffMatrix_LeftBound_trial{p,k}  = DiffMatrix_LeftBound;
                                            df_info.LGL_DiffMatrix_RightBound_trial{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                            
                                            df_info.LGL_HessianMatrix_LeftBound_trial{p,k}  = HessianMatrix_LeftBound;
                                            df_info.LGL_HessianMatrix_RightBound_trial{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                            
                                            df_info.lagrange_values_on_reference_element_LeftBound_trial{p,k}  = LagrangeValues_LeftBound;
                                            df_info.lagrange_values_on_reference_element_RightBound_trial{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                        end
                                        
                                    end
                                    
                                    df_info.LGL_DiffMatrix_trial{k}                       = DiffMatrix;
                                    df_info.LGL_HessianMatrix_trial{k}                    = HessianMatrix;
                                    df_info.lagrange_values_on_reference_element_trial{k} = LagrangeValues;
                                    
                                else
                                    
                                    df_info.lagrange_values_on_reference_element_trial{k} = ones(length(transformed_points_LGL), 1);
                                    
                                end
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_test{1})
                            
                            DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_test), p_test + 1);
                            DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                            
                            HessianMatrix           = zeros(size(DiffMatrix));
                            HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                            
                            LagrangeValues           = zeros(size(DiffMatrix));
                            LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                            
                            if p_test == 1
                                
                                for j = 1:size(DiffMatrix,2)
                                    DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(DiffMatrix,1),1);
                                end
                                
                                LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_test, df_info.LGL_nodes_on_reference_element_test, p_test);
                                
                            else
                                
                                for j = 1:size(DiffMatrix,2)
                                    for l = 1:size(DiffMatrix,1)
                                        DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), df_info.LGL_nodes_on_reference_element_test(l));
                                        
                                        if p_test == 2
                                            HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(HessianMatrix,1),1);
                                        else
                                            HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), df_info.LGL_nodes_on_reference_element_test(l));
                                        end
                                        
                                        LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), df_info.LGL_nodes_on_reference_element_test(l));
                                    end
                                end
                                
                                for p = 1:p_test-1
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            
                                            DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                            
                                            if p_test == 2
                                                HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                            end
                                            
                                            LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                            
                                        end
                                    end
                                    
                                    df_info.LGL_DiffMatrix_LeftBound_test{p,1}  = DiffMatrix_LeftBound;
                                    df_info.LGL_DiffMatrix_RightBound_test{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                    
                                    df_info.LGL_HessianMatrix_LeftBound_test{p,1}  = HessianMatrix_LeftBound;
                                    df_info.LGL_HessianMatrix_RightBound_test{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                    
                                    df_info.lagrange_values_on_reference_element_LeftBound_test{p,1}  = LagrangeValues_LeftBound;
                                    df_info.lagrange_values_on_reference_element_RightBound_test{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                end
                                
                            end
                            
                            df_info.LGL_DiffMatrix_test{1}                       = DiffMatrix;
                            df_info.LGL_HessianMatrix_test{1}                    = HessianMatrix;
                            df_info.lagrange_values_on_reference_element_test{1} = LagrangeValues;
                            
                        end
                        
                    end
                    
                else
                    
                    if p_test == p_trial
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                            
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                    
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_trial, grid.ratio);
                    
                        for k = 1:grid.ratio
                    
                            if isempty(df_info.LGL_DiffMatrix_test{k})
                                
                                if p_test ~= 0
                                    
                                    DiffMatrix           = zeros(size(transformed_points_LGL,2), p_test + 1);
                                    DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    HessianMatrix           = zeros(size(DiffMatrix));
                                    HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    LagrangeValues           = zeros(size(DiffMatrix));
                                    LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                    
                                    if p_test == 1
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                        end
                                        
                                        LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_test, p_test);
                                        
                                    else
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,l));
                                                
                                                if p_test == 2
                                                    HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), transformed_points_LGL(k,l));
                                            end
                                        end
                                        
                                        for p = 1:p_test-1
                                            for j = 1:size(DiffMatrix,2)
                                                for l = 1:size(DiffMatrix,1)
                                                    
                                                    DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                    if p_test == 2
                                                        HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                    else
                                                        HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                    end
                                                    
                                                    LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                end
                                            end
                                            
                                            df_info.LGL_DiffMatrix_LeftBound_test{p,k}  = DiffMatrix_LeftBound;
                                            df_info.LGL_DiffMatrix_RightBound_test{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                            
                                            df_info.LGL_HessianMatrix_LeftBound_test{p,k}  = HessianMatrix_LeftBound;
                                            df_info.LGL_HessianMatrix_RightBound_test{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                            
                                            df_info.lagrange_values_on_reference_element_LeftBound_test{p,k}  = LagrangeValues_LeftBound;
                                            df_info.lagrange_values_on_reference_element_RightBound_test{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                        end
                                        
                                    end
                                    
                                    df_info.LGL_DiffMatrix_test{k}                       = DiffMatrix;
                                    df_info.LGL_HessianMatrix_test{k}                    = HessianMatrix;
                                    df_info.lagrange_values_on_reference_element_test{k} = LagrangeValues;
                                    
                                else
                                    
                                    df_info.lagrange_values_on_reference_element_test{k} = ones(length(transformed_points_LGL), 1);
                                    
                                end
                                    
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_trial{1})
                            
                            if p_trial ~= 0
                                
                                DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_trial), p_trial + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_trial == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_trial, df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            
                                            if p_trial == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                        end
                                    end
                                    
                                    for p = 1:p_trial-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                                if p_trial == 2
                                                    HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_trial{p,1}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_trial{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_trial{p,1}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_trial{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_trial{p,1}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_trial{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_trial{1}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_trial{1}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_trial{1} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_trial{1} = ones(length(df_info.LGL_nodes_on_reference_element_trial), 1);
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------

                    elseif p_trial > p_test
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                        
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                        
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_trial, grid.ratio);
                        
                        for k = 1:grid.ratio
                            
                            if isempty(df_info.LGL_DiffMatrix_test{k})
                                
                                if p_test ~= 0
                                    
                                    DiffMatrix           = zeros(length(transformed_points_LGL(k,:)), p_test + 1);
                                    DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    HessianMatrix           = zeros(size(DiffMatrix));
                                    HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                    
                                    LagrangeValues           = zeros(size(DiffMatrix));
                                    LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                    
                                    if p_test == 1
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                        end
                                        
                                        LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_test, p_test);
                                        
                                    else
                                        
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,l));
                                                
                                                if p_test == 2
                                                    HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), transformed_points_LGL(k,l)); 
                                            end
                                        end
                                        
                                        for p = 1:p_test-1
                                            for j = 1:size(DiffMatrix,2)
                                                for l = 1:size(DiffMatrix,1)
                                                    
                                                    DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                    if p_test == 2
                                                        HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                    else
                                                        HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                    end
                                                    
                                                    LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                    
                                                end
                                            end
                                            
                                            df_info.LGL_DiffMatrix_LeftBound_test{p,k}  = DiffMatrix_LeftBound;
                                            df_info.LGL_DiffMatrix_RightBound_test{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                            
                                            df_info.LGL_HessianMatrix_LeftBound_test{p,k}  = HessianMatrix_LeftBound;
                                            df_info.LGL_HessianMatrix_RightBound_test{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                            
                                            df_info.lagrange_values_on_reference_element_LeftBound_test{p,k}  = LagrangeValues_LeftBound;
                                            df_info.lagrange_values_on_reference_element_RightBound_test{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                        end
                                        
                                    end
                                    
                                    df_info.LGL_DiffMatrix_test{k}                       = DiffMatrix;
                                    df_info.LGL_HessianMatrix_test{k}                    = HessianMatrix;
                                    df_info.lagrange_values_on_reference_element_test{k} = LagrangeValues;
                                    
                                else
                                    
                                    df_info.lagrange_values_on_reference_element_test{k} = ones(length(transformed_points_LGL), 1);
                                    
                                end
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_trial{1})
                            
                            DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_trial), p_trial + 1);
                            DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                            
                            HessianMatrix           = zeros(size(DiffMatrix));
                            HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                            
                            LagrangeValues           = zeros(size(DiffMatrix));
                            LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                            
                            if p_trial == 1
                                
                                for j = 1:size(DiffMatrix,2)
                                    DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(DiffMatrix,1),1);
                                end
                                
                                LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_trial, df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                
                            else
                                
                                for j = 1:size(DiffMatrix, 2)
                                    for l = 1:size(DiffMatrix,1)
                                        DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                        
                                        if p_trial == 2
                                            HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                        else
                                            HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                        end
                                        
                                        LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 0, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                    end
                                end
                                
                                for p = 1:p_trial-1
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            
                                            DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            
                                            if p_trial == 2
                                                HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            end
                                            
                                            LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_trial(l));
                                            
                                        end
                                    end
                                    
                                    df_info.LGL_DiffMatrix_LeftBound_trial{p,1}  = DiffMatrix_LeftBound;
                                    df_info.LGL_DiffMatrix_RightBound_trial{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                    
                                    df_info.LGL_HessianMatrix_LeftBound_trial{p,1}  = HessianMatrix_LeftBound;
                                    df_info.LGL_HessianMatrix_RightBound_trial{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                    
                                    df_info.lagrange_values_on_reference_element_LeftBound_trial{p,1}  = LagrangeValues_LeftBound;
                                    df_info.lagrange_values_on_reference_element_RightBound_trial{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                end
                                
                            end
                            
                            df_info.LGL_DiffMatrix_trial{1}                       = DiffMatrix;
                            df_info.LGL_HessianMatrix_trial{1}                    = HessianMatrix;
                            df_info.lagrange_values_on_reference_element_trial{1} = LagrangeValues;
                            
                        end
                        
                        %--------------------------------------------------
                        
                    elseif p_trial < p_test
                        
                        elements_tmp = linspace(-1, 1, grid.ratio+1);
                        
                        if size(elements_tmp,2) == 2
                            nodes_tmp = elements_tmp;
                        else
                            nodes_tmp = [elements_tmp(1:grid.ratio)', elements_tmp(2:grid.ratio+1)'];
                        end
                        
                        transformed_points_LGL = transform_points_from_reference_element_to_element(nodes_tmp, 2/grid.ratio, df_info.LGL_nodes_on_reference_element_test, grid.ratio);
                        
                        for k = 1:grid.ratio
                            
                            if isempty(df_info.LGL_DiffMatrix_test{k})
                                
                                DiffMatrix           = zeros(length(transformed_points_LGL(k,:)), p_test + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_test == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(transformed_points_LGL(k,:), df_info.LGL_nodes_on_reference_element_test, p_test);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 1, j+(p_test-1), transformed_points_LGL(k,l));
                                            
                                            if p_test == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 2, j+(p_test-1), transformed_points_LGL(k,l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_test, p_test+1, 0, j+(p_test-1), transformed_points_LGL(k,l));
                                        end
                                    end
                                    
                                    for p = 1:p_test-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 1, j+(p-1), transformed_points_LGL(k,l));
                                                
                                                if p_test == 2
                                                    HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 2, j+(p-1), transformed_points_LGL(k,l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_test{p}, p_test+1, 0, j+(p-1), transformed_points_LGL(k,l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_test{p,k}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_test{p,k} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_test{p,k}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_test{p,k} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_test{p,k}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_test{p,k} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_test{k}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_test{k}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_test{k} = LagrangeValues;
                                
                            end
                            
                        end
                        
                        %--------------------------------------------------
                        
                        if isempty(df_info.LGL_DiffMatrix_trial{1})
                            
                            if p_trial ~= 0
                                
                                DiffMatrix           = zeros(length(df_info.LGL_nodes_on_reference_element_test), p_trial + 1);
                                DiffMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                HessianMatrix           = zeros(size(DiffMatrix));
                                HessianMatrix_LeftBound = zeros(size(DiffMatrix));
                                
                                LagrangeValues           = zeros(size(DiffMatrix));
                                LagrangeValues_LeftBound = zeros(size(DiffMatrix));
                                
                                if p_trial == 1
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        DiffMatrix(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(DiffMatrix,1),1);
                                    end
                                    
                                    LagrangeValues = eval_lagrange_on_reference_element(df_info.LGL_nodes_on_reference_element_test, df_info.LGL_nodes_on_reference_element_trial, p_trial);
                                    
                                else
                                    
                                    for j = 1:size(DiffMatrix,2)
                                        for l = 1:size(DiffMatrix,1)
                                            DiffMatrix(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_test(l));
                                            
                                            if p_trial == 2
                                                HessianMatrix(:,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(HessianMatrix,1),1);
                                            else
                                                HessianMatrix(l,j)  = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 2, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_test(l));
                                            end
                                            
                                            LagrangeValues(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_trial, p_trial+1, 1, j+(p_trial-1), df_info.LGL_nodes_on_reference_element_test(l));
                                        end
                                    end
                                    
                                    for p = 1:p_trial-1
                                        for j = 1:size(DiffMatrix,2)
                                            for l = 1:size(DiffMatrix,1)
                                                
                                                DiffMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 1, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                                
                                                if p_trial == 2
                                                    HessianMatrix_LeftBound(:,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_test(1)) * ones(size(HessianMatrix,1),1);
                                                else
                                                    HessianMatrix_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 2, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                                end
                                                
                                                LagrangeValues_LeftBound(l,j) = Ndiff(df_info.BSpline_nodes_on_reference_element_LeftBound_trial{p}, p_trial+1, 0, j+(p-1), df_info.LGL_nodes_on_reference_element_test(l));
                                                
                                            end
                                        end
                                        
                                        df_info.LGL_DiffMatrix_LeftBound_trial{p,1}  = DiffMatrix_LeftBound;
                                        df_info.LGL_DiffMatrix_RightBound_trial{p,1} = -flip(flip(DiffMatrix_LeftBound,2));
                                        
                                        df_info.LGL_HessianMatrix_LeftBound_trial{p,1}  = HessianMatrix_LeftBound;
                                        df_info.LGL_HessianMatrix_RightBound_trial{p,1} = flip(flip(HessianMatrix_LeftBound,2));
                                        
                                        df_info.lagrange_values_on_reference_element_LeftBound_trial{p,1}  = LagrangeValues_LeftBound;
                                        df_info.lagrange_values_on_reference_element_RightBound_trial{p,1} = flip(flip(LagrangeValues_LeftBound,2));
                                    end
                                    
                                end
                                
                                df_info.LGL_DiffMatrix_trial{1}                       = DiffMatrix;
                                df_info.LGL_HessianMatrix_trial{1}                    = HessianMatrix;
                                df_info.lagrange_values_on_reference_element_trial{1} = LagrangeValues;
                                
                            else
                                
                                df_info.lagrange_values_on_reference_element_trial{1} = ones(length(df_info.LGL_nodes_on_reference_element_test), 1);
                                
                            end
                            
                        end
                        
                    end
                    
                end
                
            end
            
            
            %--------------------------------------------------------------
            % Grid with LGL-Nodes for Trial-time
            %--------------------------------------------------------------
            for i = 1:grid.nelements_trial
                
                if p_trial >= 1
                    
                    Nodes_trial = transform_points_from_reference_element_to_element(...
                        [grid.X_trial(grid.elements_trial(i,1)) grid.X_trial(grid.elements_trial(i,2))], ...
                        grid.stepsize_per_element_trial , ...
                        df_info.LGL_nodes_on_reference_element_trial, 1);
                    
                    if model.use_exact_integration
                        Nodes_trial_exact_integration = transform_points_from_reference_element_to_element(...
                            [grid.X_trial(grid.elements_trial(i,1)) grid.X_trial(grid.elements_trial(i,2))], ...
                            grid.stepsize_per_element_trial , ...
                            df_info.LGL_nodes_on_reference_element_exact_integration, 1);
                    end
                    
                    if i == 1
                        df_info.ind_of_LGL_nodes_on_element_trial{i} = ...
                            [grid.elements_trial(i,1), length(grid.X_trial)+1:length(grid.X_trial)+(p_trial-1), grid.elements_trial(i,2)];
                        
                        grid.X_trial_with_LGL = [grid.X_trial, Nodes_trial(2:end-1)];
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{i} = ... 
                                [grid.elements_trial(i,1), length(grid.X_trial)+1:length(grid.X_trial)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_trial(i,2)];
                            
                            grid.X_trial_with_LGL_exact_integration = [grid.X_trial, Nodes_trial_exact_integration(2:end-1)];
                        end
                    else
                        df_info.ind_of_LGL_nodes_on_element_trial{i} = ...
                            [grid.elements_trial(i,1), length(grid.X_trial_with_LGL)+1:length(grid.X_trial_with_LGL)+(p_trial-1), grid.elements_trial(i,2)];
                        
                        grid.X_trial_with_LGL = [grid.X_trial_with_LGL, Nodes_trial(2:end-1)];
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{i} = ...
                                [grid.elements_trial(i,1), length(grid.X_trial_with_LGL_exact_integration)+1:length(grid.X_trial_with_LGL_exact_integration)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_trial(i,2)];
                            
                            grid.X_trial_with_LGL_exact_integration = [grid.X_trial_with_LGL_exact_integration, Nodes_trial_exact_integration(2:end-1)];
                        end
                    end
                    
                else % das muss noch gemacht werden (auch fuer time)
                        
                        if model.use_exact_integration
                            Nodes_trial_exact_integration = transform_points_from_reference_element_to_element(...
                                [grid.X_trial(grid.elements_trial(i,1)) grid.X_trial(grid.elements_trial(i,2))], ...
                                    grid.stepsize_per_element_trial , df_info.LGL_nodes_on_reference_element_exact_integration, 1);
                        end
                        
                        if i == 1
                            df_info.ind_of_LGL_nodes_on_element_trial{i} = grid.elements_trial(i,1);
                            
                            grid.X_trial_with_LGL = grid.X_trial;
                            
                            if model.use_exact_integration
                                df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{i} = ... 
                                    [grid.elements_trial(i,1), length(grid.X_trial)+1:length(grid.X_trial)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_trial(i,2)];
                                
                                grid.X_trial_with_LGL_exact_integration = [grid.X_trial, Nodes_trial_exact_integration(2:end-1)];
                            end
                        else
                            df_info.ind_of_LGL_nodes_on_element_trial{i} = grid.elements_trial(i,1);
                            
                            grid.X_trial_with_LGL = grid.X_trial_with_LGL;
                            
                            if model.use_exact_integration
                                df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{i} = ... 
                                    [grid.elements_trial(i,1), length(grid.X_trial_with_LGL_exact_integration)+1:length(grid.X_trial_with_LGL_exact_integration)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_trial(i,2)];
                                
                                grid.X_trial_with_LGL_exact_integration = [grid.X_trial_with_LGL_exact_integration, Nodes_trial_exact_integration(2:end-1)];
                            end
                        end
                    
                end
                
                
                %----------------------------------------------------------
                % �nderung: Indizierung der Knoten.
                % ind_start = ind_end + 1;
                %----------------------------------------------------------
                ind_end_trial = ind_start_trial + p_trial;
                
                df_info.elements_glob_trial{i} = ind_start_trial:ind_end_trial;
                
                ind_start_trial = ind_end_trial - p_trial + 1; % Neu
                
            end
            
            
            %----------------------------------------------------------
            % Grid with LGL-Nodes for Test-time
            %----------------------------------------------------------
            for i = 1:grid.nelements_test
                
                if p_test >= 1
                    
                    Nodes_test = transform_points_from_reference_element_to_element(...
                        [grid.X_test(grid.elements_test(i,1)) grid.X_test(grid.elements_test(i,2))], ...
                        grid.stepsize_per_element_test , ...
                        df_info.LGL_nodes_on_reference_element_test, 1);
                    
                    if model.use_exact_integration
                        Nodes_test_exact_integration = transform_points_from_reference_element_to_element(...
                            [grid.X_test(grid.elements_test(i,1)) grid.X_test(grid.elements_test(i,2))], ...
                            grid.stepsize_per_element_test , ...
                            df_info.LGL_nodes_on_reference_element_exact_integration, 1);
                    end
                    
                    if i == 1
                        df_info.ind_of_LGL_nodes_on_element_test{i} = ...
                            [grid.elements_trial(i,1), length(grid.X_test)+1:length(grid.X_test)+(p_test-1), grid.elements_test(i,2)];
                        
                        grid.X_test_with_LGL = [grid.X_test, Nodes_test(2:end-1)];
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_test_exact_integration{i} = ... 
                                [grid.elements_test(i,1), length(grid.X_test)+1:length(grid.X_test)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_test(i,2)];
                            
                            grid.X_test_with_LGL_exact_integration = [grid.X_test, Nodes_test_exact_integration(2:end-1)];
                        end
                    else
                        df_info.ind_of_LGL_nodes_on_element_test{i} = ...
                            [grid.elements_test(i,1), length(grid.X_test_with_LGL)+1:length(grid.X_test_with_LGL)+(p_test-1), grid.elements_test(i,2)];
                        
                        grid.X_test_with_LGL = [grid.X_test_with_LGL, Nodes_test(2:end-1)];
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_test_exact_integration{i} = ... 
                                [grid.elements_test(i,1), length(grid.X_test_with_LGL_exact_integration)+1:length(grid.X_test_with_LGL_exact_integration)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_test(i,2)];
                            
                            grid.X_test_with_LGL_exact_integration = [grid.X_test_with_LGL_exact_integration, Nodes_test_exact_integration(2:end-1)];
                        end
                    end
                    
                else % das muss noch gemacht werden (auch fuer time)
                    
                    if model.use_exact_integration
                        Nodes_test_exact_integration = transform_points_from_reference_element_to_element(...
                            [grid.X_test(grid.elements_test(i,1)) grid.X_test(grid.elements_test(i,2))], ...
                                grid.stepsize_per_element_test , df_info.LGL_nodes_on_reference_element_exact_integration, 1);
                    end
                    
                    if i == 1
                        df_info.ind_of_LGL_nodes_on_element_test{i} = grid.elements_test(i,1);
                        
                        grid.X_test_with_LGL = grid.X_test;
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_test_exact_integration{i} = ...
                                [grid.elements_test(i,1), length(grid.X_test)+1:length(grid.X_test)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_test(i,2)];
                            
                            grid.X_test_with_LGL_exact_integration = [grid.X_test, Nodes_test_exact_integration(2:end-1)];
                        end
                    else
                        df_info.ind_of_LGL_nodes_on_element_test{i} = grid.elements_test(i,1);
                        
                        grid.X_test_with_LGL = grid.X_test_with_LGL;
                        
                        if model.use_exact_integration
                            df_info.ind_of_LGL_nodes_on_element_test_exact_integration{i} = ...
                                [grid.elements_test(i,1), length(grid.X_test_with_LGL_exact_integration)+1:length(grid.X_test_with_LGL_exact_integration)+(max(ceil((2*max(p_trial,p_test)+1)/2),2)-1), grid.elements_test(i,2)];
                            
                            grid.X_test_with_LGL_exact_integration = [grid.X_test_with_LGL_exact_integration, Nodes_test_exact_integration(2:end-1)];
                        end
                    end
                    
                end
                
                
                %----------------------------------------------------------
                % �nderung: Indizierung der Knoten.
                % ind_start = ind_end + 1;
                %----------------------------------------------------------
                ind_end_test = ind_start_test + p_test;
                
                df_info.elements_glob_test{i} = ind_start_test:ind_end_test;
                
                ind_start_test = ind_end_test - p_test + 1; % Neu
                
            end
            
            %ind_start_trial = 1;
            %ind_start_test  = 1;
            
            %ind_start_trial = ind_start_trial - p_trial;
            %ind_start_test  = ind_start_test - p_test;
            
            df_info.dimrange = model.dimrange;
            
            
            %--------------------------------------------------------------
            % �nderung: Anzahl der Knoten wird verkleinert um die Anzahl der Knoten,
            % welche die Elemente trennen
            %--------------------------------------------------------------
            if p_trial >= 2
                
                df_info.nnodes_trial = ...
                    grid.nelements_trial+p_trial; % Neu (vorher + 1)
                
            elseif p_trial == 1
                
                df_info.nnodes_trial = ...
                    grid.nelements_trial*(p_trial + 1) - grid.nelements_trial + 1;
                
            else
                
                df_info.nnodes_trial = grid.nelements_trial;
                
            end
            
            %--------------------------------------------------------------
            
            if p_test >= 2
                
                df_info.nnodes_test = ...
                    grid.nelements_test+p_test; % Neu (vorher + 1)
                
            elseif p_test == 1
                
                df_info.nnodes_test = ...
                    grid.nelements_test*(p_test + 1) - grid.nelements_test + 1;
                
            else
                
                df_info.nnodes_test = grid.nelements_test;
                
            end
            
            %--------------------------------------------------------------
            % NDOFS per Element
            %--------------------------------------------------------------
            df_info.ndofs_per_element_trial = p_trial + 1;
            
            df_info.ndofs_per_element_test  = p_test + 1;
            
            %--------------------------------------------------------------
            % Grid-Information
            %--------------------------------------------------------------
            df_info.grid_trial = grid.X_trial;
            df_info.grid_test  = grid.X_test;
            
            df_info.grid_trial_with_LGL = grid.X_trial_with_LGL;
            df_info.grid_test_with_LGL  = grid.X_test_with_LGL;
            
            
            %--------------------------------------------------------------
            % detDF
            %--------------------------------------------------------------
            df_info.detDF_trial = grid.A_trial(:);
            df_info.detDF_test  = grid.A_test(:);
            
            
            %--------------------------------------------------------------
            % Boundary-Information
            %--------------------------------------------------------------
            i = df_info.ind_of_LGL_nodes_on_element_trial{1}(1,1);
            
            type_trial = model.boundary_type_time_trial(grid.X_trial(i),model);
            type_test  = model.boundary_type_time_test(grid.X_test(i),model);
            
            df_info.dirichlet_ind_trial = [];
            df_info.dirichlet_ind_test  = [];
            
            %--------------------------------------------------------------
            
            if type_trial < 0
                
                if abs(type_trial+1)<eps
                    
                    df_info.dirichlet_ind_trial = ...
                        [df_info.elements_glob_trial{1}(1,1), 1];
                    
                end
                
            end
            
            %--------------------------------------------------------------
            
            if type_test < 0
                
                if abs(type_test+1)<eps
                    
                    df_info.dirichlet_ind_test = ...
                        [df_info.elements_glob_test{1}(1,1), 1];
                    
                end
                
            end
            
            %--------------------------------------------------------------
            
            n_trial    = grid.nelements_trial;
            n_test     = grid.nelements_test;
            
            i_trial    = df_info.ind_of_LGL_nodes_on_element_trial{n_trial}(1,end);
            i_test     = df_info.ind_of_LGL_nodes_on_element_test{n_test}(1,end);
            
            type_trial = model.boundary_type_time_trial(grid.X_trial(i_trial),model);
            type_test  = model.boundary_type_time_test(grid.X_test(i_test),model);
            
            %--------------------------------------------------------------
            
            if type_trial < 0
                
                if abs(type_trial+1)<eps
                    
                    df_info.dirichlet_ind_trial = ...
                        [df_info.dirichlet_ind_trial ; df_info.elements_glob_trial{n_trial}(end), n_trial];
                    
                end
                
            end
            
            %--------------------------------------------------------------
            
            if type_test < 0
                
                if abs(type_test+1)<eps
                    
                    df_info.dirichlet_ind_test = ...
                        [df_info.dirichlet_ind_test ; df_info.elements_glob_test{n_test}(end), n_test];
                    
                end
                
            end
            
            %--------------------------------------------------------------
            
            df_info.dofs_trial = 1:df_info.nnodes_trial;
            df_info.dofs_test  = 1:df_info.nnodes_test;
            
            if model.has_dirichlet_values_time
                if ~isempty(df_info.dirichlet_ind_trial)
                    df_info.dofs_trial(df_info.dirichlet_ind_trial(:,1)) = [];
                end
                
                if ~isempty(df_info.dirichlet_ind_test)
                    df_info.dofs_test(df_info.dirichlet_ind_test(:,1))   = [];
                end
            end
            
            df_info.ndofs_trial = length(df_info.dofs_trial);
            df_info.ndofs_test  = length(df_info.dofs_test);
            
        end
        
    end
    
end