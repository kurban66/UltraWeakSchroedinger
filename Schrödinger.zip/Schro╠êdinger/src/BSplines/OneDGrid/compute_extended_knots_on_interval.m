function [T_time, T_space] = compute_extended_knots_on_interval(model)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Temporal and spatial (extended) nodes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes both, the temporal as well as the spatial
% (extended) nodes on an interval in order to construct B-Splines.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_time  = [];
T_space = [];

order_BSpline_space = model.pdeg_space_trial + 1;

n_space = 2^model.level_space_trial + order_BSpline_space - 1;

T_space = model.xrange(1) * ones(1, n_space + order_BSpline_space);

h_space = (model.xrange(2) - model.xrange(1)) * 2^(-model.level_space_trial);

for i = order_BSpline_space+1 : n_space
    T_space(i) = model.xrange(1) + (i - order_BSpline_space) * h_space;
end

T_space(n_space+1:n_space+order_BSpline_space) = model.xrange(2) * ones(order_BSpline_space,1);

if model.instationary
    
    order_BSpline_time = model.pdeg_time_trial + 1;
    
    n_time = 2^model.level_time_trial + order_BSpline_time - 1;
    
    T_time = model.trange(1) * ones(1, n_time + order_BSpline_time);
    
    h_time = (model.trange(2) - model.trange(1)) * 2^(-model.level_time_trial);
    
    for i = order_BSpline_time+1 : n_time
        T_time(i) = model.trange(1) + (i - order_BSpline_time) * h_time;
    end
    
    T_time(n_time+1:n_time+order_BSpline_time) = model.trange(2) * ones(order_BSpline_time,1);
    
end

end