function [grid_space, grid_time] = BSpline_construct_grid(params)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct params 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               spatial and temporal grid 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function calls the necessary functions to construct a spatial 
% grid as well as a temporal grid and follows mainly the lines of the 
% RBmatlab function consturct_grid.m.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

grid_space = [];
grid_time  = [];

if isfield(params,'gridtype')
    
    switch params.gridtype
        case 'rectgrid'
            % has to be written
        case 'onedgrid'
            grid_space = BSpline_onedgrid_space(params);
            if params.instationary
                grid_time  = BSpline_onedgrid_time(params);
            end
        case 'triagrid'
            % has to be written! (For the 2D-case!!!)
            % grid = dg_triagrid(params);
            % grid = set_boundary_types(grid, params);
        case 'none'
            % nothing to do
            grid = [];
        otherwise
            error('gridtype not known')
    end
else
    
    grid = [];
    
end
