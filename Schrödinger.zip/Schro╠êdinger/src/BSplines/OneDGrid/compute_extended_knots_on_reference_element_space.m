function [T_trial, T_test] = compute_extended_knots_on_reference_element_space(model)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Spatial (extended) nodes for trial and test space
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the spatial extended nodes for trial and 
% test space in order to construct B-Splines.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_trial = [];
T_test  = [];


%% Trial-Space
if model.pdeg_space_trial >= 1
    
    order_BSpline_trial = model.pdeg_space_trial + 1; %k_trial
    
    % nNodes
    n_trial = 4*model.pdeg_space_trial;
    
    % Nodes
    T_trial = -(2*model.pdeg_space_trial-1) * ones(1,n_trial);
    
    for i = order_BSpline_trial+1:n_trial-model.pdeg_space_trial
        T_trial(i) = -(2*model.pdeg_space_trial-1) + 2*(i - order_BSpline_trial);
    end
    
    T_trial(end - model.pdeg_space_trial:end) = (2*model.pdeg_space_trial-1)*ones(order_BSpline_trial,1);
    
end


%% Test-Space
if model.pdeg_space_test >= 1
    
    order_BSpline_test  = model.pdeg_space_test + 1;  %k_test
    
    % nNodes
    n_test  = 4*model.pdeg_space_test;
    
    % Nodes
    T_test  = -(2*model.pdeg_space_test-1) * ones(1,n_test);
    
    for i = order_BSpline_test+1:n_test-model.pdeg_space_test
        T_test(i) = -(2*model.pdeg_space_test-1) + 2*(i - order_BSpline_test);
    end
    
    T_test(end - model.pdeg_space_test:end)   = (2*model.pdeg_space_test-1)*ones(order_BSpline_test,1);
    
end