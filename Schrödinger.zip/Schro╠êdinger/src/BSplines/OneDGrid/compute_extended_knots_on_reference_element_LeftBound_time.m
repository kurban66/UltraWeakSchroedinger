function [T_trial, T_test] = compute_extended_knots_on_reference_element_LeftBound_time(model)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Temporal (extended) nodes for trial and test space
%                       on reference element left bound
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the temporal extended nodes on the 
% reference element at the left bound for trial and test space in order to 
% construct B-Splines.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p_trial = model.pdeg_time_trial;
p_test  = model.pdeg_time_test;

T_trial = cell(1,p_trial-1);
T_test  = cell(1,p_test-1);


%% Trial-Space
if p_trial >= 1
    
    order_BSpline_trial = p_trial + 1; %k_trial
    
    % nNodes
    n_trial = 4*p_trial;
    
    % Nodes
    for j = 1:p_trial-1
        
        T = -(2*j-1) * ones(1,n_trial);
        
        for i = order_BSpline_trial+1:n_trial-p_trial
            T(i) = -(2*j-1) + 2*(i - order_BSpline_trial);
        end
        
        T(end - p_trial:end) = -(2*j-1) + 2*(n_trial-p_trial - order_BSpline_trial)*ones(order_BSpline_trial,1);
        
        T_trial{j} = T;
        
    end
    
end


%% Test-Space
if p_test >= 1
    
    order_BSpline_test = p_test + 1; %k_trial
    
    % nNodes
    n_test = 4*p_test;
    
    % Nodes
    for j = 1:p_test-1
        
        T = -(2*j-1) * ones(1,n_test);
        
        for i = order_BSpline_test+1:n_test-p_test
            T(i) = -(2*j-1) + 2*(i - order_BSpline_test);
        end
        
        T(end - p_test:end) = -(2*j-1) + 2*(n_test-p_test - order_BSpline_test)*ones(order_BSpline_test,1);
        
        T_test{j} = T;
        
    end
    
end