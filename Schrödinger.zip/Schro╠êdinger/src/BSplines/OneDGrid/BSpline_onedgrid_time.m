classdef BSpline_onedgrid_time < gridbase 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct params 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               temporal 1D grid 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB class generates a 1D grid in time and follows mainly the 
% lines of the RBmatlab function onedgrid.m.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    properties
        
        X_trial;
        X_test;
        X_trial_with_LGL;
        X_test_with_LGL;
        X_trial_with_LGL_exact_integration;
        X_test_with_LGL_exact_integration; 
        
        nelements_trial;
        nelements_test;
        
        elements_coarse;
        elements_fine;  
        ratio;   
        
        stepsize_per_element_trial;
        stepsize_per_element_test;

        elements_trial;
        elements_test;
        
        NBI_trial;
        NBI_test;
        
        global_eind_trial; % global enumeration of entity indices '[1:nelements]'
        global_eind_test; % global enumeration of entity indices '[1:nelements]'
        
        A_trial;
        A_test;
        
        boundary_elements_type_trial;
        boundary_elements_type_test;
        
        dirichlet_nodes_trial;
        dirichlet_nodes_test;
        
    end
    
    methods
        
        function time = BSpline_onedgrid_time(varargin)
            %function onedgrid(varargin)
            %
            % constructor of a 1d grid
            %
            %     required fields of params:
            %         xnumintervals : number of elements along x directions
            %         xrange : interval covered along the x-axes
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % copy constructor
            if (nargin > 0) && ...
                    isa(varargin{1},'BSpline_onedgrid')
                % copy constructor
                fnames = fieldnames(varargin{1});
                
                for i = 1:length(fnames)
                    time.(fnames{i}) = varargin{1}.(fnames{i});
                end
                % the following only would copy handle!!!
                %grid= varargin{1};
                
            else
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % default constructor: unit interval
                if (nargin==0)
                    params.xrange = [0,1]; % 2 points
                    params.xnumintervals_trial = 100;
                    params.xnumintervals_test  = 100;
                else
                    params = varargin{1};
                end
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % construct from params
                
                if ~isfield(params,'verbose')
                    params.verbose = 0;
                end
                
                
                %% Time
                if params.instationary == 1
                    
                    dt_trial = (params.trange(2) - params.trange(1))/params.tnumintervals_trial;
                    dt_test  = (params.trange(2) - params.trange(1))/params.tnumintervals_test;
                    
                    time.X_trial = params.trange(1):dt_trial:params.trange(2);
                    time.X_test  = params.trange(1):dt_test:params.trange(2);
                    
                    n_trial = length(time.X_trial);
                    n_test  = length(time.X_test);
                    
                    time.nelements_trial = n_trial - 1;
                    time.nelements_test  = n_test - 1;
                    
                    if time.nelements_trial <= time.nelements_test
                        time.elements_coarse = time.nelements_trial;
                        time.elements_fine   = time.nelements_test;
                        time.ratio           = time.elements_fine/time.elements_coarse;
                    else
                        time.elements_coarse = time.nelements_test;
                        time.elements_fine   = time.nelements_trial;
                        time.ratio           = time.elements_fine/time.elements_coarse;
                    end
                    
                    time.stepsize_per_element_trial = dt_trial;
                    time.stepsize_per_element_test  = dt_test;
                    
                    time.elements_trial = ...
                        [1:time.nelements_trial ; 2:time.nelements_trial + 1]';
                    time.elements_test = ...
                        [1:time.nelements_test ; 2:time.nelements_test + 1]';
                    
                    time.NBI_trial = ...
                        [2:time.nelements_trial, -1; -1,1:(time.nelements_trial - 1)]';
                    time.NBI_test  = ...
                        [2:time.nelements_test, -1; -1,1:(time.nelements_test - 1)]';
                    
                    time.global_eind_trial = 1:time.nelements_trial;
                    time.global_eind_test  = 1:time.nelements_test;
                    
                    time.A_trial = time.stepsize_per_element_trial./2;
                    time.A_test  = time.stepsize_per_element_test./2;
                    
                    %% Boundary Time
                    % First and/or last element contain a boundary node!
                    % We just have to find out which type...
                    
                    type_trial = params.boundary_type_time_trial(time.X_trial(1),params);
                    type_test  = params.boundary_type_time_trial(time.X_test(1),params);
                    
                    time.dirichlet_nodes_trial = [];
                    time.dirichlet_nodes_test  = [];
                    
                    % Trial Space
                if type_trial < 0
                    
                    if abs(type_trial+1)<eps
                        time.dirichlet_nodes_trial = [1,1];
                    end
                    
                end
                
                % Test Space
                if type_test < 0
                    
                    if abs(type_test+1)<eps
                        time.dirichlet_nodes_test = [1,1];
                    end
                    
                end
                    
                    type_trial = params.boundary_type_time_trial(time.X_trial(n_trial),params);
                    type_test  = params.boundary_type_time_trial(time.X_test(n_test),params);
                    
                    % Trial Space
                if type_trial < 0
                    if abs(type_trial+1)<eps
                        time.dirichlet_nodes_trial = ...
                            [time.dirichlet_nodes_trial;n_trial,time.nelements_trial];
                    end
                end
                
                % Test Space
                if type_test < 0
                    if abs(type_test+1)<eps
                        time.dirichlet_nodes_test = ...
                            [time.dirichlet_nodes_trial;n_trial,time.nelements_trial];
                    end
                end
                    
                end
                
            end
        end
        
        gridp = gridpart(grid, eind);
        
        function gcopy = copy(grid)
            % deep copies the grid
            %
            % Return values:
            %   'gcopy': a copy of type onedtime.
            gcopy = onedgrid(grid);
        end
        
    end   % methods
    
end   % classdef
