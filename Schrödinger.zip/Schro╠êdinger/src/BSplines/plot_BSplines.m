clear, close all, clc

PDEG  = 1;

level = 0;

knots = compute_extended_knots_on_reference_element(PDEG, level);

order = PDEG + 1;

for i = 1:PDEG+1
    
    hold on
    
    c = zeros(1,PDEG+1);
    
    c(i) = 1;

    plot_Spline(c, {knots}, order, level);
    
end

