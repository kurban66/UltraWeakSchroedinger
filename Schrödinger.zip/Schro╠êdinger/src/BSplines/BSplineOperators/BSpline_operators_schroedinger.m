function [B, r] = BSpline_operators_schroedinger(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model and struct model_data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               matrix B and RHS r of the Schroedinger equation
%                       using BSplines
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab 
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB functions computes the matrix and RHS of the Schroedinger 
% equation using BSplines. This functions follows partly the lines of 
% fem_operators.m by B. Haasdonk (22.02.2011).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A_space = sparse(0);

B = sparse(0);
r = 0;


if model.decomp_mode == 0 % == complete: simple addition
    
    %----------------------------------------------------------------------
    % Left-Hand-Side
    %----------------------------------------------------------------------
    
    AA_space = BSpline_assembly_matrices_space(model, model_data.space);
    
    for i = 1:size(AA_space,1)
        A_space = A_space + AA_space{i};
    end
    
    if model.instationary
        
        if model.use_no_duality_pairing_time
            advection_second_order = BSpline_compute_advection_second_order_matrix_time(model, model_data.time);
            diffusion_time         = BSpline_compute_diffusion_matrix_time(model, model_data.time);
        end
        
        AA_time = BSpline_assembly_matrices_time(model, model_data.time);
        
        e       = zeros(1,size(AA_time{1},2));
        e(1)    = 1;
        
        if model.has_reaction_time
            
            if model.use_kronecker_product
                
                if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))
                    
                    if model.use_no_duality_pairing
                        B = kron(cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), AA_space{1}) + kron(AA_time{2} - cell2mat(diffusion_time), AA_space{2});
                    else
                        B = kron(AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed,AA_space{1}) + kron(AA_time{2}, AA_space{2});
                    end
                    
                else
                    
                    if model.use_no_duality_pairing
                        B = [kron(cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), AA_space{1}) + kron(AA_time{2} - cell2mat(diffusion_time), AA_space{2}); ...
                        kron(e, model_data.space.inner_product_matrices.L2_mixed)]; 
                    else
                        B = [kron(AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed,AA_space{1}) + kron(AA_time{2}, AA_space{2}); ...
                        kron(e, model_data.space.inner_product_matrices.L2_mixed)]; 
                    end
                    
                end
                
            else
                
                if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))
                    
                    if model.use_no_duality_pairing
                        B = {{cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, {model_data.time.inner_product_matrices.L2_mixed, AA_space{1}}, {AA_time{2}, AA_space{2}}};
                    else
                        B = {{AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, {model_data.time.inner_product_matrices.L2_mixed, AA_space{1}}, {AA_time{2}, AA_space{2}}};
                    end
                    
                else 
                    
                    if model.use_no_duality_pairing
                        B = {{cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, ...
                            {model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), AA_space{1}}, ...
                            {AA_time{2} - cell2mat(diffusion_time),AA_space{2}}, ...
                            {model_data.space.inner_product_matrices.L2_mixed}};
                    else
                        B = {{AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, ...
                            {model_data.time.inner_product_matrices.L2_mixed, AA_space{1}}, ...
                            {AA_time{2},AA_space{2}}, ...
                            {model_data.space.inner_product_matrices.L2_mixed}};
                    end
                    
                end
                
            end
  
        else
            
            if model.use_kronecker_product
                
                if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))
                    
                    if model.use_no_duality_pairing_time
                        B = kron(cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), A_space);
                    else
                        B = kron(AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed, A_space);
                    end
                    
                else
                    
                    if model.use_no_duality_pairing_time
                        B = [kron(cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), A_space); ...
                            kron(e, model_data.space.inner_product_matrices.L2_mixed)];
                    else
                        B = [kron(AA_time{1}, model_data.space.inner_product_matrices.L2_mixed) + kron(model_data.time.inner_product_matrices.L2_mixed, A_space); ...
                            kron(e, model_data.space.inner_product_matrices.L2_mixed)];
                    end
                    
                end
                
            else
                
                if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))
                    
                    if model.use_no_duality_pairing_time
                        B = {{cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, {model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), A_space}};
                    else
                        B = {{AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, {model_data.time.inner_product_matrices.L2_mixed, A_space}};
                    end
                    
                else
                    
                    if model.use_no_duality_pairing_time
                        B = {{cell2mat(advection_second_order) + AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, ...
                            {model_data.time.inner_product_matrices.L2_mixed - cell2mat(diffusion_time), A_space}, ...
                            {model_data.space.inner_product_matrices.L2_mixed}};
                    else
                        B = {{AA_time{1}, model_data.space.inner_product_matrices.L2_mixed}, ...
                            {model_data.time.inner_product_matrices.L2_mixed, A_space}, ...
                            {model_data.space.inner_product_matrices.L2_mixed}};
                    end
                    
                end
                
            end
              
        end
        
    else
        
        B = A_space;
    
    end
    
    %----------------------------------------------------------------------
    % Right-Hand-Side
    %----------------------------------------------------------------------
    
    rr = BSpline_assembly_rhs_schroedinger(model, model_data); % Bis einschlie�lich hier sollte es stimmen
    
    if model.has_dirichlet_values_time && (~isempty(model_data.time.df_info.dirichlet_ind_trial) || ~isempty(model_data.time.df_info.dirichlet_ind_test))
        
        if model.use_kronecker_product
            r = rr(:);
        else
            r = {rr};
        end
        
    else
        
        if model.use_kronecker_product
            r = [rr{1}(:); rr{2}(:)];
        else
            r = {rr{1},rr{2}};
        end
        
    end

    

    
elseif model.decomp_mode == 1 % == components: merge to cell arrays
    
    A_space = BSpline_assembly_matrices_space(model, model_data);
    
    if model.instationary
        A_time = BSpline_assembly_matrices_time(model, model_data); 
    end
    
    r = BSpline_assembly_rhs_schroedinger(model, model_data);
    

    

elseif model.decomp_mode == 2 % decomp_mode == 2, coefficients: merge coeff vectors
    
    Adiff  = [];
    
    Aadv   = [];
    
    Areac  = [];
    
    Arobin = [];
    
    r_source   = [];
    
    r_dir      = [];
    r_dir_diff = [];
    r_dir_adv  = [];
    r_dir_reac = [];
    
    r_nm       = [];
    
    r_robin    = [];
    
    
    %% Diffusion
    if model.has_diffusivity
        Adiff = model.diffusivity([], model);
    end
    
    %% Advection
    if model.has_advection
        Aadv = model.advection([], model);
    end
    
    %% Reaction
    if model.has_reaction
        Areac = model.reaction([], model);
    end
    
    %% Robin
    if model.has_robin_values
        Arobin = model.robin_beta([], model);
    end
    
    A = [Adiff(:); Aadv(:); Areac(:); Arobin(:)];
    
    
    %% Source
    if model.has_source
        r_source = model.source([], model);
    end
    
    
    %% Dirichlet
    % Hier auf Dimensionen aufpassen!
    if model.has_dirichlet_values
        dir = model.dirichlet([], model);
        dir = dir(:);
        if model.has_diffusivity
            diff = model.diffusivity([], model);
            r_dir_diff = diff(:)*dir';
        end
        if model.has_advection
            adv = model.advection([], model);
            adv = adv(:);
            r_dir_adv = adv*dir';
        end
        if model.has_reaction
            reac = model.reaction([], model);
            reac = reac(:);
            r_dir_reac = reac*dir';
        end
        
        
        % Reihenfolge?
        r_dir = [r_dir_diff(:);r_dir_adv(:);r_dir_reac(:)];
    end
    
    
    %% Neumann
    if model.has_neumann_values
        r_nm = model.neumann([], model);
    end
    
    
    %% Robin
    if model.has_robin_values
        r_robin = model.robin_g([], model);
    end
    
    r = [r_source(:);r_dir(:);r_nm(:);r_robin(:)];
    
    
    
elseif model.decomp_mode == 3
    %% If first derivative wants to be computed;
    
    Adiff       = [];
    
    Aadv        = [];
    
    Areac       = [];
    
    Arobin      = [];
    
    r_source    = [];
    
    r_dir       = [];
    r_dir_diff  = [];
    r_dir_adv   = [];
    r_dir_reac  = [];
    
    r_nm        = [];
    
    r_robin     = [];
    
    
    %% Diffusion
    if model.has_diffusivity
        Adiff = model.diffusivity_der([], model);
    end
    
    %% Advection
    if model.has_advection
        Aadv = model.advection_dir([], model);
    end
    
    %% Reaction
    if model.has_reaction
        Areac = model.reaction_der([], model);
    end
    
    %% Robin
    if model.has_robin_values
        Arobin = model.robin_beta_der([], model);
    end
    
    A=[Adiff(:);Aadv(:);Areac(:);Arobin(:)];
    
    
    %% Source
    if model.has_source
        r_source = model.source_der([],model);
    end
    
    
    %% Dirichlet
    % Hier auf Dimensionen aufpassen!
    if model.has_dirichlet_values
        dir = model.dirichlet_der([], model);
        dir =dir(:);
        if model.has_diffusivity
            diff = model.diffusivity_der([], model);
            r_dir_diff = diff(:)*dir';
        end
        if model.has_advection
            adv=model.advection_der([], model);
            adv=adv(:);
            r_dir_adv = adv*dir';
        end
        if model.has_reaction
            reac = model.reaction_der([], model);
            reac = reac(:);
            r_dir_reac = reac*dir';
        end
        
        
        % Reihenfolge?
        r_dir = [r_dir_diff(:);r_dir_adv(:);r_dir_reac(:)];
    end
    
    
    %% Neumann
    if model.has_neumann_values
        r_nm = model.neumann_der([], model);
    end
    
    
    %% Robin
    if model.has_robin_values
        r_robin = model.robin_g_der([], model);
    end
    
    r=[r_source(:);r_dir(:);r_nm(:);r_robin(:)];
    
end