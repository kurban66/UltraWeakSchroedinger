function H2semi = BSpline_compute_inner_product_matrix_H2semi_time_trial(model, model_data) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H2-semi inner-product matrix for temporal trial 
%                       functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H2-semi inner-product matrix for the
% temporal trial functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values
diff_time                                   = model.has_diffusivity_time;
model.has_diffusivity_time                  = 1;

adv_time                                    = model.has_advection_time;
model.has_advection_time                    = 0;

reac_time                                   = model.has_reaction_time;
model.has_reaction_time                     = 0;

decomp_mode                                 = model.decomp_mode;
model.decomp_mode                           = 0;

if isempty(model_data.df_info.dirichlet_ind_trial)
    dirichlet_values = model.has_dirichlet_values_time;
    model.has_dirichlet_values_time = 0;
else
    dirichlet_test = model_data.df_info.dirichlet_ind_test;
    model_data.df_info.dirichlet_ind_test = model_data.df_info.dirichlet_ind_trial;
end

p_test                                      = model.pdeg_time_test;
model.pdeg_time_test                        = model.pdeg_time_trial;

nelements_test                              = model_data.grid.nelements_test;
model_data.grid.nelements_test              = model_data.grid.nelements_trial;

coarse_time                                 = model_data.grid.elements_coarse;
model_data.grid.elements_coarse             = model_data.grid.nelements_trial;

fine_time                                   = model_data.grid.elements_fine;
model_data.grid.elements_fine               = model_data.grid.nelements_trial;

nnodes_test                                 = model_data.df_info.nnodes_test;
model_data.df_info.nnodes_test              = model_data.df_info.nnodes_trial;

ratio                                       = model_data.grid.ratio;
model_data.grid.ratio                       = 1;

ultraweak_formulation                       = model.ultraweak_formulation;
model.ultraweak_formulation                 = 0;

if model.use_exact_integration
    
    X_time_test = model_data.grid.X_test_with_LGL_exact_integration;
    model_data.grid.X_test_with_LGL_exact_integration = model_data.grid.X_trial_with_LGL_exact_integration;
    
    ind_of_LGL_nodes_test = model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration;
    model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration;
    
else
    
    X_time_test = model_data.grid.X_test_with_LGL;
    model_data.grid.X_test_with_LGL = model_data.grid.X_trial_with_LGL;
    
    ind_of_LGL_nodes_test = model_data.df_info.ind_of_LGL_nodes_on_element_test;
    model_data.df_info.ind_of_LGL_nodes_on_element_test = model_data.df_info.ind_of_LGL_nodes_on_element_trial;

end

if model.pdeg_time_trial ~= 0
    glob_time_test = model_data.df_info.elements_glob_test;
    model_data.df_info.elements_glob_test = model_data.df_info.elements_glob_trial;
    
    stepsize_per_element = model_data.grid.stepsize_per_element_test;
    model_data.grid.stepsize_per_element_test = model_data.grid.stepsize_per_element_trial;
end

LGL_HessianMatrix_test = model_data.df_info.LGL_HessianMatrix_test;
model_data.df_info.LGL_HessianMatrix_test = model_data.df_info.LGL_HessianMatrix_trial;

LGL_HessianMatrix_test_LeftBound = model_data.df_info.LGL_HessianMatrix_LeftBound_test;
model_data.df_info.LGL_HessianMatrix_LeftBound_test = model_data.df_info.LGL_HessianMatrix_LeftBound_trial;

LGL_HessianMatrix_test_RightBound = model_data.df_info.LGL_HessianMatrix_RightBound_test;
model_data.df_info.LGL_HessianMatrix_RightBound_test = model_data.df_info.LGL_HessianMatrix_RightBound_trial;

%% Save & change the reaction components and coefficients!
diffusivity_time       = model.diffusivity_time;
model.diffusivity_time = @(glob,params) ones(length(glob),1);

%% Comppute Inner Product Matrix
H2semi = BSpline_compute_bidiffusion_matrix_time(model, model_data);
H2semi = H2semi{1};

H2semi = 0.5*(H2semi + H2semi');

%% Return the old values
model.has_diffusivity_time                  = diff_time;

model.has_advection_time                    = adv_time;

model.has_reaction_time                     = reac_time;

model.diffusivity_time                      = diffusivity_time;

if isempty(model_data.df_info.dirichlet_ind_trial)
    model.has_dirichlet_values_time = dirichlet_values;
else
    model_data.df_info.dirichlet_ind_test = dirichlet_test;
end

model.pdeg_time_test                        = p_test;

model_data.grid.nelements_test              = nelements_test;

model_data.df_info.nnodes_test              = nnodes_test;

model_data.grid.elements_coarse             = coarse_time;

model_data.grid.elements_fine               = fine_time;

if model.use_exact_integration
    model_data.grid.X_test_with_LGL_exact_integration = X_time_test;
    
    model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration = ind_of_LGL_nodes_test;
else
   model_data.grid.X_test_with_LGL = X_time_test; 
   
   model_data.df_info.ind_of_LGL_nodes_on_element_test = ind_of_LGL_nodes_test;
end

if model.pdeg_time_trial ~= 0
    model_data.df_info.elements_glob_test = glob_time_test;
    model_data.grid.stepsize_per_element_test = stepsize_per_element;
end

model_data.df_info.LGL_HessianMatrix_test = LGL_HessianMatrix_test;

model_data.df_info.LGL_HessianMatrix_LeftBound_test = LGL_HessianMatrix_test_LeftBound;

model_data.df_info.LGL_HessianMatrix_RightBound_test = LGL_HessianMatrix_test_RightBound;

model_data.grid.ratio = ratio;

model.ultraweak_formulation = ultraweak_formulation;
   
model.decomp_mode = decomp_mode;