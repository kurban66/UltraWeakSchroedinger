function H2semi = BSpline_compute_inner_product_matrix_H2semi_space_test(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H2-semi inner-product matrix for spatial test 
%                       functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H2-semi inner-product matrix for the 
% spatial test functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values
diff_space                                  = model.has_diffusivity_space;
model.has_diffusivity_space                 = 1;

adv_space                                   = model.has_advection_space;
model.has_advection_space                   = 0;

reac_space                                  = model.has_reaction_space;
model.has_reaction_space                    = 0;

robin_space                                 = model.has_robin_values_space;
model.has_robin_values_space                = 0;

decomp_mode                                 = model.decomp_mode;
model.decomp_mode                           = 0;

p_trial                                     = model.pdeg_space_trial;
model.pdeg_space_trial                      = model.pdeg_space_test;

nelements_trial                             = model_data.grid.nelements_trial;
model_data.grid.nelements_trial             = model_data.grid.nelements_test;

coarse_space                                = model_data.grid.elements_coarse;
model_data.grid.elements_coarse             = model_data.grid.nelements_test;

fine_space                                  = model_data.grid.elements_fine;
model_data.grid.elements_fine               = model_data.grid.nelements_test;

nnodes_trial                                = model_data.df_info.nnodes_trial;
model_data.df_info.nnodes_trial             = model_data.df_info.nnodes_test;

ultraweak_formulation                       = model.ultraweak_formulation;
model.ultraweak_formulation                 = 0;

if model.use_exact_integration
    X_space_trial = model_data.grid.X_trial_with_LGL_exact_integration;
    model_data.grid.X_trial_with_LGL_exact_integration = model_data.grid.X_test_with_LGL_exact_integration;
else
    X_space_trial = model_data.grid.X_trial_with_LGL;
    model_data.grid.X_trial_with_LGL = model_data.grid.X_test_with_LGL;
end

if model.use_exact_integration
    ind_of_LGL_nodes_trial = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration;
    model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration = model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration;
else
    ind_of_LGL_nodes_trial = model_data.df_info.ind_of_LGL_nodes_on_element_trial;
    model_data.df_info.ind_of_LGL_nodes_on_element_trial = model_data.df_info.ind_of_LGL_nodes_on_element_test;
end

if model.pdeg_space_test ~= 0
    glob_space_trial = model_data.df_info.elements_glob_trial;
    model_data.df_info.elements_glob_trial = model_data.df_info.elements_glob_test;
    
    stepsize_per_element = model_data.grid.stepsize_per_element_trial;
    model_data.grid.stepsize_per_element_trial = model_data.grid.stepsize_per_element_test;
end

ratio = model_data.grid.ratio;
model_data.grid.ratio = 1;

LGL_HessianMatrix_trial = model_data.df_info.LGL_HessianMatrix_trial;
model_data.df_info.LGL_HessianMatrix_trial = model_data.df_info.LGL_HessianMatrix_test;

LGL_HessianMatrix_trial_LeftBound = model_data.df_info.LGL_HessianMatrix_LeftBound_trial;
model_data.df_info.LGL_HessianMatrix_LeftBound_trial = model_data.df_info.LGL_HessianMatrix_LeftBound_test;

LGL_HessianMatrix_trial_RightBound = model_data.df_info.LGL_HessianMatrix_RightBound_trial;
model_data.df_info.LGL_HessianMatrix_RightBound_trial = model_data.df_info.LGL_HessianMatrix_RightBound_test;

%% Save & change the reaction components and coefficients!
diffusivity_space       = model.diffusivity_space;
model.diffusivity_space = @(glob,params) ones(length(glob),1);

%% Comppute Inner Product Matrix
H2semi = BSpline_compute_bidiffusion_matrix_space(model, model_data);
H2semi = H2semi{1};

H2semi = 0.5*(H2semi + H2semi');

%% Return the old values
model.has_diffusivity_space                 = diff_space;

model.has_advection_space                   = adv_space;

model.has_reaction_space                    = reac_space;

model.has_robin_values_space                = robin_space;

model.diffusivity_space                     = diffusivity_space;

model.pdeg_space_trial                      = p_trial;

model_data.grid.nelements_trial             = nelements_trial;

model_data.df_info.nnodes_trial             = nnodes_trial;

model_data.grid.elements_coarse             = coarse_space;

model_data.grid.elements_fine               = fine_space;

if model.use_exact_integration
    model_data.grid.X_trial_with_LGL_exact_integration = X_space_trial;
else
   model_data.grid.X_trial_with_LGL = X_space_trial; 
end

if model.use_exact_integration
    model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration = ind_of_LGL_nodes_trial;
else
    model_data.df_info.ind_of_LGL_nodes_on_element_trial = ind_of_LGL_nodes_trial;
end

if model.pdeg_space_test ~= 0
    model_data.df_info.elements_glob_trial = glob_space_trial;
    model_data.grid.stepsize_per_element_trial = stepsize_per_element;
end

model_data.grid.ratio = ratio;
    
model_data.df_info.LGL_HessianMatrix_trial = LGL_HessianMatrix_trial;

model_data.df_info.LGL_HessianMatrix_LeftBound_trial = LGL_HessianMatrix_trial_LeftBound;

model_data.df_info.LGL_HessianMatrix_RightBound_trial = LGL_HessianMatrix_trial_RightBound;

model.ultraweak_formulation = ultraweak_formulation;

model.decomp_mode = decomp_mode;