function Y = BSpline_compute_inner_product_matrix_test(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               inner-product matrix for space and time dependend
%                       test functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes inner-product matrix for the test space, 
% which contains the space and time dependend test functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Choose V-Norm
if model.use_energy_norm
    
    diffusion_matrix       = BSpline_compute_diffusion_matrix_space(model, model_data.space);
    diffusion_matrix       = {-diffusion_matrix{1}};
    
    if model.has_diffusivity_space && model.has_advection_space && model.has_reaction_space
        
        advection_matrix = BSpline_compute_advection_matrix_space(model, model_data.space);
        reaction_matrix = BSpline_compute_reaction_matrix_space(model, model_data.space);
        
        inner_product_matrix_V = cell2mat(diffusion_matrix) + cell2mat(advection_matrix) + cell2mat(reaction_matrix);
        inner_product_matrix_V = 0.5*(inner_product_matrix_V + inner_product_matrix_V.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
    
    elseif model.has_diffusivity_space && model.has_reaction_space
        
        reaction_matrix = BSpline_compute_reaction_matrix_space(model, model_data.space);
        
        inner_product_matrix_V = cell2mat(diffusion_matrix) + cell2mat(reaction_matrix);
        inner_product_matrix_V = 0.5*(inner_product_matrix_V + inner_product_matrix_V.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
        
    elseif model.has_diffusivity_space && ~model.has_reaction_space
        
        inner_product_matrix_V = 0.5*(diffusion_matrix{1} + diffusion_matrix{1}.');
        inner_product_matrix_V = real(inner_product_matrix_V) + imag(inner_product_matrix_V);
        
    end
    
else
    
    inner_product_matrix_V = model_data.space.inner_product_matrices.H1_test;
    
end


%% Generate Inner-Product-Matrix of Trial-Space
if model.use_kronecker_product
    
    % Define First Block
    Block_1 = kron(model_data.time.inner_product_matrices.L2_test, inner_product_matrix_V);
    
    %if strcmp(model.name,'schroedinger')
    %    
    %    if model.use_no_duality_pairing_time
    %        Block_1 = kron(model_data.time.inner_product_matrices.L2_test, inner_product_matrix_V); %kron(model_data.time.inner_product_matrices.H1_test, inner_product_matrix_V);
    %    else
    %        Block_1 = kron(model_data.time.inner_product_matrices.L2_test * (model_data.time.inner_product_matrices.H1_test \ model_data.time.inner_product_matrices.L2_test), inner_product_matrix_V); %kron(model_data.time.inner_product_matrices.H1_test, inner_product_matrix_V);
    %    end
    %    
    %else
    %    
    %    Block_1 = kron(model_data.time.inner_product_matrices.L2_test, inner_product_matrix_V);
    %    
    %end
    
    % Compute Inner-Product-Matrix for Test-Space
    if ~isempty(model_data.time.df_info.dirichlet_ind_trial)
        
        Y = Block_1;
        
        Y = 0.5*(Y + Y');
        
    else
        
        % Define Last Block
        % L2 inner product
        Block_4 = model_data.space.inner_product_matrices.L2_test;

        % Duality Pairing <u,v>_H1 x H-1
        %Block_4 = model_data.space.inner_product_matrices.L2_test * (model_data.space.inner_product_matrices.H1_test \ model_data.space.inner_product_matrices.L2_test);

        %if strcmp(model.name,'schroedinger')
        %    Block_4 = model_data.space.inner_product_matrices.L2_test; % * (model_data.space.inner_product_matrices.H1_test \ model_data.space.inner_product_matrices.L2_test);
        %else
        %    Block_4 = model_data.space.inner_product_matrices.L2_test;
        %end
        
        % Define Zero-Blocks
        Block_2_3 = sparse(size(Block_1,1),size(Block_4,2));
        
        Y = [Block_1, Block_2_3; Block_2_3', Block_4];
        
        Y = 0.5 * (Y + Y');
        
    end
    
else
    
    % Define First Block
    if model.use_no_duality_pairing_time
        Block_1 = {model_data.time.inner_product_matrices.H1_test, inner_product_matrix_V};
    else
        Block_1 = {model_data.time.inner_product_matrices.L2_test * (model_data.time.inner_product_matrices.H1_test \ model_data.time.inner_product_matrices.L2_test), inner_product_matrix_V};
    end
    
    % Compute Inner-Product-Matrix for Test-Space
    if ~isempty(model_data.time.df_info.dirichlet_ind_trial)
        
        Y = {Block_1};
        
    else
        
        % Define Last Block
        Block_4 = model_data.space.inner_product_matrices.L2_test;
        
        Y = {Block_1, {Block_4}};
        
    end
    
end

end
