function [H1semi, H1semi_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1semi_time_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H1-semi inner-product matrix (mixed) between 
%                       temporal trial and temporal test functions with and 
%                       without Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H1-semi inner-product matrices between 
% the temporal trial functions and the temporal test functions (= "mixed") 
% with and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values for computing Inner-Product-Matrix
diff_time                               = model.has_diffusivity_time;
model.has_diffusivity_time              = 1;

adv_time                                = model.has_advection_time;
model.has_advection_time                = 0;

reac_time                               = model.has_reaction_time;
model.has_reaction_time                 = 0;

dirichlet_time                          = model.has_dirichlet_values_time;
model.has_dirichlet_values_time         = 0;

decomp_mode                             = model.decomp_mode;
model.decomp_mode                       = 0;

ultraweak_formulation                   = model.ultraweak_formulation;
model.ultraweak_formulation             = 0;

%% Save & change the reaction components and coefficients!
diffusivity_time       = model.diffusivity_time;
model.diffusivity_time = @(glob,params) ones(length(glob),1);

%% Compute Inner Product Matrix
H1semi                = BSpline_assembly_matrices_time(model,model_data);
H1semi_with_Dirichlet = -H1semi{1};
H1semi                = H1semi_with_Dirichlet;

model.has_dirichlet_values_time = dirichlet_time;

if model.has_dirichlet_values_time && ~isempty(model_data.df_info.dirichlet_ind_trial)
    dir_info_trial                = model_data.df_info.dirichlet_ind_trial;
    H1semi(:,dir_info_trial(:,1)) = [];
end

if model.has_dirichlet_values_time && ~isempty(model_data.df_info.dirichlet_ind_test)
    dir_info_test                = model_data.df_info.dirichlet_ind_test;
    H1semi(dir_info_test(:,1),:) = [];
end

%% Return the old values
model.has_diffusivity_time              = diff_time;
model.has_advection_time                = adv_time;
model.has_reaction_time                 = reac_time;

model.diffusivity_time                  = diffusivity_time;

model.ultraweak_formulation             = ultraweak_formulation;

model.decomp_mode                       = decomp_mode;