function H1semi = BSpline_compute_inner_product_matrix_H1semi_space_trial(model, model_data) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H1-semi inner-product matrix for spatial trial 
%                       functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H1-semi inner-product matrix for the
% spatial trial functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values
diff_space                                  = model.has_diffusivity_space;
model.has_diffusivity_space                 = 1;

adv_space                                   = model.has_advection_space;
model.has_advection_space                   = 0;

reac_space                                  = model.has_reaction_space;
model.has_reaction_space                    = 0;

robin_space                                 = model.has_robin_values_space;
model.has_robin_values_space                = 0;

decomp_mode                                 = model.decomp_mode;
model.decomp_mode                           = 0;

p_test                                      = model.pdeg_space_test;
model.pdeg_space_test                       = model.pdeg_space_trial;

nelements_test                             	= model_data.grid.nelements_test;
model_data.grid.nelements_test             	= model_data.grid.nelements_trial;

coarse_space                                = model_data.grid.elements_coarse;
model_data.grid.elements_coarse             = model_data.grid.nelements_trial;

fine_space                                  = model_data.grid.elements_fine;
model_data.grid.elements_fine               = model_data.grid.nelements_trial;

nnodes_test                                 = model_data.df_info.nnodes_test;
model_data.df_info.nnodes_test              = model_data.df_info.nnodes_trial;

ultraweak_formulation                       = model.ultraweak_formulation;
model.ultraweak_formulation                 = 0;

if model.use_exact_integration
    X_space_test = model_data.grid.X_test_with_LGL_exact_integration;
    model_data.grid.X_test_with_LGL_exact_integration = model_data.grid.X_trial_with_LGL_exact_integration;
else
    X_space_test = model_data.grid.X_test_with_LGL;
    model_data.grid.X_test_with_LGL = model_data.grid.X_trial_with_LGL;
end

if model.use_exact_integration
    ind_of_LGL_nodes_test = model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration;
    model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration;
else
    ind_of_LGL_nodes_test = model_data.df_info.ind_of_LGL_nodes_on_element_test;
    model_data.df_info.ind_of_LGL_nodes_on_element_test = model_data.df_info.ind_of_LGL_nodes_on_element_trial;
end

if model.pdeg_space_trial ~= 0
    glob_space_test = model_data.df_info.elements_glob_test;
    model_data.df_info.elements_glob_test = model_data.df_info.elements_glob_trial;
    
    stepsize_per_element = model_data.grid.stepsize_per_element_test;
    model_data.grid.stepsize_per_element_test = model_data.grid.stepsize_per_element_trial;
end

ratio = model_data.grid.ratio;
model_data.grid.ratio = 1;

LGL_DiffMatrix_test = model_data.df_info.LGL_DiffMatrix_test;
model_data.df_info.LGL_DiffMatrix_test = model_data.df_info.LGL_DiffMatrix_trial;

LGL_DiffMatrix_test_LeftBound = model_data.df_info.LGL_DiffMatrix_LeftBound_test;
model_data.df_info.LGL_DiffMatrix_LeftBound_test = model_data.df_info.LGL_DiffMatrix_LeftBound_trial;

LGL_DiffMatrix_test_RightBound = model_data.df_info.LGL_DiffMatrix_RightBound_test;
model_data.df_info.LGL_DiffMatrix_RightBound_test = model_data.df_info.LGL_DiffMatrix_RightBound_trial;

%% Save & change the reaction components and coefficients!
diffusivity_space       = model.diffusivity_space;
model.diffusivity_space = @(glob,params) ones(length(glob),1);

%% Comppute Inner Product Matrix
H1semi = BSpline_assembly_matrices_space(model, model_data);
H1semi = -H1semi{1};

H1semi = 0.5*(H1semi + H1semi');

%% Return the old values
model.has_diffusivity_space                 = diff_space;

model.has_advection_space                   = adv_space;

model.has_reaction_space                    = reac_space;

model.has_robin_values_space                = robin_space;

model.diffusivity_space                     = diffusivity_space;

model.pdeg_space_test                    	= p_test;

model_data.grid.nelements_test              = nelements_test;

model_data.df_info.nnodes_test              = nnodes_test;

model_data.grid.elements_coarse             = coarse_space;

model_data.grid.elements_fine               = fine_space;

if model.use_exact_integration
    model_data.grid.X_test_with_LGL_exact_integration = X_space_test;
else
   model_data.grid.X_test_with_LGL = X_space_test; 
end

if model.use_exact_integration
    model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration = ind_of_LGL_nodes_test;
else
    model_data.df_info.ind_of_LGL_nodes_on_element_test = ind_of_LGL_nodes_test;
end

if model.pdeg_space_trial ~= 0
    model_data.df_info.elements_glob_test = glob_space_test;
    model_data.grid.stepsize_per_element_test = stepsize_per_element;
end

model_data.grid.ratio = ratio;
    
model_data.df_info.LGL_DiffMatrix_test = LGL_DiffMatrix_test;

model_data.df_info.LGL_DiffMatrix_LeftBound_test = LGL_DiffMatrix_test_LeftBound;

model_data.df_info.LGL_DiffMatrix_RightBound_test = LGL_DiffMatrix_test_RightBound;

model.ultraweak_formulation = ultraweak_formulation;

model.decomp_mode = decomp_mode;