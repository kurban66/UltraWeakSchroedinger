function [L2, L2_with_Dirichlet] = BSpline_compute_inner_product_matrix_L2_space_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               L2 inner-product matrix (mixed) between spatial 
%                       trial and spatial test functions with and without
%                       Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the L2 inner-product matrices between the
% spatial trial functions and the spatial test functions (= "mixed") with 
% and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values for computing Inner-Product-Matrix
diff_space                              = model.has_diffusivity_space;
model.has_diffusivity_space             = 0;

adv_space                               = model.has_advection_space;
model.has_advection_space               = 0;

reac_space                              = model.has_reaction_space;
model.has_reaction_space                = 1;

dirichlet_space                         = model.has_dirichlet_values_space;
model.has_dirichlet_values_space        = 0;

robin_space                             = model.has_robin_values_space;
model.has_robin_values_space            = 0;

decomp_mode                             = model.decomp_mode;
model.decomp_mode                       = 0;

%% Save & change the reaction components and coefficients!
reaction_space       = model.reaction_space;
model.reaction_space = @(glob,params) ones(length(glob),1);

%% Compute Inner Product Matrix
L2_space          = BSpline_assembly_matrices_space(model,model_data);
L2_with_Dirichlet = L2_space{1};
L2                = L2_with_Dirichlet;

model.has_dirichlet_values_space = dirichlet_space;

if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_trial)
    dir_info_trial            = model_data.df_info.dirichlet_ind_trial;
    L2(:,dir_info_trial(:,1)) = [];
end

if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_test)
    dir_info_test            = model_data.df_info.dirichlet_ind_test;
    L2(dir_info_test(:,1),:) = [];
end

%% Return the old values
model.has_diffusivity_space             = diff_space;
model.has_advection_space               = adv_space;
model.has_reaction_space                = reac_space;

model.has_robin_values_space            = robin_space;

model.reaction_space                    = reaction_space;

model.decomp_mode                       = decomp_mode;