function [H1, H1_with_Dirichlet] = BSpline_compute_inner_product_matrix_H1_time_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H1 inner-product matrix (mixed) between temporal 
%                       trial and temporal test functions with and without
%                       Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H1 inner-product matrices between the
% temporal trial functions and the temporal test functions (= "mixed") with 
% and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Compute L2-Inner-Product-Matrix
L2                = model_data.inner_product_matrices.L2_mixed;
L2_with_Dirichlet = model_data.inner_product_matrices.L2_mixed_with_Dirichlet;

%% Compute H1-Semi-Inner-Product-Matrix
H1semi = model_data.inner_product_matrices.H1semi_mixed;
H1semi_with_Dirichlet = model_data.inner_product_matrices.H1semi_mixed_with_Dirichlet;

%% Compute H1-Inner-Product-Matrix
H1                = H1semi + L2;
H1_with_Dirichlet = H1semi_with_Dirichlet + L2_with_Dirichlet;

end