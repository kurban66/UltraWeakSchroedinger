function [H2, H2_with_Dirichlet] = BSpline_compute_inner_product_matrix_H2_time_mixed(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               H2 inner-product matrix (mixed) between temporal 
%                       trial and temporal test functions with and without
%                       Dirichlet boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the H2 inner-product matrices between the
% temporal trial functions and the temporal test functions (= "mixed") with 
% and without considering Dirichlet boundary conditions. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Compute L2-Inner-Product-Matrix
H1                = model_data.inner_product_matrices.H1_mixed;
H1_with_Dirichlet = model_data.inner_product_matrices.H1_mixed_with_Dirichlet;

%% Compute H1-Semi-Inner-Product-Matrix
H2semi = model_data.inner_product_matrices.H2semi_mixed;
H2semi_with_Dirichlet = model_data.inner_product_matrices.H2semi_mixed_with_Dirichlet;

%% Compute H1-Inner-Product-Matrix
H2                = H2semi + H1;
H2_with_Dirichlet = H2semi_with_Dirichlet + H1_with_Dirichlet;

end