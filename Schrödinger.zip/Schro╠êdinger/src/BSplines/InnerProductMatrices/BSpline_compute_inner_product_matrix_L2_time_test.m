function L2 = BSpline_compute_inner_product_matrix_L2_time_test(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               L2 inner-product matrix for temporal test functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the L2 inner-product matrix for the
% temporal test functions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set values
diff_time                               = model.has_diffusivity_time;
model.has_diffusivity_time              = 0;

adv_time                                = model.has_advection_time;
model.has_advection_time                = 0;

reac_time                               = model.has_reaction_time;
model.has_reaction_time                 = 1;

if isempty(model_data.df_info.dirichlet_ind_test)
    dirichlet_values = model.has_dirichlet_values_time;
    model.has_dirichlet_values_time = 0;
else
    dirichlet_trial = model_data.df_info.dirichlet_ind_trial;
    model_data.df_info.dirichlet_ind_trial = model_data.df_info.dirichlet_ind_test;
end

decomp_mode                             = model.decomp_mode;
model.decomp_mode                       = 0;

p_trial                                 = model.pdeg_time_trial;
model.pdeg_time_trial                   = model.pdeg_time_test;

nelements_trial                         = model_data.grid.nelements_trial;
model_data.grid.nelements_trial         = model_data.grid.nelements_test;

coarse_time                             = model_data.grid.elements_coarse;
model_data.grid.elements_coarse         = model_data.grid.nelements_test;

fine_time                               = model_data.grid.elements_fine;
model_data.grid.elements_fine           = model_data.grid.nelements_test;

nnodes_trial                            = model_data.df_info.nnodes_trial;
model_data.df_info.nnodes_trial         = model_data.df_info.nnodes_test;

ratio                                   = model_data.grid.ratio;
model_data.grid.ratio                   = 1;

if model.use_exact_integration
    X_time_trial = model_data.grid.X_trial_with_LGL_exact_integration;
    model_data.grid.X_trial_with_LGL_exact_integration = model_data.grid.X_test_with_LGL_exact_integration;
                                 
    ind_of_LGL_nodes_trial = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration;
    model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration = model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration;
else
    X_time_trial = model_data.grid.X_trial_with_LGL;
    model_data.grid.X_trial_with_LGL = model_data.grid.X_test_with_LGL;
    
    ind_of_LGL_nodes_trial = model_data.df_info.ind_of_LGL_nodes_on_element_trial;
    model_data.df_info.ind_of_LGL_nodes_on_element_trial = model_data.df_info.ind_of_LGL_nodes_on_element_test;
end

if model.pdeg_time_test ~= 0
    glob_time_trial = model_data.df_info.elements_glob_trial;
    model_data.df_info.elements_glob_trial = model_data.df_info.elements_glob_test;
    
    stepsize_per_element  = model_data.grid.stepsize_per_element_trial;
    model_data.grid.stepsize_per_element_trial = model_data.grid.stepsize_per_element_test;
end

LagrangeValuesTrial = model_data.df_info.lagrange_values_on_reference_element_trial;
model_data.df_info.lagrange_values_on_reference_element_trial = model_data.df_info.lagrange_values_on_reference_element_test;

LagrangeValuesTrial_LeftBound = model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial;
model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial = model_data.df_info.lagrange_values_on_reference_element_LeftBound_test;

LagrangeValuesTrial_RightBound = model_data.df_info.lagrange_values_on_reference_element_RightBound_trial;
model_data.df_info.lagrange_values_on_reference_element_RightBound_trial = model_data.df_info.lagrange_values_on_reference_element_RightBound_test;

%% Save & change the reaction components and coefficients!
reaction_time       = model.reaction_time;
model.reaction_time = @(glob,params) ones(length(glob),1);

%% Comppute Inner Product Matrix
L2 = BSpline_assembly_matrices_time(model, model_data);
L2 = L2{1};

L2 = 0.5*(L2 + L2');

%% Return the old values
model.has_diffusivity_time                  = diff_time;

model.has_advection_time                    = adv_time;

model.has_reaction_time                     = reac_time;

if isempty(model_data.df_info.dirichlet_ind_test)
    model.has_dirichlet_values_time = dirichlet_values;
else
    model_data.df_info.dirichlet_ind_trial = dirichlet_trial;
end

model.reaction_time                         = reaction_time;

model.pdeg_time_trial                       = p_trial;

model_data.grid.nelements_trial             = nelements_trial;

model_data.df_info.nnodes_trial             = nnodes_trial;

model_data.grid.elements_coarse             = coarse_time;

model_data.grid.elements_fine               = fine_time;

if model.use_exact_integration
    model_data.grid.X_trial_with_LGL_exact_integration = X_time_trial;
    model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration = ind_of_LGL_nodes_trial;
else
   model_data.grid.X_trial_with_LGL = X_time_trial; 
   model_data.df_info.ind_of_LGL_nodes_on_element_trial = ind_of_LGL_nodes_trial;
end

if model.pdeg_time_test ~= 0
    model_data.df_info.elements_glob_trial = glob_time_trial;
    model_data.grid.stepsize_per_element_trial = stepsize_per_element;
end
    
model_data.df_info.lagrange_values_on_reference_element_trial = LagrangeValuesTrial;

model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial = LagrangeValuesTrial_LeftBound;

model_data.df_info.lagrange_values_on_reference_element_RightBound_trial = LagrangeValuesTrial_RightBound;

model_data.grid.ratio = ratio;

model.decomp_mode = decomp_mode;