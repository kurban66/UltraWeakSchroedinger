clear
close all
clc

% Add the path of the toolkit by C. Mollet 
addpath('../Toolkit-Splines');
addpath('../Toolkit-Splines/Utilities');

refinementLevel = 3;
bSplineOrder = 4;

T = InitUniNodes(refinementLevel, bSplineOrder);
Tsol = T;
Ttest = T;
ksol = bSplineOrder;
ktest = bSplineOrder;
diff = 0;


% Draw all splines
x = linspace(0,1,1000);
for i=1:length(T)-bSplineOrder
    f = @(x) Ndiff(Tsol,ksol,diff,i,x);
    fx = zeros(size(x));
    for j = 1:length(x)
        fx(j) = f(x(j));
    end
    plot(x, fx, 'LineWidth', 2)
    grid on
    hold on
end
plot(T, zeros(size(T)), '*', 'MarkerSize', 5)

