function [A] = BSpline_assembly_matrices_time(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               temporal system matrices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function helps to compute only the necessary temporal system 
% matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if model.ultraweak_formulation
    
    Adiff_strong    = []; 
    Abidiff         = []; 
    Adiff_ultraweak = []; 
    Aadv            = []; 
    Adiff           = []; 
    Aadv_ultraweak  = []; 
    Areac           = []; 
    
    %% Assemble Diffusion Matrices
    if model.has_diffusivity_time 
        
        if model.use_SEM
            
            error('Not suitable for SEM!')
            
        elseif model.use_BSplines
            
            Adiff_strong    = BSpline_compute_diffusion_matrix_strong_time(model, model_data);
            Abidiff         = BSpline_compute_bidiffusion_matrix_time(model, model_data);
            Adiff_ultraweak = BSpline_compute_diffusion_matrix_ultraweak_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    
    %% Assemble Advection-Matrices
    if model.has_advection_time
        
        if model.use_SEM
            
            Aadv = sem_compute_advection_matrix_time(model, model_data);
            
        elseif model.use_BSplines
            
            Aadv           = BSpline_compute_advection_matrix_time(model, model_data);
            Adiff          = BSpline_compute_diffusion_matrix_time(model, model_data);
            Aadv_ultraweak = BSpline_compute_advection_matrix_ultraweak_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    
    %% Assemble Reaction-Matrices
    if model.has_reaction_time
        
        if model.use_SEM
            
            Areac = sem_compute_reaction_matrix_time(model, model_data);
            
        elseif model.use_BSplines
            
            Areac = BSpline_compute_reaction_matrix_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    A = [Adiff_strong; Abidiff; Adiff_ultraweak; Aadv; Adiff; Aadv_ultraweak; Areac];
    
else
    
    Adiff   = [];
    Aadv    = [];
    Areac   = [];
    
    %% Assemble Diffusion Matrices
    if model.has_diffusivity_time
        
        if model.use_SEM
            
            Adiff = sem_compute_diffusion_matrix_time(model, model_data);
            
        elseif model.use_BSplines
            
            Adiff = BSpline_compute_diffusion_matrix_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    
    %% Assemble Advection-Matrices
    if model.has_advection_time
        
        if model.use_SEM
            
            Aadv = sem_compute_advection_matrix_time(model, model_data);
            
        elseif model.use_BSplines
            
            Aadv = BSpline_compute_advection_matrix_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    
    
    %% Assemble Reaction-Matrices
    if model.has_reaction_time
        
        if model.use_SEM
            
            Areac = sem_compute_reaction_matrix_time(model, model_data);
            
        elseif model.use_BSplines
            
            Areac = BSpline_compute_reaction_matrix_time(model, model_data);
            
        elseif model.use_dgSEM
            
            error('Not implemented yet!')
            
        end
        
    end
    
    A = [Adiff; Aadv; Areac];
    
end

end
