function Aadv = BSpline_compute_advection_matrix_ultraweak_space(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               spatial ultraweak advection matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the spatial ultraweak advection matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialization
p_trial = model.pdeg_space_trial; % Fuer Adaptivitaet in die For-Schleife der Elemente
p_test  = model.pdeg_space_test;  % Fuer Adaptivitaet in die For-Schleife der Elemente


%% Choose Grid
if model.use_exact_integration
    
    if model_data.grid.nelements_trial <= model_data.grid.nelements_test
        
        X = model_data.grid.X_test_with_LGL_exact_integration(:);
        
    else
        
        X = model_data.grid.X_trial_with_LGL_exact_integration(:);
        
    end
    
elseif model_data.df_info.nnodes_trial >= model_data.df_info.nnodes_test
    
    X = model_data.grid.X_trial_with_LGL(:);
    
elseif model_data.df_info.nnodes_trial < model_data.df_info.nnodes_test
    
    X = model_data.grid.X_test_with_LGL(:);
    
end


%% Compute Advection-Matrix
coeff = model.advection_space(X(:),model);

if model.decomp_mode == 0
    coeff = {coeff};
end

Q_a_adv = size(coeff,2);

Aadv    = cell(Q_a_adv,1);

for q = 1:Q_a_adv
    
    Aadv{q} = sparse(model_data.df_info.nnodes_test, model_data.df_info.nnodes_trial);
    
    if p_trial ~= 0
        
        b        = coeff{q};
        
        for el_coarse = 1:model_data.grid.elements_coarse
            
            for el_fine = ((el_coarse - 1)*model_data.grid.ratio + 1):(el_coarse*model_data.grid.ratio)
                
                if model_data.grid.nelements_trial <= model_data.grid.nelements_test && p_trial ~= 0 && p_test ~= 0
                    
                    ind_trial = model_data.df_info.elements_glob_trial{el_coarse};
                    
                    ind_test  = model_data.df_info.elements_glob_test{el_fine};
                    
                elseif model_data.grid.nelements_trial <= model_data.grid.nelements_test && p_trial == 0 && p_test ~= 0
                    
                    ind_trial = el_coarse;
                    
                    ind_test  = model_data.df_info.elements_glob_test{el_fine};
                    
                elseif model_data.grid.nelements_trial <= model_data.grid.nelements_test && p_trial ~= 0 && p_test == 0
                    
                    ind_trial = model_data.df_info.elements_glob_trial{el_coarse};
                    
                    ind_test  = el_fine;
                    
                elseif model_data.grid.nelements_trial <= model_data.grid.nelements_test && p_trial == 0 && p_test == 0
                    
                    ind_trial = el_coarse;
                    
                    ind_test  = el_fine;
                    
                elseif model_data.grid.nelements_trial > model_data.grid.nelements_test && p_trial ~= 0 && p_test ~= 0
                    
                    ind_trial = model_data.df_info.elements_glob_trial{el_fine};
                    
                    ind_test  = model_data.df_info.elements_glob_test{el_coarse};
                    
                elseif model_data.grid.nelements_trial > model_data.grid.nelements_test && p_trial == 0 && p_test ~= 0
                    
                    ind_trial = el_fine;
                    
                    ind_test  = model_data.df_info.elements_glob_test{el_coarse};
                    
                elseif model_data.grid.nelements_trial > model_data.grid.nelements_test && p_trial ~= 0 && p_test == 0
                    
                    ind_trial = model_data.df_info.elements_glob_trial{el_fine};
                    
                    ind_test  = el_coarse;
                    
                elseif model_data.grid.nelements_trial > model_data.grid.nelements_test && p_trial == 0 && p_test == 0
                    
                    ind_trial = el_fine;
                    
                    ind_test  = el_coarse;
                    
                end
                
                
                
                if model.use_exact_integration
                    if model_data.grid.nelements_trial >= model_data.grid.nelements_test
                        ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_trial_exact_integration{el_fine};
                    else
                        ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_test_exact_integration{el_fine};
                    end
                else
                    if model_data.grid.nelements_trial >= model_data.grid.nelements_test
                        ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_trial{el_fine};
                    else
                        ind_of_LGL_nodes = model_data.df_info.ind_of_LGL_nodes_on_element_test{el_fine};
                    end
                end
                
                
                
                if model_data.grid.nelements_trial <= model_data.grid.nelements_test
                    
                    if size(model_data.df_info.lagrange_values_on_reference_element_test,2) == 1
                        
                        if p_trial >=2 && el_coarse <= p_trial - 1
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_trial >= 2 && el_coarse >= model_data.grid.elements_coarse - p_trial + 2
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                        if p_test >= 2 && el_coarse <= p_test - 1
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, 1};
                        elseif p_test >= 2 && el_coarse >= model_data.grid.elements_coarse - p_test + 2
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_RightBound_test{model_data.grid.elements_coarse - el_coarse + 1, 1};
                        else
                            Matrix_test = cell2mat(model_data.df_info.LGL_DiffMatrix_test);
                        end
                        
                    else
                        
                        if p_trial >=2 && el_coarse <= p_trial - 1
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_trial >= 2 && el_coarse >= model_data.grid.elements_coarse - p_trial + 2
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                        if p_test >= 2 && el_coarse <= p_test - 1
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_test >= 2 && el_coarse >= model_data.grid.elements_coarse - p_test + 2
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_RightBound_test{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_test{mod(mod(el_fine, model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                    end
                    
                else
                    
                    if size(model_data.df_info.LGL_DiffMatrix_trial,2) == 1
                        
                        if p_trial >=2 && el_coarse <= p_trial - 1
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, 1};
                        elseif p_trial >= 2 && el_coarse >= model_data.grid.elements_coarse - p_trial + 2
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.grid.elements_coarse - el_coarse + 1, 1};
                        else
                            Matrix_trial = cell2mat(model_data.df_info.lagrange_values_on_reference_element_trial);
                        end
                        
                        if p_test >= 2 && el_coarse <= p_test - 1
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_test >= 2 && el_coarse >= model_data.grid.elements_coarse - p_test + 2
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_RightBound_test{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_test{mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                    else
                        
                        if p_trial >=2 && el_coarse <= p_trial - 1
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_LeftBound_trial{el_coarse, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_trial >= 2 && el_coarse >= model_data.grid.elements_coarse - p_trial + 2
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_RightBound_trial{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_trial = model_data.df_info.lagrange_values_on_reference_element_trial{mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                        if p_test >= 2 && el_coarse <= p_test - 1
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_LeftBound_test{el_coarse, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        elseif p_test >= 2 && el_coarse >= model_data.grid.elements_coarse - p_test + 2
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_RightBound_test{model_data.grid.elements_coarse - el_coarse + 1, mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        else
                            Matrix_test = model_data.df_info.LGL_DiffMatrix_test{mod(mod(el_fine,model_data.grid.ratio+1)+el_coarse-1,model_data.grid.ratio+1)};
                        end
                        
                    end
                    
                end
                
                 Aadv{q}(ind_test, ind_trial) = Aadv{q}(ind_test, ind_trial) - ...
                    (1/model_data.grid.ratio) * ((diag(conj(b(ind_of_LGL_nodes)) .* model_data.df_info.LGL_weights_on_reference_element') * ...
                    Matrix_trial)' * Matrix_test)';
                
            end
            
        end
        
    end
    
    if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_trial)
        dir_info_trial = model_data.df_info.dirichlet_ind_trial;
        Aadv{q}(:,dir_info_trial(:,1)) = [];
    end
    
    if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_test)
        dir_info_test = model_data.df_info.dirichlet_ind_test;
        Aadv{q}(dir_info_test(:,1),:) = [];
    end
    
end