function Arobin = BSpline_compute_robin_matrix_space(model, model_data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT:                struct model, struct model_data  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               spatial matrix for Robin boundary conditions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
% 
%                       Petrov_Galerkin_BSplines library from C. Mollet            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB function computes the spatial matrix for Robin boundary 
% conditions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Choose Grid
if model.use_exact_integration
    
    if model_data.grid.nelements_trial <= model_data.grid.nelements_test
        
        X = model_data.grid.X_test_with_LGL_exact_integration(:);
        
    else
        
        X = model_data.grid.X_trial_with_LGL_exact_integration(:);
        
    end
    
elseif model_data.df_info.nnodes_trial >= model_data.df_info.nnodes_test
    
    X = model_data.grid.X_trial_with_LGL(:);
    
elseif model_data.df_info.nnodes_trial < model_data.df_info.nnodes_test
    
    X = model_data.grid.X_test_with_LGL(:);
    
end


%% Compute Robin-Matrix
gR = model.robin_beta_space(X(:),model);

if model.decomp_mode == 0
    gR = {gR};
end

Q_a_robin_beta = size(gR,2);
Arobin = cell(Q_a_robin_beta,1);

for q = 1:Q_a_robin_beta
    
    Arobin{q} = sparse(model_data.df_info.nnodes_test, model_data.df_info.nnodes_trial);
    
    robin_trial = model_data.df_info.robin_ind_trial;
    robin_test  = model_data.df_info.robin_ind_test;
    
    for i = 1:size(robin_trial,1) % length(robin_trial) = length(robin_test) - diese For-Schleife stimmt noch nicht
        ind_trial = robin_trial(i,1);
        ind_test  = robin_test(i,1);
        
        Arobin{q}(ind_test,ind_trial) = gR{q}(i);
    end
    
    if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_trial)
        dir_info_trial = model_data.df_info.dirichlet_ind_trial;
        Arobin{q}(:,dir_info_trial(:,1)) = [];
    end
    
    if model.has_dirichlet_values_space && ~isempty(model_data.df_info.dirichlet_ind_test)
        dir_info_test = model_data.df_info.dirichlet_ind_test;
        Arobin{q}(dir_info_test(:,1),:) = [];
    end
    
end