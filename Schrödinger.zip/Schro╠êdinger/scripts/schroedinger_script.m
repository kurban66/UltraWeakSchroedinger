clear; 
close all; 
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AUTHORS:              Stefan Hain
% LAST MODIFICATION:    13.09.2023
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT:               Inf-sup constants as well as space-time errors
%                       w.r.t. the natural Bochner norm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USED LIBRARIES:       RBmatlab 
%                       M. Dihlmann, M. Drohmann, B. Haasdonk, M.
%                       Ohlberger, M. Schaefer
%                       https://www.morepas.org/software/rbmatlab/
%
%                       Petrov_Galerkin_BSplines library from C. Mollet 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This MATLAB script sets up the system of linear equations for a space-time
% variational formulation of the Schroedinger equation analogeously to the
% parabolic case. Inf-sup constants as well as space-time errors w.r.t. the
% natural Bochner norm are computed.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Since Code is in a subdirectory
addpath(genpath('../src'));
addpath(genpath('../models'));

% Set FileName for saving results later
FileName = '...';

% Select discretization method
params.use_SEM      = 1;
params.use_dgSEM    = 0;
params.use_BSplines = 0 ;

% Set spatial and temporal domain
params.xrange    = [0,1];
params.trange    = [0,1];

% Define the level for the high-fidelity discretization in space
level_space      = 2:5;

% Define parameter. However, not relevant for my numerical experiments
parameter_max    = 1;
parameter        = 1;

% Initialize relevant quantites
errorSpaceTime   = zeros(1,length(level_space));
iterations       = zeros(1,length(level_space));
runtime          = zeros(1,length(level_space));
dofs             = zeros(1,length(level_space));
infsup_constants = zeros(length(parameter), length(level_space));
real_parts       = zeros(length(parameter), length(level_space));
imag_parts       = zeros(length(parameter), length(level_space));

for k = 1:length(level_space) % Loop over level in time
    
    level = level_space(k)
    
    % Discretization in space
    params.level_space_trial = level;
    params.level_space_test  = level;
    
    params.pdeg_space_trial  = 1;
    params.pdeg_space_test   = 1;
    

    % Discretization in time
    params.level_time_trial = 3*(level+1);
    params.level_time_test  = 3*(level+1);
    
    params.pdeg_time_trial  = 1;
    params.pdeg_time_test   = 0;
    
    % Set model
    model = schroedinger_model(params);
    
    % Select, if energy norm should be applied instead of ||.||_V
    model.use_energy_norm = 0; % Does not work for time-dependent inner sesquilinear forms
    
    % Add the term ||u(T)||_H^2 to the natural Bochner norm for trial space, i.e.
    % ||u||_U^2 = ||u||_L2(I;V)^2 + ||u_t||_L2(I;V')^2 + ||u(T)||_H^2
    model.use_modified_norm = 0;
    
    % Select is subspace dependent norm should be applied
    model.use_discrete_norm           = 0;
    
    % Settings for solving system of linear equations. Kronecker product is
    % not efficient, but recommended within this implementation
    if level <= 8
        model.use_kronecker_product = 1;
    else
        model.use_kronecker_product = 0;
    end
    
    model.use_CGNR = 0;
    
    if level <= 8
        model.use_CGNR_precond = 0;
    else
        model.use_CGNR_precond = 1;
    end

    model.use_LSQR                  = 0;
    
    % Plot solution?
    model.plot = 0;
    
    % Compute inf-sup constant?
    model.compute_infsup = 1;
    
    for i = 1:length(parameter)
        
        % Set i-th parameter
        model.mus  = parameter(i);
        
        % Generate model_data
        model_data = model.gen_model_data(model);
        
        % Generate operators
        [B, r]  = model.operators(model,model_data);
        
        % NDOFs
        dofs(k) = size(B,2);
        
        % Compute inf-sup constant
        if model.compute_infsup
            infsup_constants(i,k) = get_infsup_space_time(B, model, model_data);
            disp(['Die Inf-Sup-Konstante fuer mu = ' num2str(parameter(i)) ' betraegt: '  num2str(infsup_constants(i,k))])
        end
        
        % Solve LGS
        [u, iteration, time] = model.solveLGS(B, r, model, model_data, 'notransp');
        runtime(k)           = time;
        if model.use_CGNR || model.use_CGNR_precond || model.use_LSQR
            iterations(k) = iteration;
        end
        
        % Reshape solution
        u = model.doReshape(u, model, model_data); 
        
        % Some experiments w.r.t. int_I <u_t(t),u(t)>_V'xV dt
        if model.use_kronecker_product && size(B,1) == size(B,2) && isempty(model_data.time.df_info.dirichlet_ind_trial)
            [real_parts(i,k), imag_parts(i,k)] = compute_real_imag_term_spacetime(u, model, model_data);
        end
        
        % Reconstruct dirichlet boundary conditions
        if ~isempty(model_data.time.df_info.dirichlet_ind_trial) %&& model_data.time.df_info.dirichlet_ind_trial(:,1) == 1
            u = model.reconstruct_dirichlet_time_and_space(model, model_data, u); % Hier muss noch weitergearbeitet werden
        else
            u = model.reconstruct_dirichlet_space(model, model_data, u);
        end
        
        % Evaluate Function Values B-Splines
        %if model.use_BSplines && model.plot
        %   u = Evaluate_Spline(u, model);
        %end
        
        % Plot solution
        if model.plot
            
            u_ex = @(t,x) sqrt(2)*sin(pi*x).*exp(-(pi^2/2)*1i*t);
            
            if model.use_SEM
                [T,X] = meshgrid(sort(model_data.time.grid.X_trial_with_LGL), sort(model_data.space.grid.X_trial_with_LGL));
            else
                
                grid_space = model_data.space.grid.X_trial;
                grid_time  = model_data.time.grid.X_trial;
                
                [T,X] = meshgrid(grid_time, grid_space);
            end
            
            u_ex_values = u_ex(T,X);
            
            model.plot_solution(model, model_data, u, u_ex_values)
            %model.plot_solution(model, model_data, u)
            
        end
        
        % Space-time error
        u_ex = @(t,x) sqrt(2)*sin(pi*x).*exp(-(pi^2/2)*1i*t);
        
        [T,X] = meshgrid(sort(model_data.time.grid.X_trial_with_LGL), sort(model_data.space.grid.X_trial_with_LGL));
        u_ex_values = u_ex(T,X);
        
        if ~isempty(model_data.time.df_info.dirichlet_ind_trial)
            u_ex_values = u_ex_values(2:end-1,2:end);
            u           = u(2:end-1,2:end);
        else
            u_ex_values = u_ex_values(2:end-1,:);
            u           = u(2:end-1,:);
        end
        
        error     = u_ex_values - u;
        error_vec = error(:);
        
        errorSpaceTime(k) = model.compute_spacetime_error(error, error_vec, model, model_data);
        
    end
    
end

% Save data
for i = 1:length(parameter)
    
    M = [real(dofs.'), infsup_constants(i,:)', real_parts(i,1:length(dofs))', imag_parts(i,1:length(dofs))'];
    
    header   = {'dofs ', 'Inf-Sup ', 'Real-Part ', 'Imag-Part'};
    T        = table(M(:,1), M(:,2), M(:,3), M(:,4), 'VariableNames', header);
    
    writetable(T, FileName, 'Delimiter', 'tab')
end


%% Plot Space-Time-Error
%{
figure
loglog(dofs, errorSpaceTime, 'r*-','linewidth',2,'MarkerSize',14)
loglogTriangle(10^3,10^4,10^(-4.5),2,'l');
title({'Evolution of the Space-Time-Error'},'interpreter','Latex')
xlabel({'DOFs'},'interpreter','Latex')
ylabel({'$\Vert u - u^{\mathcal{N}} \Vert_{\mathcal{X}}^2$'},'interpreter','Latex')
grid on
set(gca,'FontSize',42)
%}


%% Plot Iterations
%{
dofs = [85, 297, 1105, 4257, 16705, 66177, 263425, 1051137];
iterations_CGNR = [16, 32, 67, 255, 1020, 4088, 16362, 65445];
iterations_pCGNR = [13, 13, 15, 23, 38, 70, 131, 232];

figure
semilogy(dofs, iterations_CGNR, 'r*-',dofs, iterations_pCGNR, 'b^-','linewidth',2,'MarkerSize',14)
title({'Number of Iterations CGNR and pCGNR'},'interpreter','Latex')
legend({'CGNR', 'pCGNR'}, 'interpreter','Latex')
xlabel({'DOFs'},'interpreter','Latex')
ylabel({'Number of Iterations'},'interpreter','Latex')
grid on
set(gca,'FontSize',42)
%}


%% Plot Runtime
%{
dofs = [85, 297, 1105, 4257, 16705, 66177, 263425, 1051137];
runtime_Backslash = [1.8319e-05, 9.7355e-05, 0.0027, 0.0140, 0.0811, 0.3912, 1.9808];
runtime_CGNR      = [0.0026, 0.0014, 0.0064, 0.1009, 1.1535, 15.6101, 304.6541, 6.6299e+03];
runtime_pCGNR    = [0.3819, 0.4508, 0.6140, 0.9663, 2.4731, 13.9086, 189.5061, 4.0533e+03];

figure
semilogy(dofs(1:end-1), runtime_Backslash, 'r*-',dofs, runtime_CGNR, 'b^-', dofs, runtime_pCGNR, 'g<-', 'linewidth', 2, 'MarkerSize', 14)
title({'Runtime Backslash-Operator, CGNR and pCGNR'},'interpreter','Latex')
legend({'Backslash','CGNR', 'pCGNR'}, 'interpreter','Latex')
xlabel({'DOFs'},'interpreter','Latex')
ylabel({'Runtime'},'interpreter','Latex')
grid on
set(gca,'FontSize',42)
%}


%% Plot inf-sup
% figure
% plot(parameter,infsup_constants,'r*-','linewidth',2.5,'Markersize',10)
% title({'$\beta(\mu)$ \"uber $\mathcal{P}$ (Harm. Osz.)'},'interpreter','Latex')
% xlabel({'Parameterbereich'},'interpreter','Latex')
% ylabel({'$\beta(\mu)$'},'interpreter','Latex')
% %ylim([0.001175,0.001176])
% grid on
% set(gca,'FontSize',28)

% figure
% semilogy(dofs,infsup_constants(1,:),'r*-','linewidth',2.5,'Markersize',10)
% xlabel({'NDOFs'},'interpreter','Latex')
% ylabel({'$\beta$'},'interpreter','Latex')
% %ylim([0.25,0.27])
% grid on
% set(gca,'FontSize',48)